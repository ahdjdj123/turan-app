/*
 * TURAN offline museum service worker.
 * Precaches every city-era artwork so the museum stays open without a network
 * (field trips, classrooms, airplanes). Artwork requests are served
 * stale-while-revalidate: instant from cache, refreshed in the background.
 */
const MANIFEST_URL = '/images/cities/manifest.json';
const MANIFEST_CACHE = 'turan-manifest-v1';
let ART_CACHE = 'turan-art-v1';

self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      try {
        const res = await fetch(MANIFEST_URL, { cache: 'no-store' });
        const manifest = await res.json();
        if (manifest && manifest.version && Array.isArray(manifest.files)) {
          ART_CACHE = `turan-art-${manifest.version}`;
          const cache = await caches.open(ART_CACHE);
          await cache.addAll(manifest.files.map((f) => `/images/cities/${f}`));
          // remember which manifest we cached (for cleanup)
          const mcache = await caches.open(MANIFEST_CACHE);
          await mcache.put(MANIFEST_URL, new Response(JSON.stringify(manifest), { headers: { 'Content-Type': 'application/json' } }));
        }
      } catch (err) {
        /* offline during install — runtime caching below still works */
        console.error('[turan-sw] precache failed:', err && err.message ? err.message : err);
      }
      await self.skipWaiting();
    })()
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      // drop artwork caches from other manifest versions
      const names = await caches.keys();
      await Promise.all(
        names
          .filter((n) => n.startsWith('turan-art-') && n !== ART_CACHE)
          .map((n) => caches.delete(n))
      );
      await self.clients.claim();
    })()
  );
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || !url.pathname.startsWith('/images/cities/')) return;

  event.respondWith(
    (async () => {
      const cache = await caches.open(ART_CACHE);
      const cached = await cache.match(event.request);
      // stale-while-revalidate: answer from cache now, refresh in background
      const refresh = fetch(event.request)
        .then((res) => {
          if (res && res.ok) cache.put(event.request, res.clone());
          return res;
        })
        .catch(() => undefined);
      return cached || (await refresh) || new Response('', { status: 504 });
    })()
  );
});

// allow the app to ask the SW to clear cached artwork (offline mode off)
self.addEventListener('message', (event) => {
  if (event.data === 'turan-clear-art') {
    event.waitUntil(
      (async () => {
        const names = await caches.keys();
        await Promise.all(names.filter((n) => n.startsWith('turan-art-') || n === MANIFEST_CACHE).map((n) => caches.delete(n)));
      })()
    );
  }
});
