import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';

const OUT_DIR = path.resolve(process.cwd(), 'public/images/cities');
fs.mkdirSync(OUT_DIR, { recursive: true });

const STYLE =
  'museum-quality historical digital painting, cinematic lighting, rich detail, atmospheric, no text, no watermark, no modern logos';

const IMAGES = [
  { file: 'menu_caravan.png', size: '1344x768', prompt: `Silk Road caravan of camels and traders crossing golden desert dunes at dusk, distant turquoise domes and minarets of an ancient Central Asian city glowing on the horizon, epic wide landscape, ${STYLE}` },
  { file: 'samarkand_ancient.png', size: '1344x768', prompt: `Ancient Sogdian city of Maracanda (Samarkand), mud-brick citadel walls of Afrasiab under warm dusk sky, Zoroastrian fire temple with sacred flames, camel caravans, Central Asian oasis, terracotta and amber tones, ${STYLE}` },
  { file: 'samarkand_islamic.png', size: '1344x768', prompt: `9th-10th century Islamic Samarkand, elegant Samanid-era mosque with carved terracotta arches and turquoise domes, scholars in a serene courtyard, gardens and water channels, warm golden light, ${STYLE}` },
  { file: 'samarkand_timurid.png', size: '1344x768', prompt: `Registan Square in Samarkand at golden hour, 15th century Timurid golden age, monumental turquoise-tiled madrasah portals with gold mosaic, towering minarets and blue domes, majestic imperial splendor, ${STYLE}` },
  { file: 'samarkand_soviet.png', size: '1344x768', prompt: `Early 20th century Soviet-era Samarkand, vintage railway station, tram on old street, constructivist buildings beside ancient monuments, muted nostalgic photography tones, historical scene, ${STYLE}` },
  { file: 'samarkand_modern.png', size: '1344x768', prompt: `Modern Samarkand Uzbekistan at dusk, beautifully restored Registan ensemble glowing with warm light, elegant streets, gentle crowds, UNESCO heritage cityscape, photorealistic travel photography, ${STYLE}` },
  { file: 'bukhara_ancient.png', size: '1344x768', prompt: `Ancient Sogdian trading city of Bukhara, earthen ramparts and covered bazaar with merchants and silk goods, desert oasis with caravanserai, warm terracotta tones, ${STYLE}` },
  { file: 'bukhara_islamic.png', size: '1344x768', prompt: `Bukhara at its golden age, Poi-Kalyan ensemble with the great Kalyan minaret, Samanid Mausoleum with intricate brick lacework, moonlit square, turquoise and ivory tones, ${STYLE}` },
  { file: 'bukhara_timurid.png', size: '1344x768', prompt: `Timurid-era Bukhara, madrasah courtyards and domed trading arcades, scholars and merchants, turquoise and gold accents, living medieval city, ${STYLE}` },
  { file: 'bukhara_soviet.png', size: '1344x768', prompt: `Bukhara under Russian protectorate, early 20th century, Emir's city with slender minarets beside Russian colonial buildings, sepia vintage photography style, historical scene, ${STYLE}` },
  { file: 'bukhara_modern.png', size: '1344x768', prompt: `Modern Bukhara Uzbekistan at sunset, Kalyan minaret reflected in the Lyab-i Hauz pool, restored old town in warm golden light, photorealistic travel photography, ${STYLE}` },
  { file: 'khiva_ancient.png', size: '1344x768', prompt: `Ancient Khorezm fortress near Khiva, desert citadel walls and watchtowers, Amu Darya delta oasis, dramatic sky, earthy tones, ${STYLE}` },
  { file: 'khiva_islamic.png', size: '1344x768', prompt: `Itchan Kala in Khiva, ancient walled inner city, forest of carved wooden columns inside Juma Mosque, Kunya-Ark citadel, slender turquoise minaret, desert light, ${STYLE}` },
  { file: 'khiva_soviet.png', size: '1344x768', prompt: `Khiva as a quiet museum city in 20th century, restored ancient walls with subtle modern life outside, muted tones, vintage photography style, ${STYLE}` },
  { file: 'khiva_modern.png', size: '1344x768', prompt: `Modern Khiva Uzbekistan at dawn, Itchan Kala walls glowing golden, open-air museum atmosphere, clean morning sky, photorealistic travel photography, ${STYLE}` },
  { file: 'shakhrisabz_timurid.png', size: '1344x768', prompt: `Ak-Saray Palace in Shakhrisabz, colossal Timurid gate portal with blue and gold mosaic rising into the sky, 14th century construction site with scaffolding, monumental imperial ambition, ${STYLE}` },
  { file: 'termez_ancient.png', size: '1344x768', prompt: `Ancient Buddhist monastery Fayaz Tepe near Termez, Kushan empire 2nd century, whitewashed stupas and monastic courts, sandstone cliffs above the Amu Darya river, warm desert tones, ${STYLE}` },
  { file: 'tashkent_soviet.png', size: '1344x768', prompt: `Soviet-era Tashkent 1970s, monumental modernist buildings, wide tree-lined avenues, ornate metro station with chandeliers, muted vintage photography, ${STYLE}` },
  { file: 'tashkent_modern.png', size: '1344x768', prompt: `Modern Tashkent Uzbekistan at dusk, Amir Timur square with fountains, gleaming white buildings, blue-lit modern skyline, photorealistic travel photography, ${STYLE}` },
  { file: 'kokand_islamic.png', size: '1344x768', prompt: `Palace of Khudayar Khan in Kokand, 19th century Khanate architecture, ornate carved wooden columns, colorful majolica tiles, grand courtyard with gardens, ${STYLE}` },
  { file: 'urgench_ancient.png', size: '1344x768', prompt: `Ancient Konye-Urgench capital of Khorezm, great minaret and mausoleums of medieval Khwarazm, grand desert ruins, dramatic golden sunset, ${STYLE}` },
  { file: 'urgench_islamic.png', size: '1344x768', prompt: `Medieval Gurganj at its golden age, scholars of the Mamun Academy beneath the great minaret, thriving Khorezm capital, caravans and libraries, warm evening light, ${STYLE}` },
  { file: 'tashkent_ancient.png', size: '1344x768', prompt: `Ancient Sogdian settlement of Chach (Tashkent), earthen city walls and crossroad bazaar, traders with horses and ceramics, first millennium Central Asia, warm earthy tones, ${STYLE}` },
  { file: 'margilan_modern.png', size: '1344x768', prompt: `Margilan silk workshop in Uzbekistan, vivid ikat atlas silk fabrics drying on wooden racks, master craftsmen at mulberry-fed dye vats, warm light, photorealistic, ${STYLE}` },
  { file: 'nukus_soviet.png', size: '1344x768', prompt: `Nukus art museum gallery in Karakalpakstan, Soviet avant-garde paintings on quiet walls, desert city museum interior, muted museum light, historical scene, ${STYLE}` },
];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function generateOne(zai, item, attempt = 1) {
  try {
    const res = await zai.images.generations.create({ prompt: item.prompt, size: item.size });
    const b64 = res?.data?.[0]?.base64;
    if (!b64) throw new Error('empty response');
    const buf = Buffer.from(b64, 'base64');
    if (buf.length < 1000) throw new Error('suspiciously small image');
    fs.writeFileSync(path.join(OUT_DIR, item.file), buf);
    console.log(`[ok] ${item.file} (${Math.round(buf.length / 1024)} KB)`);
    return true;
  } catch (e) {
    console.error(`[fail ${attempt}] ${item.file}: ${e.message.split('\n')[0]}`);
    if (attempt < 5) {
      const backoff = e.message.includes('429') ? 12000 * attempt : 3000 * attempt;
      await sleep(backoff);
      return generateOne(zai, item, attempt + 1);
    }
    return false;
  }
}

async function main() {
  const zai = await ZAI.create();
  const pending = IMAGES.filter((i) => {
    const p = path.join(OUT_DIR, i.file);
    if (fs.existsSync(p) && fs.statSync(p).size > 1000) {
      console.log(`[skip] ${i.file} exists`);
      return false;
    }
    return true;
  });
  console.log(`Generating ${pending.length} images -> ${OUT_DIR}`);
  const CONCURRENCY = 1;
  let idx = 0;
  let ok = 0;
  async function worker() {
    while (idx < pending.length) {
      const item = pending[idx++];
      const success = await generateOne(zai, item);
      if (success) ok++;
      await sleep(2500);
    }
  }
  await Promise.all(Array.from({ length: CONCURRENCY }, worker));
  console.log(`DONE: ${ok}/${pending.length} generated, ${IMAGES.length - pending.length} skipped`);
}

main().catch((e) => {
  console.error('FATAL', e);
  process.exit(1);
});
