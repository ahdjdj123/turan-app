import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';

const OUT_DIR = path.resolve(process.cwd(), 'public/images/cities');
fs.mkdirSync(OUT_DIR, { recursive: true });

const STYLE =
  'museum-quality historical digital painting, cinematic lighting, rich detail, atmospheric, no text, no watermark, no modern logos';

// Remaining combos not covered by round-1/round-2 scripts (verified against disk)
const IMAGES = [
  { file: 'termez_timurid.png', prompt: `Timurid-era Termez, pilgrims at fluted-domed shrine complex, gardens along the Amu Darya, caravans and scholars, warm afternoon light, ${STYLE}` },
  { file: 'termez_soviet.png', prompt: `Soviet-era Termez, border garrison town on the Amu Darya, bridge and watchtowers, cotton trucks on dusty avenue, muted archival tones, ${STYLE}` },
  { file: 'karshi_islamic.png', prompt: `Medieval Islamic Karshi (Nakhshab), Friday mosque and caravanserai around a lotus pool, poplar groves, warm brick and carved terracotta, ${STYLE}` },
  { file: 'karshi_timurid.png', prompt: `Timurid-era Karshi, walled silk road town with courtyards of a grand caravanserai, fruit bazaars and melons, steppe horizon, golden light, ${STYLE}` },
  { file: 'karshi_soviet.png', prompt: `Soviet-era Karshi, irrigation canal with cotton collective farms, monument square with banners, 1970s retro photography feel, ${STYLE}` },
  { file: 'margilan_timurid.png', prompt: `Timurid-era Margilan, silk weavers' quarter with wooden looms under carved columns, mulberry orchards, Fergana valley morning light, ${STYLE}` },
  { file: 'margilan_soviet.png', prompt: `Soviet-era Margilan, silk combine factory with red banner, workers at mechanized looms, rainbow ikat fabric bolts, 1970s poster realism, ${STYLE}` },
  { file: 'kokand_khanates.png', prompt: `Khanate-era Kokand, Khudayar Khan palace with gilded majolica facade and seven courtyards, royal court procession, Fergana valley, ${STYLE}` },
  { file: 'kokand_soviet.png', prompt: `Soviet-era Kokand, Khan's palace converted to museum, school pioneers on excursion under plane trees, 1960s nostalgic tones, ${STYLE}` },
  { file: 'urgench_timurid.png', prompt: `Timurid-era Urgench, great Kutlug Timur minaret rising over reconstrucing city after Mongol ruin, masons and caravans, dawn desert light, ${STYLE}` },
  { file: 'urgench_khanates.png', prompt: `Khanate-era Khorezm, walled river capital on the Oxus with madrasahs and covered bazaars, desert caravan arriving at gates, ${STYLE}` },
  { file: 'fergana_khanates.png', prompt: `19th century Khanate Fergana, planned garrison citadel with gardens and new mud-brick streets, mounted Kokand sentries, valley orchards, ${STYLE}` },
  { file: 'fergana_soviet.png', prompt: `Soviet-era Fergana, plane-tree boulevards with Russian colonial facades, textile combine and oil derricks beyond, 1960s postcard style, ${STYLE}` },
  { file: 'andijan_islamic.png', prompt: `Medieval Islamic Andijan, grand Jami madrasah portal of carved brick, silk and indigo bazaar stalls, caravan camels at dusk, ${STYLE}` },
  { file: 'andijan_khanates.png', prompt: `Khanate-era Andijan, walled town with citadel under Kokand rule, pomegranate orchards, mounted riders on dusty roads, warm light, ${STYLE}` },
  { file: 'andijan_soviet.png', prompt: `Soviet-era Andijan, textile mill smokestacks and Lenin prospect with tram, monumental murals, 1970s retro postcard feel, ${STYLE}` },
  { file: 'navoi_ancient.png', prompt: `Ancient Karmana near the Zarafshan river, Sogdian fortress ruins on caravan road toward Merv, terracotta desert dusk, watchfires, ${STYLE}` },
  { file: 'navoi_islamic.png', prompt: `Medieval Islamic Karmana, Rabati Malik caravanserai portal and domed sardoba water cistern, desert caravan resting, warm sandstone, ${STYLE}` },
  { file: 'navoi_timurid.png', prompt: `Timurid-era Karmana, pilgrim caravan crossing the Zarafshan oasis toward Samarkand, Sufi shrine with poplars, golden evening, ${STYLE}` },
  { file: 'navoi_soviet.png', prompt: `Soviet-era Navoi, brand-new planned industrial city, mining combines and heroic worker murals, wide empty boulevards, 1970s, ${STYLE}` },
  { file: 'jizzakh_ancient.png', prompt: `Ancient Sogdian settlement near the Nurata hills, grape trellises and mud-brick towers, caravan trail across steppe, terracotta light, ${STYLE}` },
  { file: 'jizzakh_islamic.png', prompt: `Medieval Islamic Jizzakh, walled oasis town with madrasah and caravan gates at the steppe edge, bazaars and minaret, warm tones, ${STYLE}` },
  { file: 'jizzakh_timurid.png', prompt: `Timurid-era Jizzakh, imperial garden province at the mountain frontier, juniper forests of Zaamin, mounted patrol, fresh morning, ${STYLE}` },
  { file: 'jizzakh_soviet.png', prompt: `Soviet-era Jizzakh, heroic irrigation of the Hungry Steppe, canal construction and blooming cotton fields, socialist realist painting, ${STYLE}` },
  { file: 'gulistan_khanates.png', prompt: `19th century frontier of the Hungry Steppe, small Kokand khanate mud fort with sentries, camel caravan on dusty plain, haze, ${STYLE}` },
  { file: 'gulistan_soviet.png', prompt: `Soviet-era Gulistan, planned city rising from irrigated steppe, railway station and poplar alleys, flower gardens, retro optimism, ${STYLE}` },
  { file: 'nukus_ancient.png', prompt: `Ancient Khorezm near Nukus, Zoroastrian dakhma silence towers and Ayaz Qala desert fortress at dawn, wind-carved sands, ${STYLE}` },
  { file: 'nukus_khanates.png', prompt: `Khanate-era Khorezm frontier, Kurgancha-kala caravanserai ruins by the Amu Darya floodplain, camel caravan, soft desert light, ${STYLE}` },
];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function generateOne(zai, item, attempt = 1) {
  try {
    const res = await zai.images.generations.create({ prompt: item.prompt, size: '1344x768' });
    const b64 = res?.data?.[0]?.base64;
    if (!b64) throw new Error('empty response');
    const buf = Buffer.from(b64, 'base64');
    if (buf.length < 1000) throw new Error('suspiciously small image');
    fs.writeFileSync(path.join(OUT_DIR, item.file), buf);
    console.log(`[ok] ${item.file} (${Math.round(buf.length / 1024)} KB)`);
    return true;
  } catch (e) {
    console.error(`[fail ${attempt}] ${item.file}: ${e.message.split('\n')[0]}`);
    if (attempt < 5) {
      const backoff = e.message.includes('429') ? 12000 * attempt : 3000 * attempt;
      await sleep(backoff);
      return generateOne(zai, item, attempt + 1);
    }
    return false;
  }
}

async function main() {
  const zai = await ZAI.create();
  const pending = IMAGES.filter((i) => {
    const p = path.join(OUT_DIR, i.file);
    if (fs.existsSync(p) && fs.statSync(p).size > 1000) {
      console.log(`[skip] ${i.file} exists`);
      return false;
    }
    return true;
  });
  console.log(`Round 3: generating ${pending.length} images -> ${OUT_DIR}`);
  let idx = 0;
  let ok = 0;
  async function worker() {
    while (idx < pending.length) {
      const item = pending[idx++];
      const success = await generateOne(zai, item);
      if (success) ok++;
      await sleep(2500);
    }
  }
  await Promise.all(Array.from({ length: 1 }, worker));
  console.log(`DONE: ${ok}/${pending.length} generated`);
}

main().catch((e) => {
  console.error('FATAL', e);
  process.exit(1);
});
