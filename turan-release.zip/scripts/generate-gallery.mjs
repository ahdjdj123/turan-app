import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';

const OUT_DIR = path.resolve(process.cwd(), 'public/images/cities/gallery');
fs.mkdirSync(OUT_DIR, { recursive: true });

const STYLE =
  'museum-quality historical digital painting, cinematic lighting, rich architectural detail, atmospheric, no text, no watermark, no modern logos, no people facing camera';

// Landmark gallery plates referenced in src/data/cities-rich.ts
const IMAGES = [
  // Samarkand
  { file: 'samarkand_registan.png', prompt: `Registan Square Samarkand at golden dusk, three grand Timurid madrasahs with azure turquoise domes and towering pishtaq portals, majolica mosaic, vast empty plaza with long shadows, ${STYLE}` },
  { file: 'samarkand_bibi_khanym.png', prompt: `Grand historic mosque of Samarkand, huge pishtaq entrance gate and ribbed azure dome, marble lecture stand in a quiet courtyard, birds in soft sky, ${STYLE}` },
  { file: 'samarkand_shah_i_zinda.png', prompt: `Shah-i-Zinda necropolis Samarkand, narrow avenue of jewelled mausoleums with deep blue turquoise tilework, carved terracotta columns, stairway rising to shrine, evening light, ${STYLE}` },
  { file: 'samarkand_gur_e_amir.png', prompt: `Gur-e Amir mausoleum Samarkand, ribbed fluted turquoise dome on tall drum, azure portal with gold leaf calligraphy, twilight blue hour, single almond tree, ${STYLE}` },
  { file: 'samarkand_observatory.png', prompt: `Ulugh Beg Observatory Samarkand, monumental ancient astronomical sextant trench cut into hillside, marble arc segment, star charts on stone, scholars' instruments, dusk, ${STYLE}` },
  { file: 'samarkand_afrasiab.png', prompt: `Afrasiab mound ancient Samarkand, vast archaeological ruins of layered mud-brick walls above green Zarafshan valley, excavation trenches, poplars, warm morning haze, ${STYLE}` },
  { file: 'samarkand_silk_bazaar.png', prompt: `Ancient Silk Road bazaar in Samarkand, domed crossroad trading hall, merchants with silk bolts spices and Samarkand paper, shafts of light through dome openings, camels, ${STYLE}` },
  { file: 'samarkand_tilework.png', prompt: `Extreme close-up of Timurid cut-tile mosaic, geometric girikh patterns in cobalt turquoise gold and white, glazed brick banding, morning sun raking across surface, ${STYLE}` },
  // Bukhara
  { file: 'bukhara_kalyan_minaret.png', prompt: `Kalyan Minaret Bukhara, tall slender brick tower with decorative bands and lantern top, standing over ancient mosque courtyard, doves circling, desert afternoon, ${STYLE}` },
  { file: 'bukhara_samanid_mausoleum.png', prompt: `Samanid Mausoleum Bukhara, perfect cubic brick mausoleum with rounded dome, woven basket-pattern baked brick, soft golden light, ancient park trees, ${STYLE}` },
  { file: 'bukhara_ark.png', prompt: `The Ark citadel Bukhara, massive earthen fortress walls with grand entrance ramp and carved wooden gates, emirs' ancient seat, late afternoon desert light, ${STYLE}` },
  { file: 'bukhara_lyab_i_hauz.png', prompt: `Lyab-i Hauz pool Bukhara, ancient rectangular water tank framed by mulberry trees and madrasah porches, teahouse with painted ceiling, old men playing chess, ${STYLE}` },
  { file: 'bukhara_chor_minor.png', prompt: `Chor Minor Bukhara, whimsical gatehouse with four small turquoise-capped towers, blue tile inserts shaped as storks, quiet courtyard, morning, ${STYLE}` },
  { file: 'bukhara_trade_domes.png', prompt: `Domed trading arcades of old Bukhara, sixteenth-century stone crossing domes over narrow bazaar lanes, jewelers and silk merchants in lamplight, vaulted brick, ${STYLE}` },
  // Khiva
  { file: 'khiva_itchan_kala.png', prompt: `Itchan Kala Khiva at sunset, ten-metre crenellated mud-brick walls enclosing a forest of turquoise domes and minarets, desert horizon, warm ochre tones, ${STYLE}` },
  { file: 'khiva_juma_mosque.png', prompt: `Juma Mosque Khiva interior, forest of 213 carved wooden columns of varied age holding a low roof, shafts of light from three ceiling wells, worshippers' courtyard, ${STYLE}` },
  { file: 'khiva_islam_khoja.png', prompt: `Islam Khoja Minaret Khiva, tallest slender minaret with bands of glazed turquoise and white bricks, rising over old city rooftops against clear sky, ${STYLE}` },
  { file: 'khiva_kunya_ark.png', prompt: `Kunya-Ark citadel Khiva, khan's inner fortress with open-air throne hall of blue majolica, watchtower flag, courtyard gardens, desert light, ${STYLE}` },
  { file: 'khiva_tash_hauli.png', prompt: `Tash Hauli palace Khiva, ornate courtyard with carved wooden columns and vivid majolica peacock tiles, harem windows with lattice, warm shade, ${STYLE}` },
  { file: 'khiva_kalta_minor.png', prompt: `Kalta Minor Khiva, short thick tower completely covered in brilliant turquoise glazed bricks, scaffoldless unfinished top, base of madrasah, midday, ${STYLE}` },
  // Tashkent
  { file: 'tashkent_chorsu.png', prompt: `Chorsu Bazaar Tashkent, giant ribbed turquoise dome over bustling two-level bazaar, mountains of spices fruits and bread, blue tile madrasah nearby, ${STYLE}` },
  { file: 'tashkent_metro.png', prompt: `Tashkent metro station hall, marble columns with blue ceramic Uzbek ornament, crystal chandeliers, vaulted coffered ceiling, empty platform grandeur, ${STYLE}` },
  { file: 'tashkent_independence_square.png', prompt: `Independence Square Tashkent, monumental arch with storks, granite memorial, fountains and flower beds, cabinet building dome, clear morning, ${STYLE}` },
  { file: 'tashkent_mahalla.png', prompt: `Old Tashkent mahalla quarter, narrow adobe lanes with carved wooden gates, grape trellises over courtyards, laundry lines, tiled mosque dome beyond rooftops, ${STYLE}` },
  { file: 'tashkent_amir_timur_square.png', prompt: `Amir Timur Square Tashkent, bronze equestrian statue amid tall plane trees, ring of museums with domes, fountain, golden autumn light, ${STYLE}` },
  { file: 'tashkent_kukeldash.png', prompt: `Kukeldash Madrasah Tashkent, towering glazed-brick pishtaq portal over old city, crenellated walls, bazaar crowds below, blue sky, ${STYLE}` },
  // Shakhrisabz
  { file: 'shakhrisabz_ak_saray.png', prompt: `Ak-Saray gateway Shakhrisabz, colossal ruined portal pylon with mosaic of roaring tigers and ancient inscription band, towering against sky, wind-blown dust, ${STYLE}` },
  { file: 'shakhrisabz_dorus_saodat.png', prompt: `Dorus Saodat complex Shakhrisabz, unfinished massive empty mausoleum hall of brick, marble sarcophagus crypt beneath, broken dome open to sky, reverent light, ${STYLE}` },
  { file: 'shakhrisabz_kok_gumbaz.png', prompt: `Kok Gumbaz mosque Shakhrisabz, great blue dome above courtyard of carved columns, Timurid calligraphy band, doves, green foothills beyond, ${STYLE}` },
  // Termez
  { file: 'termez_buddhist_stupa.png', prompt: `Fayaz Tepe Buddhist monastery Termez, ancient clay stupa and monastery cells under desert sun, prayer niches, mountains of Afghanistan on horizon, ochre tones, ${STYLE}` },
  { file: 'termez_hakim_shrine.png', prompt: `Hakim al-Termizi mausoleum, elegant portal shrine with turquoise dome above the Amu Darya river bluff, pilgrims' ribbons, desert evening, ${STYLE}` },
  { file: 'termez_sultan_saodat.png', prompt: `Sultan Saodat necropolis Termez, avenue of unglazed brick portal mausoleums with ribbed domes, ancient sayyid cemetery, warm dusk light, ${STYLE}` },
];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function generateOne(zai, item, attempt = 1) {
  try {
    const res = await zai.images.generations.create({ prompt: item.prompt, size: '1344x768' });
    const b64 = res?.data?.[0]?.base64;
    if (!b64) throw new Error('empty response');
    const buf = Buffer.from(b64, 'base64');
    if (buf.length < 1000) throw new Error('suspiciously small image');
    fs.writeFileSync(path.join(OUT_DIR, item.file), buf);
    console.log(`[ok] ${item.file} (${Math.round(buf.length / 1024)} KB)`);
    return true;
  } catch (e) {
    console.error(`[fail ${attempt}] ${item.file}: ${String(e?.message ?? e).split('\n')[0]}`);
    if (attempt < 5) {
      const backoff = String(e?.message).includes('429') ? 12000 * attempt : 3000 * attempt;
      await sleep(backoff);
      return generateOne(zai, item, attempt + 1);
    }
    return false;
  }
}

async function main() {
  const zai = await ZAI.create();
  const todo = IMAGES.filter((i) => !fs.existsSync(path.join(OUT_DIR, i.file)));
  console.log(`gallery: ${IMAGES.length - todo.length} exist, ${todo.length} to generate`);
  let ok = 0;
  for (const item of todo) {
    const good = await generateOne(zai, item);
    if (good) ok++;
    await sleep(1500);
  }
  console.log(`gallery done: ${ok}/${todo.length} generated`);
}

main().catch((e) => {
  console.error('fatal', e);
  process.exit(1);
});
