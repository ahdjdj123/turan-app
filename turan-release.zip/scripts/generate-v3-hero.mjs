import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';

const OUT_DIR = path.resolve(process.cwd(), 'public/images/cities');
fs.mkdirSync(OUT_DIR, { recursive: true });

const STYLE =
  'museum-quality historical digital painting, cinematic lighting, rich detail, atmospheric, no text, no watermark, no modern logos';

const IMAGES = [
  {
    file: 'hero_panorama.png',
    size: '1440x704',
    prompt: `Breathtaking panoramic vista of Samarkand at sunrise, silhouette of majestic Timurid skyline with glowing turquoise-blue domes and slender minarets on the horizon, a Silk Road camel caravan crossing rolling golden desert dunes in the foreground, warm rose-gold dawn light bathing the sky in deep indigo above, epic cinematic composition, painterly detail, ${STYLE}`,
  },
  {
    file: 'menu_artifact_bg.png',
    size: '1024x1024',
    prompt: `Aged parchment manuscript texture background, warm cream ivory paper with subtle golden fiber grain, soft ink stains at edges, faint compass rose watermark in center, elegant antique feel, evenly lit flat texture, ${STYLE}`,
  },
];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function generateOne(zai, item, attempt = 1) {
  try {
    const res = await zai.images.generations.create({ prompt: item.prompt, size: item.size });
    const b64 = res?.data?.[0]?.base64;
    if (!b64) throw new Error('empty response');
    const buf = Buffer.from(b64, 'base64');
    if (buf.length < 1000) throw new Error('suspiciously small image');
    fs.writeFileSync(path.join(OUT_DIR, item.file), buf);
    console.log(`[ok] ${item.file} (${Math.round(buf.length / 1024)} KB)`);
    return true;
  } catch (e) {
    console.error(`[fail ${attempt}] ${item.file}: ${e.message.split('\n')[0]}`);
    if (attempt < 4) {
      const backoff = e.message.includes('429') ? 12000 * attempt : 3000 * attempt;
      await sleep(backoff);
      return generateOne(zai, item, attempt + 1);
    }
    return false;
  }
}

const only = process.argv[2] ? process.argv[2].split(',') : null;
const list = only ? IMAGES.filter((i) => only.includes(i.file)) : IMAGES;

(async () => {
  const zai = await ZAI.create();
  for (const item of list) {
    if (fs.existsSync(path.join(OUT_DIR, item.file))) {
      console.log(`[skip] ${item.file} exists`);
      continue;
    }
    await generateOne(zai, item);
    await sleep(1200);
  }
  console.log('DONE');
})();
