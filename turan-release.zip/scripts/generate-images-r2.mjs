import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';

const OUT_DIR = path.resolve(process.cwd(), 'public/images/cities');
fs.mkdirSync(OUT_DIR, { recursive: true });

const STYLE =
  'museum-quality historical digital painting, cinematic lighting, rich detail, atmospheric, no text, no watermark, no modern logos';

const IMAGES = [
  { file: 'shakhrisabz_ancient.png', prompt: `Ancient Sogdian city of Kesh (Shakhrisabz), green terraced foothills with mud-brick fortress, horsemen on mountain roads, Central Asian antiquity, terracotta tones, ${STYLE}` },
  { file: 'shakhrisabz_islamic.png', prompt: `Early Islamic Kesh (Shakhrisabz), star-pattern brickwork gateway, Friday mosque and caravans in green oasis below mountains, warm light, ${STYLE}` },
  { file: 'shakhrisabz_soviet.png', prompt: `Soviet-era Shakhrisabz, cotton fields and tractors below crumbling Timurid palace ruins, conservation scaffolding, muted nostalgic tones, ${STYLE}` },
  { file: 'shakhrisabz_modern.png', prompt: `Modern Shakhrisabz Uzbekistan, colossal Ak-Saray gate ruins towering over tidy green city, flowers and celebration flags, photorealistic travel photography, ${STYLE}` },
  { file: 'termez_islamic.png', prompt: `Medieval Islamic Termez, fluted domes of Sultan Saodat necropolis, citadel above the Amu Darya river, caravans and garrison, warm dusk, ${STYLE}` },
  { file: 'termez_modern.png', prompt: `Modern Termez Uzbekistan, Friendship Bridge over Amu Darya at sunset, archaeological park with Buddhist stupa, warm river light, photorealistic, ${STYLE}` },
  { file: 'tashkent_islamic.png', prompt: `Medieval Qarakhanid Tashkent, Kukeldash madrasah towering over domed Chorsu bazaar, merchants and blue tiles, golden hour, ${STYLE}` },
  { file: 'tashkent_timurid.png', prompt: `Timurid-era Tashkent, walled city with gardens and shrines of Sheikhantaur, mounted couriers departing, warm evening light, ${STYLE}` },
  { file: 'karshi_ancient.png', prompt: `Ancient Sogdian Nakhshab (Karshi), citadel by the Kashka Darya river, melon fields and caravans, Zoroastrian fire shrine, warm terracotta, ${STYLE}` },
  { file: 'karshi_modern.png', prompt: `Modern Karshi Uzbekistan, renovated riverfront park with ancient ten-arch Timurid bridge, families strolling, photorealistic, ${STYLE}` },
  { file: 'margilan_ancient.png', prompt: `Ancient Margilan, mulberry groves and silk caravans, legend of princess with silkworm eggs in bridal headdress, Fergana valley oasis, warm tones, ${STYLE}` },
  { file: 'margilan_islamic.png', prompt: `Medieval Margilan silk bazaar, vivid ikat atlas fabrics in rainbow blur patterns, dyers at indigo vats, Said Akhmad-khoja madrasah, ${STYLE}` },
  { file: 'kokand_modern.png', prompt: `Modern Kokand Uzbekistan, restored Khudayar Khan palace with majolica facade, craft workshops and film festival banners, photorealistic, ${STYLE}` },
  { file: 'andijan_timurid.png', prompt: `Timurid-era Andijan, young prince Babur in the citadel garden with pomegranate trees, valley bazaars beyond, golden light, ${STYLE}` },
  { file: 'andijan_modern.png', prompt: `Modern Andijan Uzbekistan, Babur memorial park with fountains, bustling bazaars and devouring crowds, photorealistic travel photography, ${STYLE}` },
  { file: 'navoi_modern.png', prompt: `Modern Navoi Uzbekistan, industrial skyline with mining facilities and golden desert, poet Alisher Navoi monument in rose garden, dusk, photorealistic, ${STYLE}` },
  { file: 'jizzakh_modern.png', prompt: `Modern Jizzakh Uzbekistan, special economic zone factories and green boulevards, Zaamin juniper mountains on horizon, photorealistic, ${STYLE}` },
  { file: 'nukus_modern.png', prompt: `Modern Nukus Karakalpakstan, Savitsky art museum facade, ship graveyard of Moynaq on the horizon, resilient desert city, warm light, ${STYLE}` },
  { file: 'fergana_modern.png', prompt: `Modern Fergana Uzbekistan, leafy plane-tree boulevards, Russian-colonial architecture and university students, green valley city, photorealistic, ${STYLE}` },
  { file: 'gulistan_modern.png', prompt: `Modern Gulistan Uzbekistan, flower-garden city squares and regional theater, canal with poplars in former Hungry Steppe, photorealistic, ${STYLE}` },
  { file: 'urgench_modern.png', prompt: `Modern Urgench Uzbekistan, bright aviation city with plane trees, gateway roads toward ancient Khorezm ruins, photorealistic, ${STYLE}` },
  { file: 'khiva_khanates.png', prompt: `Khanate-era Khiva, Islam Khoja minaret towering over Itchan Kala, khan's procession with horsemen, Tash Hauli palace tiles, desert light, ${STYLE}` },
  { file: 'bukhara_khanates.png', prompt: `Khanate-era Bukhara, Emir's procession before the Ark citadel, Chor Minor gatehouse, gold embroidery bazaar, warm evening, ${STYLE}` },
  { file: 'khiva_timurid.png', prompt: `Timurid-era Khiva, Said Alauddin mausoleum with turquoise tile dome, oasis town recovering beside desert, soft morning light, ${STYLE}` },
];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function generateOne(zai, item, attempt = 1) {
  try {
    const res = await zai.images.generations.create({ prompt: item.prompt, size: '1344x768' });
    const b64 = res?.data?.[0]?.base64;
    if (!b64) throw new Error('empty response');
    const buf = Buffer.from(b64, 'base64');
    if (buf.length < 1000) throw new Error('suspiciously small image');
    fs.writeFileSync(path.join(OUT_DIR, item.file), buf);
    console.log(`[ok] ${item.file} (${Math.round(buf.length / 1024)} KB)`);
    return true;
  } catch (e) {
    console.error(`[fail ${attempt}] ${item.file}: ${e.message.split('\n')[0]}`);
    if (attempt < 5) {
      const backoff = e.message.includes('429') ? 12000 * attempt : 3000 * attempt;
      await sleep(backoff);
      return generateOne(zai, item, attempt + 1);
    }
    return false;
  }
}

async function main() {
  const zai = await ZAI.create();
  const pending = IMAGES.filter((i) => {
    const p = path.join(OUT_DIR, i.file);
    if (fs.existsSync(p) && fs.statSync(p).size > 1000) {
      console.log(`[skip] ${i.file} exists`);
      return false;
    }
    return true;
  });
  console.log(`Round 2: generating ${pending.length} images -> ${OUT_DIR}`);
  let idx = 0;
  let ok = 0;
  async function worker() {
    while (idx < pending.length) {
      const item = pending[idx++];
      const success = await generateOne(zai, item);
      if (success) ok++;
      await sleep(2500);
    }
  }
  await Promise.all(Array.from({ length: 1 }, worker));
  console.log(`DONE: ${ok}/${pending.length} generated`);
}

main().catch((e) => {
  console.error('FATAL', e);
  process.exit(1);
});
