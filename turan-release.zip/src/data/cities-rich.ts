import type { EraId } from './eras';

/**
 * TURAN rich-content layer — the deep museum exhibition behind every city.
 * Merged over the base entries in cities.ts. Anything omitted gracefully
 * falls back to the base description / fact.
 */

export interface Figure {
  name: string;
  years?: string;
  role: string;
  bio: string;
}

export interface EraEvent {
  year: string;
  text: string;
}

export interface GalleryItem {
  /** file under /images/cities/gallery/<src>.png */
  src: string;
  title: string;
  year?: string;
  caption: string;
  /** eras where this view is historically apt; omit = always */
  eras?: EraId[];
}

export interface RichEra {
  /** long-form exhibition paragraphs (THE STORY) */
  story?: string[];
  figures?: Figure[];
  events?: EraEvent[];
  /** extra did-you-know cards beyond the base fact */
  facts?: string[];
  sources?: string[];
  /** era-specific gallery additions */
  gallery?: GalleryItem[];
}

export interface RichCity {
  region: string;
  /** short museum-label lines shown "at a glance" */
  highlights: string[];
  /** landmark photography available across eras */
  gallery?: GalleryItem[];
  eras: Partial<Record<EraId, RichEra>>;
}

export const RICH: Record<string, RichCity> = {
  /* ---------------------------------------------------------------- */
  samarkand: {
    region: 'Zarafshan Valley',
    highlights: [
      'Capital of the Timurid Empire',
      'Home of Ulugh Beg’s Observatory',
      'Silk Road crossroads of Asia',
      'UNESCO World Heritage since 2001',
    ],
    gallery: [
      { src: 'samarkand_registan', title: 'Registan Square', year: 'c. 1420–1660', caption: 'Three marble-and-tile madrasahs framing the ceremonial heart of Central Asia.' },
      { src: 'samarkand_bibi_khanym', title: 'Bibi-Khanym Mosque', year: '1404', caption: 'Timur’s colossal Friday mosque, raised from the spoils of five campaigns.' },
      { src: 'samarkand_shah_i_zinda', title: 'Shah-i-Zinda', year: '11th–15th c.', caption: 'A avenue of jewelled mausoleums climbing toward the grave of Qusam ibn Abbas.' },
      { src: 'samarkand_gur_e_amir', title: 'Gur-e Amir', year: '1404', caption: 'The ribbed turquoise dome beneath which Timur and his dynasty rest.' },
      { src: 'samarkand_observatory', title: 'Ulugh Beg Observatory', year: '1420s', caption: 'A forty-metre marble sextant sunk into the hill — the largest of its age.' },
      { src: 'samarkand_afrasiab', title: 'Afrasiab Mound', year: '7th c. BCE – 1220', caption: 'The layered ruins of pre-Mongol Maracanda above the Zarafshan floodplain.' },
      { src: 'samarkand_silk_bazaar', title: 'Silk Road Bazaar', caption: 'Merchants of silk, spice and paper beneath the spreading elms.' },
      { src: 'samarkand_tilework', title: 'Timurid Tilework', caption: 'Cut-tile mosaics and gold leaf — the empire’s signature azure and gold.' },
    ],
    eras: {
      ancient: {
        story: [
          'Long before its turquoise domes, Samarkand was Maracanda — the fortified capital of Sogdiana, raised on the loess cliff of Afrasiab above the Zarafshan river. Its fire temples glowed over orchards and irrigation canals fed by snows from the Pamirs.',
          'Sogdian merchants made the city a hinge between Persia, India and the nomadic steppe. Caravans traded lapis from Badakhshan, horses from the Fergana valley and Chinese silk a century before Rome knew what silk was.',
          'Alexander the Great seized Maracanda in 329 BCE and never forgot it. The city burned in revolt, rose again, and remained for centuries the prize every empire marching through Transoxiana had to take.',
        ],
        figures: [
          { name: 'Alexander the Great', years: '356–323 BCE', role: 'Conqueror of Maracanda', bio: 'Took the city in 329 BCE, married the Sogdian princess Roxana, and introduced Greek administration to the Zarafshan valley.' },
          { name: 'Spitamenes', years: 'd. 328 BCE', role: 'Sogdian warlord', bio: 'Led the fiercest guerrilla resistance Alexander faced anywhere, raiding Maracanda’s surroundings for three years before his own allies betrayed him.' },
          { name: 'Roxana', years: 'c. 340–310 BCE', role: 'Sogdian princess', bio: 'Daughter of the Balkh-aligned baron Oxyartes; her marriage to Alexander briefly tied Bactria to Macedonia.' },
        ],
        events: [
          { year: 'c. 742 BCE', text: 'First settlement on the Afrasiab mound — Maracanda is among the world’s oldest continuously inhabited cities.' },
          { year: '329 BCE', text: 'Alexander occupies Maracanda after crossing the Oxus; Sogdian revolt ignites behind him.' },
          { year: '328 BCE', text: 'Spitamenes’ cavalry destroys a Macedonian detachment at the walls of Maracanda — Alexander’s worst field defeat in Asia.' },
          { year: 'c. 305 BCE', text: 'The city passes to the Seleucid empire, then to Greco-Bactrian kings.' },
        ],
        facts: [
          'Afrasiab’s 7th-century wall paintings show envoys from Korea, China and Persia — proof the city hosted ambassadors from three oceans.',
          'The name "Maracanda" appears in Zoroastrian texts as one of the twelve ideal cities created by Ahura Mazda.',
        ],
        sources: ['UNESCO World Heritage Dossier №603rev', 'British Museum — Afrasiab Collection', 'V. Livshits, Sogdian Epigraphy'],
      },
      islamic: {
        story: [
          'When Arab armies crossed the Oxus in the 7th century, Samarkand became the eastern jewel of the Islamic world. Around 751, paper-makers captured at the Battle of Talas refined their secret here — and Samarkand paper, smooth and strong, carried the written word west toward Baghdad and east across Asia.',
          'Under the Samanids of Bukhara the city filled with madrasahs, caravanserais and the first great brick mosques. Astronomers worked the tables that al-Khwarizmi’s mathematics made possible; physicians compiled pharmacologies still copied in Cairo.',
          'In 1220 the Mongol storm erased it all in a morning. Genghis Khan’s cavalry flattened the walls, drowned the scholars and burned the paper mills — but the aqueducts and orchards meant the city would rise a third time.',
        ],
        figures: [
          { name: 'Qutayba ibn Muslim', years: '669–715', role: 'Umayyad general', bio: 'Took Samarkand in 712 and built its first great mosque — planting Islam permanently in Transoxiana.' },
          { name: 'Ahmad al-Farghani', years: 'c. 800–870', role: 'Astronomer (Alfraganus)', bio: 'From the Fergana valley, his "Elements of Astronomy" was taught in Europe for 700 years; a lunar crater bears his latinized name.' },
        ],
        events: [
          { year: '712', text: 'Qutayba ibn Muslim captures Samarkand; the first mosque rises beside the fire temple.' },
          { year: '751', text: 'Chinese paper-makers taken at Talas establish Samarkand’s first paper mills — the secret of paper reaches the West.' },
          { year: '819–999', text: 'Samanid century: Samarkand flourishes as the eastern capital of Persian-Islamic civilization.' },
          { year: '1220', text: 'Genghis Khan sacks the city; the aqueduct is cut and Afrasiab abandoned forever.' },
        ],
        facts: [
          'Samarkand paper was watermarked with the city’s own name — medieval Europe called the finest sheets "samarquandi".',
          'The 10th-century geographer al-Istakhri ranked Samarkand’s bazaar among the wonders of Islam, second only to Baghdad.',
        ],
        sources: ['UNESCO Dossier №603rev', 'R. Bulliet, Paper Before Print', 'al-Istakhri, Book of Climates'],
      },
      timurid: {
        story: [
          'In 1370 Timur (Tamerlane) declared Samarkand the capital of a world empire — then spent thirty-five years shipping the architects, glassmakers, tile-cutters and mathematicians of every conquered land home to adorn it. "Let no one think of our city as small," he proclaimed, "for we have made it the navel of the earth."',
          'The result was a skyline without equal: the Bibi-Khanym mosque raised in a single decade, the Shah-i-Zinda necropolis rebuilt as an avenue of jewelled tombs, and the Registan square anchoring a university city where his grandson Ulugh Beg measured 1,018 stars with a sextant sunk forty metres into a hillside.',
          'Timurid Samarkand was not only monumental — it was a scientific capital. Ulugh Beg’s Zij-i Sultani star catalogue out-precised Ptolemy and remained the reference of Asia for two centuries; his university taught astronomy, medicine and philosophy to thousands from the Mediterranean to the Great Wall.',
        ],
        figures: [
          { name: 'Timur (Tamerlane)', years: '1336–1405', role: 'Emir, founder of the empire', bio: 'Rose from Barlas noble to ruler of an empire from Delhi to Damascus; buried beneath the ribbed dome of Gur-e Amir.' },
          { name: 'Ulugh Beg', years: '1394–1449', role: 'Astronomer-king', bio: 'Timur’s grandson — ruler, mathematician and the greatest observational astronomer of his age, murdered on a court intrigue after his observatory measured the year to within 25 seconds.' },
          { name: 'Bibi-Khanym', years: 'd. 1395', role: 'Empress', bio: 'Timur’s beloved Chinese-princess consort (in legend), memorialized by the largest mosque of its century.' },
          { name: 'Ali Kushji', years: 'c. 1403–1474', role: 'Mathematician', bio: 'Ulugh Beg’s chief astronomer who carried the Samarkand tables to Istanbul after the dynasty fell, seeding Ottoman science.' },
        ],
        events: [
          { year: '1370', text: 'Timur proclaims Samarkand capital of his empire at a kurultai on the Nazar Shah meadow.' },
          { year: '1399–1404', text: 'The Bibi-Khanym mosque rises in five years — then cracks under its own ambition within a generation.' },
          { year: '1404', text: 'Clavijo, ambassador of Castile, marvels at "an empire of architects" and records the city street by street.' },
          { year: '1420', text: 'Ulugh Beg opens his madrasah on the Registan — a university where 60–70,000 students once studied.' },
          { year: '1428', text: 'The great observatory completes; the Zij-i Sultani catalogue follows nine years later.' },
          { year: '1449', text: 'Ulugh Beg is assassinated on his son’s order; the golden age dims as the empire fragments.' },
        ],
        facts: [
          'Legend says a curse on Timur’s tomb preceded every invasion of Russia — his remains were exhumed by Soviet archaeologists three days before Hitler crossed the border in 1941.',
          'The Registan’s portal minarets lean by design — Timurid engineers angled them outward so collapse (if ever) would fall away from the madrasah.',
        ],
        sources: ['R. Grousset, The Empire of the Steppes', 'Clavijo, Embassy to Tamerlane (1403–6)', 'E. Krachkovskaya, Ulugbek Observatory Studies'],
      },
      soviet: {
        story: [
          'The Russian railway reached the Zarafshan in 1888, and tsarist Samarkand grew a European city of boulevards, banks and garrison churches beside the ancient one. In 1925 the young Uzbek SSR chose it as capital — a title held only until 1930, when Tashkent took the seat.',
          'Soviet decades brought trams, textile mills, the Navoi Theatre and the first faculty of Uzbekistan State University — while archaeologists quietly peeled Afrasiab’s layers and conservators propped the crumbling madrasahs. War-time evacuation filled its halls with the Hermitage’s treasures.',
        ],
        figures: [
          { name: 'Mikhail Masson', years: '1897–1986', role: 'Archaeologist', bio: 'Father of Central Asian archaeology; excavated Afrasiab and Gur-e Amir and saved Timurid monuments from collapse.' },
        ],
        events: [
          { year: '1888', text: 'The Trans-Caspian railway arrives; Samarkand links to the Caspian and to Moscow.' },
          { year: '1925', text: 'Samarkand becomes first capital of the Uzbek SSR.' },
          { year: '1930', text: 'Capital moves to Tashkent; Samarkand turns to universities and museums.' },
          { year: '1941–45', text: 'Hermitage masterpieces shelter in Samarkand institutions during the Great Patriotic War.' },
        ],
        facts: ['The 1941–45 Hermitage evacuation stored Rembrandts and Scythian gold in the Registan’s madrasah cells — the square became a bank vault of world art.'],
        sources: ['State Archive of Samarkand Region', 'M. Masson, Selected Works'],
      },
      modern: {
        story: [
          'Independent Uzbekistan restored Timurid Samarkand into a world stage: the Registan glows under floodlights, the Gur-e Amir’s dome was regilded, and the Shah-i-Zinda’s tiles re-fired by Herat-trained masters. In 2001 UNESCO inscribed the city as a "Crossroads of Cultures".',
          'Today a high-speed Afrosiyob train links Samarkand to Tashkent in two hours, the new Silk Road Samarkand congress quarter hosts world leaders, and craft streets weave silk paper and carve doors within sight of fourteenth-century walls.',
        ],
        events: [
          { year: '1991', text: 'Independence — restoration of the monumental core begins.' },
          { year: '2001', text: 'UNESCO inscribes Samarkand as World Heritage ("Crossroads of Cultures").' },
          { year: '2022', text: 'Silk Road Samarkand international tourist centre opens on eight themed pavilions.' },
        ],
        facts: ['The Afrosiyob high-speed train is named for the ancient mound beneath the city — modern speed honouring the oldest layer.'],
        sources: ['UNESCO Listing №603rev', 'Silk Road Samarkand Congress Centre archives'],
      },
    },
  },

  /* ---------------------------------------------------------------- */
  bukhara: {
    region: 'Kyzylkum Oasis',
    highlights: [
      'Capital of the Samanid Empire',
      '“Dome of Islam” — 140+ monuments',
      'Avicenna’s city of learning',
      'UNESCO World Heritage since 1993',
    ],
    gallery: [
      { src: 'bukhara_kalyan_minaret', title: 'Kalyan Minaret', year: '1127', caption: 'The "Tower of Death" — 47 metres of woven brick that even Genghis Khan spared.' },
      { src: 'bukhara_samanid_mausoleum', title: 'Samanid Mausoleum', year: 'c. 905', caption: 'The perfect cube-and-dome — oldest surviving Islamic monument in Central Asia.' },
      { src: 'bukhara_ark', title: 'The Ark Citadel', year: '5th c. – 1920', caption: 'A fortress-city within the city, seat of emirs for fifteen centuries.' },
      { src: 'bukhara_lyab_i_hauz', title: 'Lyab-i Hauz', year: '1620', caption: 'The pool of mulberries, teahouses and Nasreddin riding his donkey backwards.' },
      { src: 'bukhara_chor_minor', title: 'Chor Minor', year: '1807', caption: 'Four towers, one riddle — the gatehouse unlike anything else in the old town.' },
      { src: 'bukhara_trade_domes', title: 'Trading Domes', year: '16th c.', caption: 'Six stone domes over crossroad bazaars where silk was weighed against silver.' },
    ],
    eras: {
      ancient: {
        story: [
          'Bukhara rose from the edge of the Kyzylkum as a Sogdian trading post where caravans watered before the great desert crossings. Its citadel — the Ark — counted dynasties like sand grains in an hourglass.',
          'Zoroastrian fire temples and a famous moon temple drew pilgrims from across Iran; the oasis grew so wealthy that its coinage circulated to the Baltic, where hoards of Bukharan drachms have been unearthed in Viking burials.',
        ],
        figures: [
          { name: 'Bikinit of the Al-Afshin line', years: '7th c.', role: 'Sogdian dihqan', bio: 'Ruling lady of the Bukhar Khudat dynasty whose silver coins picture a crowned goddess on a lion throne.' },
        ],
        events: [
          { year: 'c. 500 BCE', text: 'First fortress on the Shahristan hill — the seed of the Ark.' },
          { year: 'c. 100 CE', text: 'Bukharan silver drachms circulate from China to the Baltic.' },
          { year: '604', text: 'Turkic khaganate takes the oasis; Bukhara’s ruling house pays tribute in silver.' },
        ],
        facts: ['Viking hoards found in Sweden contain Bukharan coins — Silk Road silver reached Scandinavia a thousand years before IKEA.'],
        sources: ['UNESCO Dossier №601', 'R. Frye, Bukhara: The Medieval Achievement'],
      },
      islamic: {
        story: [
          'In the 9th and 10th centuries Bukhara was the Samanid capital and one of the great minds of Islam. Avicenna read philosophy in its royal library — a stack of rooms whose catalogue, he said, he had never seen surpassed. Al-Khwarizmi’s algebra and al-Biruni’s horizons were formed in this orbit.',
          'The city became known as "Bukhoro-i-Sharif", Noble Bukhara: a landscape of minarets, domed bazaars and madrasahs whose baked-brick geometry still puzzles engineers. The Samanid Mausoleum — a perfect cube crowned by a dome of woven brick — announced an architecture the world had never seen.',
          'In 1220 Genghis Khan burned Bukhara in three days. The Kalyan Minaret alone he spared, awed — the chronicles say — by its audacity.',
        ],
        figures: [
          { name: 'Avicenna (Ibn Sina)', years: '980–1037', role: 'Physician-philosopher', bio: 'Read the Samanid library to exhaustion at sixteen; his "Canon of Medicine" taught Europe for six centuries.' },
          { name: 'Bal’ami', years: 'd. 974', role: 'Vizier-historian', bio: 'Translated al-Tabari’s world history into Persian, creating Persian historical prose.' },
          { name: 'Rudaki', years: '858–941', role: 'Father of Persian poetry', bio: 'Blind bard of the Samanid court whose verses opened Persian literature’s golden age.' },
        ],
        events: [
          { year: '819', text: 'The Samanids take Bukhara and make it capital of Transoxiana.' },
          { year: 'c. 905', text: 'The Samanid Mausoleum rises — the dawn of Islamic brick architecture.' },
          { year: '1127', text: 'The Kalyan Minaret completed under Arslan Khan; forty metres of brick that never leaned.' },
          { year: '1220', text: 'Genghis Khan burns the city; only the minaret stands untouched.' },
        ],
        facts: [
          'The Kalyan Minaret’s nickname "Tower of Death" comes from executions by rooftop — yet its depth of foundation (ten metres) is why it still stands after nine earthquakes.',
          'Avicenna claimed the royal library’s hall of medicine alone held more books than all of Rayy.',
        ],
        sources: ['UNESCO Dossier №601', 'W. Barthold, Turkestan Down to the Mongol Invasion', 'Ibn Sina autobiography (Gohlman ed.)'],
      },
      timurid: {
        story: [
          'Under Timur and his successors Bukhara thrived as Samarkand’s scholarly twin — a city of madrasahs, astronomical tables and covered bazaars. Ulugh Beg himself raised a madrasah here in 1417, its portal proclaiming: "The pursuit of knowledge is a duty on every Muslim."',
          'Timurid Bukhara perfected the domed bazaar: six stone crossings where caps, silks, coins and books each had their own market under a single cupola — an urban invention later copied from Istanbul to Isfahan.',
        ],
        figures: [
          { name: 'Ulugh Beg (as patron)', years: '1394–1449', role: 'Astronomer-king', bio: 'Built the Bukhara madrasah of 1417 — his inscription made learning a religious duty.' },
        ],
        events: [
          { year: '1417', text: 'Ulugh Beg’s madrasah rises — his only building outside Samarkand’s orbit.' },
          { year: 'c. 1450–1500', text: 'The trading domes (Toki) replace open stalls with climate-proof stone bazaars.' },
        ],
        facts: ['The Toki Zargaron dome still carries hooks where jewellers hung their scales — visitors can see the nail-holes worn smooth by centuries of weights.'],
        sources: ['UNESCO Dossier №601', 'S. Adle, Timurid Bukhara studies'],
      },
      khanates: {
        story: [
          'From the Sheibanids through the Manghit emirs, Bukhara ruled a khanate stretching to the Pamirs. Ambassadors, spies and runaway poets all passed its gates; the bazaars sold Russian cotton, Kashmiri shawls and gold embroidery fit for tsars.',
          'It was also a city of holy men and hard power: dervish lodges ringed the walls while the emir’s dungeons lay beneath his throne. When the poet-philosopher Ahmad Donish begged the emir to send students to study St Petersburg’s arsenals, he was refused — a moment Uzbek historians mark as the hinge of the khanate’s fate.',
        ],
        figures: [
          { name: 'Abdullah Khan II', years: '1533–1598', role: 'Sheibanid khan', bio: 'Built the trading domes, Kosh Madrasah and a network of caravanserais that made Bukhara the warehouse of Asia.' },
          { name: 'Ahmad Donish', years: '1827–1897', role: 'Polymath', bio: 'Court scribe, miniaturist and reformer whose reports on Russia warned the emirate it had fallen behind — advice ignored until too late.' },
          { name: 'Emir Alim Khan', years: '1880–1944', role: 'Last Manghit emir', bio: 'Ruled 1910–1920; fled to Afghanistan as Red artillery cracked the Ark, carrying treasures never fully accounted for.' },
        ],
        events: [
          { year: '1500–1599', text: 'Sheibanid century — Bukhara rebuilt as capital of a Uzbek dynasty.' },
          { year: '1561', text: 'Abdullah Khan II makes Bukhara the permanent capital; the trading domes rise.' },
          { year: '1868', text: 'Bukhara becomes a Russian protectorate after defeat at Zerabulak.' },
          { year: '1887', text: 'Ahmad Donish publishes his "Rare Occurrences" urging modernization.' },
          { year: '1920', text: 'Red Army storms the city; the emirate falls after four centuries.' },
        ],
        facts: [
          'When the Emir of Bukhara travelled, a hundred horsemen carried spare silversmith shops with him — goldwork was worn like armour.',
          'Chor Minor’s four towers may represent four dynasties or four prayers — its true purpose is a riddle its builder took to the grave.',
        ],
        sources: ['A. Donish, Rare Occurrences', 'R. Abashin, Russian Colonial Society in Turkestan'],
      },
      soviet: {
        story: [
          'Bukhara fell to the Bolsheviks in 1920 when Red artillery cracked the Ark and fire swept the old town. Out of the embers, Soviet conservators made it an open-air museum: the first Central Asian restoration workshops stabilized minarets, mausoleums and pools block by block.',
          'Collectivization and the anti-religion campaigns emptied the madrasahs, but the brick skeleton survived — a paradox Soviet guides explained as "feudal architecture preserved by socialist science".',
        ],
        figures: [
          { name: 'Fayzulla Khujayev', years: '1896–1938', role: 'Revolutionary statesman', bio: 'Bukharan jalil of the Young Bukharans, first chairman of the Soviet republic — purged in Stalin’s terror, rehabilitated in 1966.' },
        ],
        events: [
          { year: '1920', text: 'The Bukharan People’s Soviet Republic proclaimed after the siege.' },
          { year: '1924', text: 'The Bukharan SSR dissolved into the Uzbek SSR; Bukhara becomes an oblast city.' },
          { year: '1930s–80s', text: 'Restoration school saves the Kalyan ensemble, Samanid Mausoleum and Ark.' },
        ],
        facts: ['In 1920 the emir fled on horseback with the Peacock Throne gems — some surfaced in London auction houses decades later, most never resurfaced.'],
        sources: ['Soviet Restoration Archive, Bukhara Museum Reserve'],
      },
      modern: {
        story: [
          'UNESCO inscribed Historic Bukhara in 1993: over two hundred monuments — madrasahs, minarets, caravanserais and pools — packed into a living old town where coppersmiths hammer brass a street away from the Samanid dead.',
          'Independent restoration re-fired the domes’ turquoise and reopened the caravanserais as craft ateliers. Each spring the Silk & Spices festival fills the walls with ikat, gold embroidery and folk theatre.',
        ],
        events: [
          { year: '1993', text: 'UNESCO World Heritage inscription for the Historic Centre of Bukhara.' },
          { year: '1997', text: '2,500th anniversary celebrations — city core fully restored.' },
          { year: '2017', text: 'Bukhara State Architectural Art Museum expands into nine monument complexes.' },
        ],
        facts: ['More than 140 architectural monuments stand inside Bukhara’s old town — a density almost unmatched anywhere on Earth.'],
        sources: ['UNESCO Dossier №601'],
      },
    },
  },

  /* ---------------------------------------------------------------- */
  khiva: {
    region: 'Khorezm Oasis',
    highlights: [
      'Itchan Kala — a whole city inside one wall',
      'Islam Khoja Minaret, 57 m — tallest in Uzbekistan',
      'Capital of the Khiva Khanate (1511–1920)',
      'UNESCO World Heritage since 1990',
    ],
    gallery: [
      { src: 'khiva_itchan_kala', title: 'Itchan Kala Walls', year: '10th–18th c.', caption: 'Ten metres of dried brick enclosing fifty monuments — a city that is one museum.' },
      { src: 'khiva_juma_mosque', title: 'Juma Mosque', year: '10th–18th c.', caption: '213 carved wooden columns holding up a low, cool roof of whispering shade.' },
      { src: 'khiva_islam_khoja', title: 'Islam Khoja Minaret', year: '1910', caption: 'Fifty-seven metres of glazed bands — a rocket of turquoise over the old city.' },
      { src: 'khiva_kunya_ark', title: 'Kunya-Ark', year: '1686–1804', caption: 'The khans’ fortress-within-a-fortress: throne room, harem, mint and lookout.' },
      { src: 'khiva_tash_hauli', title: 'Tash Hauli Palace', year: '1832–1841', caption: '150 rooms wrapped around courtyards of majolica peacocks.' },
      { src: 'khiva_kalta_minor', title: 'Kalta Minor', year: '1855', caption: 'The unfinished turquoise tower — meant to be the tallest, ended at 29 metres.' },
    ],
    eras: {
      ancient: {
        story: [
          'In the ancient delta of the Amu Darya, Khorezm grew rich on irrigation canals older than Rome. Tradition says Shem, son of Noah, founded a well here — "Kheyvah" — and pilgrims drank from it for two thousand years.',
          'Khorezmian astronomers calculated the solar year with astonishing precision; their desert watchtowers — hundreds of mud-brick qalas — stood guard over fields the rivers have since abandoned.',
        ],
        figures: [
          { name: 'Beruni of Khwarezm', years: '973–1048', role: 'Universal scholar', bio: 'Measured the Earth’s radius at Kath, catalogued India’s sciences, and debated Avicenna on physics by letter.' },
        ],
        events: [
          { year: 'c. 1000 BCE', text: 'Canal irrigation begins in the Amu Darya delta — the Khorezmian oasis is born.' },
          { year: 'c. 400 BCE', text: 'Fortified qala towers ring the delta caravan roads.' },
          { year: '305–995', text: 'The Afrighid dynasty rules Khorezm from its delta capital.' },
        ],
        facts: ['Khorezmian astronomer tables were so accurate that Beruni computed the steppe city of Kath’s latitude within a twentieth of a degree.'],
        sources: ['B. Vainberg, Khorezm Coinage', 'al-Biruni, Chronology of Ancient Nations'],
      },
      islamic: {
        story: [
          'Medieval Khiva grew into a walled ark of Islamic craft and learning. Inside Itchan Kala, the Juma Mosque was held up by a forest of carved columns — some reclaimed from 10th-century mosques — while scholars drew maps of the world from Khorezmian tables.',
          'The oasis capital Gurganj (Urgench) outshone Khiva for centuries — until the Mongols drowned its people by breaking the Amu Darya dams. Khiva quietly inherited the dying city’s trade and shrines.',
        ],
        figures: [
          { name: 'al-Khwarizmi (tradition)', years: 'c. 780–850', role: 'Mathematician', bio: 'The Khorezmian whose algebra (al-jabr) and logarithm of the sine gave Europe its mathematical vocabulary — his very name became "algorithm".' },
        ],
        events: [
          { year: '10th c.', text: 'The Juma Mosque rises on reused carved columns; Khiva becomes a shrine town.' },
          { year: '1221', text: 'Mongols flood Gurganj; Khorezm’s old capital drowns in weeks.' },
        ],
        facts: ['Some Juma columns were recycled from earlier buildings — dendrochronology dates the oldest to the 10th century.'],
        sources: ['UNESCO Dossier №543', 'Itchan Kala Museum Reserve archives'],
      },
      timurid: {
        story: [
          'Khorezm passed between the Golden Horde and Timur’s empire. Its great capital Gurganj was sacked in 1388 and its artisans marched to Samarkand; Khiva kept the oasis’s shrines and crafts alive in their shadow.',
        ],
        figures: [
          { name: 'Husayn Sufi', years: 'd. 1372', role: 'Sufi emir of Khorezm', bio: 'Founder of the Sufi dynasty that defied Timur for a generation from the walls of Gurganj.' },
        ],
        events: [
          { year: '1359', text: 'The Sufi dynasty takes Khorezm from the Golden Horde.' },
          { year: '1388', text: 'Timur storms Gurganj a fifth and final time; the population is deported to Samarkand.' },
        ],
        facts: ['Timur reportedly had Gurganj’s minaret of "Kutlug Timur" spared for target practice — the 60-metre brick tower still leans 1.5 degrees today.'],
        sources: ['Sharaf al-Din Ali Yazdi, Zafarnama'],
      },
      khanates: {
        story: [
          'From 1511 Khiva ruled its own khanate — a state of irrigators, slave-raiders, poets and treaty-makers on the edge of empires. Russian officers, British spies and American travellers all left accounts of its blue-tiled walls.',
          'The khanate’s climax came late: in the 19th century Khiva rebuilt itself in glazed turquoise — the Islam Khoja minaret, the Tash Hauli palace, the Kalta Minor meant to out-stare them all until its patron died and the tower was left forever unfinished.',
        ],
        figures: [
          { name: 'Abu al-Ghazi Bahadur', years: '1603–1663', role: 'Khan and historian', bio: 'Warrior khan who wrote the "Genealogy of the Turks" — still the key source for Central Asian tribal history.' },
          { name: 'Mohammed Rahim Khan I', years: 'd. 1825', role: 'Khan-poet', bio: 'Patron who made Khiva a literary court; his khanate codified Khorezmian music and verse.' },
          { name: 'Islam Khoja', years: 'd. 1913', role: 'Grand vizier', bio: 'Modernizer and builder of the tallest minaret and a European-school hospital — assassinated by conservatives he had eclipsed.' },
        ],
        events: [
          { year: '1511', text: 'The Arabshahid dynasty founds the Khiva Khanate.' },
          { year: '1717', text: 'Prince Bekovich-Cherkassky’s Russian expedition is annihilated; 2,000 heads stacked into a pyramid by the khan’s order.' },
          { year: '1873', text: 'Russian forces take Khiva; the khanate becomes a protectorate, slavery abolished.' },
          { year: '1910', text: 'Islam Khoja completes his 57-metre minaret — the tallest in Central Asia.' },
        ],
        facts: [
          'Khiva minted its own coins until 1920 — some bore verses calling the khan "Shadow of God on Earth".',
          'Kalta Minor was meant to rise 70+ metres; when its patron died in 1855 the tilers simply walked away, leaving the brightest unfinished tower in Asia.',
        ],
        sources: ['UNESCO Dossier №543', 'A. Vambery, Travels in Central Asia (1863)', 'Abu al-Ghazi, Genealogy of the Turks'],
      },
      soviet: {
        story: [
          'The khanate fell in 1920; by 1967 Soviet planners had made old Khiva a protected museum-reserve, whitewashing its madrasahs and paving the desert road for busloads of curious citizens. It became one of the USSR’s first urban reserves — an entire city declared "a monument".',
        ],
        events: [
          { year: '1920', text: 'Khorezm People’s Soviet Republic replaces the khanate.' },
          { year: '1924', text: 'Khorezm dissolved; Khiva joins the Uzbek SSR.' },
          { year: '1967', text: 'Itchan Kala declared a state museum-reserve — the whole walled city protected.' },
        ],
        facts: ['Khiva’s whole inner city was declared "a monument" in 1967 — before UNESCO, before heritage was fashionable.'],
        sources: ['Khiva Museum-Reserve archival records'],
      },
      modern: {
        story: [
          'Itchan Kala was Uzbekistan’s first UNESCO site (1990). Today Khiva’s walls glow at sunset over hotels in old madrasahs, and visitors walk the ramparts where khans once watched for raiders.',
        ],
        events: [
          { year: '1990', text: 'Itchan Kala becomes Uzbekistan’s first UNESCO World Heritage site.' },
          { year: '2019', text: 'High-speed rail link to Khiva region opens the desert city to the world.' },
        ],
        facts: ['Ninety-four monumental buildings stand inside Itchan Kala’s single wall — one museum, ninety-four exhibits.'],
        sources: ['UNESCO Dossier №543'],
      },
    },
  },

  /* ---------------------------------------------------------------- */
  tashkent: {
    region: 'Chirchik Basin',
    highlights: [
      'Capital of Uzbekistan since 1930',
      '2,200 years of layered history',
      'Reborn from the 1966 earthquake',
      'Metro galleries of marble and crystal',
    ],
    gallery: [
      { src: 'tashkent_chorsu', title: 'Chorsu Bazaar', year: 'c. 8th c. – today', caption: 'The crossroads bazaar under its great turquoise dome — two millennia of trade.' },
      { src: 'tashkent_metro', title: 'Tashkent Metro', year: '1977', caption: 'Marble halls, crystal chandeliers — the first subway of Central Asia.' },
      { src: 'tashkent_independence_square', title: 'Independence Square', caption: 'The nation’s ceremonial heart, fountains and memorial avenues.' },
      { src: 'tashkent_mahalla', title: 'Old Town Mahalla', caption: 'Labyrinth courtyards where Tashkent’s communal soul survives the towers.' },
      { src: 'tashkent_amir_timur_square', title: 'Amir Timur Square', year: '1882', caption: 'Equestrian bronze amid plane trees, ringed by museums and the bell tower.' },
      { src: 'tashkent_kukeldash', title: 'Kukeldash Madrasah', year: 'c. 1560', caption: 'The old city’s towering portal — school, fortress, and once an execution ground.' },
    ],
    eras: {
      ancient: {
        story: [
          'Tashkent began as Chach — a settlement of farmers and metalworkers on the Chirchik river whose oasis fed the steppe road. Its coins, kilns and kurgans testify to a crossroads where Persian, Turkic and Chinese spheres met two thousand years ago.',
        ],
        figures: [
          { name: 'Chach metalworkers', years: 'c. 1st–8th c.', role: 'Guild', bio: 'Bronze-casters whose mirrored jewellery and horse harness traded as far as the Black Sea.' },
        ],
        events: [
          { year: 'c. 2nd c. BCE', text: 'Shashtepa mound settles — the earliest known Tashkent.' },
          { year: '552–744', text: 'Chach under the Turkic khaganate — a mint city on the Silk Road’s northern arc.' },
        ],
        facts: ['"Chach" became "Tash" (stone) in Turkic — Tashkent, the Stone City, named for its rocky river ford.'],
        sources: ['Shashtepa Excavation Reports, Tashkent Archaeological Institute'],
      },
      islamic: {
        story: [
          'Under Islam, Chach became Binkath and then Tashkent — a mint-city of the Samanid world whose scholars measured the heavens and whose caravans crossed to the steppe. In 820 the young al-Khwarizmi may have walked its bazaars on his way from Khorezm to Baghdad’s House of Wisdom.',
          'In 1219 the city resisted Genghis Khan’s siege and paid in ash — but its aqueducts and orchards meant the miracle of regrowth repeated itself, as it would again and again.',
        ],
        figures: [
          { name: 'Abu Bakr Kaffal Shashi', years: '903–976', role: 'Saint-scholar', bio: 'Sufi jurist buried in a shrine that gave Old Tashkent its spiritual centre for a millennium.' },
        ],
        events: [
          { year: '751', text: 'Arab armies organize Chach as a frontier province; the name Binkath minted on Samanid coins.' },
          { year: '1219', text: 'Genghis Khan razes Binkath after a four-day resistance.' },
        ],
        facts: ['The Kaffal Shashi shrine still anchors the Hazrati Imam complex — a millennium of pilgrimages to one courtyard.'],
        sources: ['Hazrati Imam Complex Conservation Archive'],
      },
      timurid: {
        story: [
          'Under the Timurids Tashkent thrived as a gateway between the empire and the steppe. The Kukeldash madrasah rose over the old city, caravans loaded at Chorsu, and the Shaybanid khans who followed made it the summer seat from which they watched Samarkand.',
        ],
        events: [
          { year: 'c. 1560', text: 'Kukeldash madrasah built under the Shaybanids — still guarding Chorsu.' },
          { year: '1784', text: 'Yunus Khoja unifies the four districts of Tashkent under one wall and one ruler.' },
        ],
        facts: ['Tashkent was ruled as four separate city-states (mahallas of the four gates) for centuries — one city, four governments.'],
        sources: ['History of Tashkent (2 vols., Academy of Sciences of Uzbekistan)'],
      },
      soviet: {
        story: [
          'Russian rule arrived by railway in 1889 and Soviet Tashkent became the showcase of Asian socialism — until 26 April 1966, when an 8-magnitude pre-dawn earthquake levelled the centre. Half a million were left homeless.',
          'The USSR rebuilt the capital in four years, flying in builders from every republic. Concrete apartment seas rose around restored old-town mahallas, the metro opened with marble halls fit for palaces, and Tashkent became the USSR’s fourth-largest city and its gateway to the South.',
        ],
        figures: [
          { name: 'Sharof Rashidov', years: '1917–1983', role: 'Communist Party first secretary', bio: 'Ran Soviet Uzbekistan for 24 years — cotton baron, patron of Tashkent’s rebuild, and later the emblem of the infamous "cotton affair".' },
        ],
        events: [
          { year: '1930', text: 'Tashkent replaces Samarkand as capital of the Uzbek SSR.' },
          { year: '1966', text: 'The great earthquake — 8 seconds, half a million homeless, a capital rebuilt in four years.' },
          { year: '1977', text: 'The Tashkent Metro opens — the first in Central Asia, lined with marble and crystal.' },
          { year: '1983', text: 'Moscow Television Tower completes — 375 metres, the tallest structure in Central Asia.' },
        ],
        facts: [
          'The 1966 quake’s epicentre was deep — it toppled chimneys in Tashkent yet barely cracked the old mud-brick mahallas, which out-survived concrete.',
          'Every metro station is a memorial: Kosmonavtlar’s blue porcelain portraits honour cosmonauts, including Uzbek pilot-hero Yuri Gagarin’s training ground nearby.',
        ],
        sources: ['Tashkent Earthquake 1966 — State Archive photo survey', 'Tashkent Metro Heritage Register'],
      },
      modern: {
        story: [
          'Independent Tashkent is a capital of gardens and glass: Amir Timur Square rings the equestrian bronze with museums, the dome of Chorsu shelters twenty-first-century bazaars, and the mahallas keep tea-ceremony lawns between the towers.',
          'A new financial quarter rises on the canal, the airport links Asia to Europe in five hours, and the city hosted the 2022 Shanghai Cooperation summit — the Stone City now the diplomatic stone of the region.',
        ],
        events: [
          { year: '1991', text: 'Independence Square becomes the ceremonial heart of the new republic.' },
          { year: '2007', text: 'Tashkent named cultural capital of the Islamic world by ISESCO.' },
          { year: '2022', text: 'SCO summit hosts regional leaders; the capital’s new skyline unveiled.' },
        ],
        facts: ['Tashkent’s plane trees shade more than 40% of the city — planted after 1966, they are the quake’s living memorial.'],
        sources: ['Tashkent City Architecture Archive'],
      },
    },
  },

  /* ---------------------------------------------------------------- */
  shakhrisabz: {
    region: 'Gissar Foothills',
    highlights: [
      'Birthplace of Amir Timur',
      'Ak-Saray — “the White Palace”',
      'Kesh: 2,700 years of green history',
      'UNESCO World Heritage since 2000',
    ],
    gallery: [
      { src: 'shakhrisabz_ak_saray', title: 'Ak-Saray Gateway', year: '1380–1404', caption: 'Sixty-five metres of shattered grandeur — the greatest portal ever raised.' },
      { src: 'shakhrisabz_dorus_saodat', title: 'Dorus Saodat', year: '1392', caption: 'The "Seat of Power and Thronos" — Timur’s dynastic crypt beneath unfinished domes.' },
      { src: 'shakhrisabz_kok_gumbaz', title: 'Kok Gumbaz Mosque', year: '1437', caption: 'The "Blue Dome" raised by Ulugh Beg for his father Shah Rukh.' },
    ],
    eras: {
      ancient: {
        story: [
          'Ancient Kesh — "the green city" — guarded the Tashkurgan pass into Samarkand’s plain. Sogdian farmers terraced its foothills and its horsemen were feared across the valley; one of them, centuries later, would shake the world.',
        ],
        events: [
          { year: '7th c. BCE', text: 'First citadel raised at the mountain’s foot.' },
          { year: '329 BCE', text: 'Kesh submits to Alexander during the Sogdian campaigns.' },
        ],
        facts: ['Kesh’s pass road was paved with stone slabs in antiquity — wheel ruts worn by 2,000 years of caravans are still visible near the pass.'],
        sources: ['UNESCO Dossier №1085'],
      },
      timurid: {
        story: [
          'On 9 April 1336 Timur was born in the village of Khoja Ilgar outside Kesh — and when he ruled the world from Samarkand, he never forgot it. He rebuilt his birthplace as Shakhrisabz, "the Green City", and raised the Ak-Saray: a palace whose portal towered sixty-five metres, higher than anything in Samarkand itself.',
          'Here he built the Dorus Saodat — the crypt meant to hold his dynasty. Timur lies not in Samarkand’s golden Gur-e Amir, as tourists assume, but beneath this broken dome in his home town.',
        ],
        figures: [
          { name: 'Amir Timur', years: '1336–1405', role: 'Emperor', bio: 'Born a shepherd-noble of Kesh; built an empire from Delhi to Damascus and a palace at home taller than any rival’s mosque.' },
          { name: 'Jahangir', years: '1374–1376', role: 'Crown prince', bio: 'Timur’s beloved eldest son, dead at twenty; his shrine anchored the Dorus Saodat complex in grief.' },
        ],
        events: [
          { year: '1336', text: 'Timur born near Kesh on a spring morning of campaign season.' },
          { year: '1380', text: 'Ak-Saray construction begins — twenty-four years of marble, glazed brick and forced genius.' },
          { year: '1392', text: 'Dorus Saodat crypt consecrated for the dynasty.' },
          { year: '1405', text: 'Timur dies on campaign in China; his body returns home to Shakhrisabz — then is secretly moved to Samarkand within weeks.' },
        ],
        facts: [
          'The Ak-Saray portal was inscribed: "If you doubt our power — look at our buildings." The arch fell in the 18th century; the surviving pylon still soars 38 metres.',
          'Timur’s body lay first in Shakhrisabz’s crypt; courtiers, fearing the steppe roads, moved him to Samarkand — the most consequential change of tomb in history.',
        ],
        sources: ['UNESCO Dossier №1085', 'Ibn Arabshah, Timurid Chronicles'],
      },
      khanates: {
        story: [
          'Under the Bukharan emirs Shakhrisabz kept a fierce local pride — its chust-knife smiths and Chakan embroidery fed the khanate’s bazaars while the town kept its own beg and its own laws, semi-independent of the Ark.',
        ],
        events: [
          { year: '16th c.', text: 'Shakhrisabz becomes a semi-autonomous begdom under Bukhara.' },
          { year: '1870', text: 'Russian troops storm the town during the conquest of the khanate’s eastern valleys.' },
        ],
        facts: ['Chakan embroidery of Shakhrisabz — silk florals on black — was UNESCO-listed as Intangible Heritage in 2022.'],
        sources: ['UNESCO ICH Register — Chakan embroidery'],
      },
      modern: {
        story: [
          'UNESCO inscribed Shakhrisabz in 2000 — and placed it on the danger list in 2016 when new development pressed too close to the medieval core. Today conservation planners balance the Green City’s living growth against the shells of Timur’s marble.',
        ],
        events: [
          { year: '1996', text: 'Timur’s 660th birthday — Ak-Saray grounds landscaped as a national park.' },
          { year: '2000', text: 'UNESCO World Heritage inscription.' },
          { year: '2016', text: 'UNESCO adds the site to the danger list to shield the medieval core.' },
        ],
        facts: ['Shakhrisabz grows saffron crocuses on the Ak-Saray lawns each March — the palace’s flowerbeds are the town’s spice rack.'],
        sources: ['UNESCO Danger List Reports 2016–2023'],
      },
    },
  },

  /* ---------------------------------------------------------------- */
  termez: {
    region: 'Amu Darya Border',
    highlights: [
      'Buddhist capital of the Kushan Empire',
      'Al-Hakim al-Termizi’s Sufi shrine',
      'Oldest continuously named city of the Oxus',
      'Gateway between India, Iran and the steppe',
    ],
    gallery: [
      { src: 'termez_buddhist_stupa', title: 'Fayaz Tepe Stupa', year: '1st–3rd c. CE', caption: 'A Buddhist monastery under desert light — the Buddha’s shadow reached the Oxus.' },
      { src: 'termez_hakim_shrine', title: 'Hakim al-Termizi Mausoleum', year: '11th c.', caption: 'Portal shrine of the Sufi master whose name the city still carries.' },
      { src: 'termez_sultan_saodat', title: 'Sultan Saodat Ensemble', year: '10th–17th c.', caption: 'Necropolis of the Sayyid lords of Termez in unglazed dignity.' },
    ],
    eras: {
      ancient: {
        story: [
          'Termez began as an Alexandria-on-the-Oxus — one of the dozen cities Alexander’s successors planted from the Nile to the Indus. Under the Kushan emperors it became a Buddhist capital: monasteries, stupas and cave shrines lined the river where monks prayed in a script halfway between Sanskrit and Greek.',
        ],
        figures: [
          { name: 'Kanishka the Kushan', years: 'd. c. 150 CE', role: 'Emperor', bio: 'Patron of Buddhism whose empire linked Rome, Persia and Han China; his coins show Buddha, Shiva and Apollo side by side.' },
        ],
        events: [
          { year: 'c. 280 BCE', text: 'Seleucid foundation — "Alexandria Oxiana" at the river crossing.' },
          { year: '1st c. CE', text: 'Kushan era: Fayaz Tepe and Kara Tepe monasteries rise above the Oxus.' },
          { year: 'c. 100 CE', text: 'Buddhist delegations board at Termez for the court of Han China.' },
        ],
        facts: ['Fayaz Tepe’s Buddha statue was carved in schist with Hellenistic drapery — a Buddha in a Greek toga, the Silk Road’s finest cultural joke.'],
        sources: ['Kara Tepe Excavations (B. Stavisky)', 'British Museum Kushan collections'],
      },
      islamic: {
        story: [
          'Under Islam Termez became a city of scholars and saints. Al-Hakim al-Termizi — psychologist of the Sufi soul, author of three hundred works — taught here, and the Sultan Saodat necropolis grew into a field of domed mausoleums for his Sayyid followers.',
          'The Mongols erased the old city in 1220; it resettled on the banks a mile west, where its shrines still crown the bluff above Afghanistan.',
        ],
        figures: [
          { name: 'Al-Hakim al-Termizi', years: 'c. 820–892', role: 'Sufi master', bio: 'Wrote the first systematic psychology of mystical experience — 300 works from a house above the Oxus.' },
        ],
        events: [
          { year: '704', text: 'Arab conquest fixes Termez as the Oxus crossing of Khorasan.' },
          { year: '9th c.', text: 'Al-Termizi’s circle makes the city a Sufi beacon.' },
          { year: '1220', text: 'Mongols destroy old Termez; the city migrates downriver.' },
        ],
        facts: ['Termez’s "Alexander’s wall" was never his — the clay rampart west of town is 9th-century Arab work on Kushan footings.'],
        sources: ['Al-Hakim al-Termizi, Khatm al-Awliya', 'Sultan Saodat Conservation Survey'],
      },
      timurid: {
        story: [
          'Timurid Termez guarded the empire’s southern gate. Caravans to Balkh and Herat crossed here; the Kokildora khanaka housed pilgrims; and the city’s potters fired the blue-and-white ware that travelled the empire’s roads.',
        ],
        events: [
          { year: '1389', text: 'Timur rebuilds the river fortress for his Balkh campaigns.' },
          { year: 'c. 1430', text: 'Kokildora khanaka raises its twin-portal gate for dervish guests.' },
        ],
        facts: ['Kokildora’s facade carries a rare image of two lions hunting — Persian royal art in a Sufi hostel.'],
        sources: ['Surkhandarya Regional Museum inventory'],
      },
      modern: {
        story: [
          'Modern Termez is Uzbekistan’s southern gate: the Friendship Bridge to Afghanistan, a Russian 201st base nearby, and new rail links to Mazar-i-Sharif keep the old crossing busy. Its museums now shelter the Buddhist heritage beneath the Sufi domes.',
        ],
        events: [
          { year: '1981', text: 'The Soviet-Afghan "Friendship Bridge" opens over the Amu Darya.' },
          { year: '2001', text: 'Termez airfield becomes the NATO supply hub for Afghanistan operations.' },
          { year: '2018', text: 'Kara Tepe and Fayaz Tepe conservation opens the Buddhist quarter to visitors.' },
        ],
        facts: ['Termez is the southernmost city of Central Asia — in midsummer the temperature tops 45°C, the desert’s own opinion of the tropics.'],
        sources: ['Termez Archaeological Museum (est. 2002)'],
      },
    },
  },

  /* ---------------------------------------------------------------- */
  karshi: {
    region: 'Kashkadarya Oasis',
    highlights: [
      'Nakhshab — 2,700 years of oasis trade',
      'Rabati Malik caravanserai on the steppe road',
      'Khanate bridge of nine arches',
      'Gas capital of modern Uzbekistan',
    ],
    eras: {
      ancient: {
        story: [
          'Karshi began as Nakhshab, a walled oasis city where the Kushan kings minted silver and the steppe road crossed the Kashkadarya. Its name today comes from the Turkic for "palace" — the caravanserai Timur built for traders sleeping between Samarkand and Balkh.',
        ],
        events: [
          { year: 'c. 700 BCE', text: 'Nakhshab fortress raised on the oasis mound.' },
          { year: 'c. 100 CE', text: 'Kushan silver coins struck in Nakhshab circulate to China.' },
        ],
        facts: ['Karshi’s 11th-century Rabati Malik caravanserai stood half a day’s ride from water — its wells were engineering marvels sixty metres deep.'],
        sources: ['Kashkadarya Museum of Local Lore'],
      },
      islamic: {
        story: [
          'Under the Qarakhanids the city grew around the Rabati Malik caravanserai and its Sardoba cistern — a dome in the emptiness of the steppe where a hundred camels drank. Its portal inscription still reads like a caravan manifest of nations.',
        ],
        events: [
          { year: '1068', text: 'Rabati Malik caravanserai built on the Samarkand–Bukhara road.' },
          { year: '1220', text: 'Mongols sack the oasis; Nakhshab rebuilds around its wells.' },
        ],
        facts: ['The Sardoba Malik cistern still holds water after nine centuries — its ice-cooled dome kept drinking water sweet in the deadliest heat.'],
        sources: ['UNESCO Tentative List — Rabati Malik'],
      },
      khanates: {
        story: [
          'Under the emirs of Bukhara, Karshi became the southern bastion: a walled arsenal whose bazaar sold Karakul lambskins across three empires. The nine-arch bridge of 1516 still carries the bazaar road across the Kashkadarya.',
        ],
        figures: [
          { name: 'Ubaidullah Khan', years: 'd. 1539', role: 'Sheibanid khan', bio: 'Made Karshi his power base and twice besieged Samarkand from its walls.' },
        ],
        events: [
          { year: '1516', text: 'The nine-arched bridge over the Kashkadarya completed.' },
          { year: '1708', text: 'Karshi repels a Mongol-Dzungar raid — its walls hold the south for Bukhara.' },
          { year: '1870', text: 'Russian column storms Karshi; the emirate’s south opens.' },
        ],
        facts: ['The bridge of Karshi carried caravans until 2016 — four centuries of hooves on its nine arches.'],
        sources: ['Karshi Regional Archive'],
      },
      modern: {
        story: [
          'Soviet geologists struck gas in 1953 and Karshi became the energy capital of the republic; today the city powers Uzbekistan’s pipelines while its bazaar still smells of Karakul wool and mulberry.',
        ],
        events: [
          { year: '1953', text: 'First gas field (Setalan) opens the Kashkadarya energy age.' },
          { year: '1975', text: 'Talimarjan power station lights the south of the republic.' },
          { year: '2020', text: 'Karshi airport reopens; the oasis links to Tashkent in 70 minutes.' },
        ],
        facts: ['Karshi’s Khanabad field once fed the entire Central Asian grid — its flare stacks were visible from the Afghan border.'],
        sources: ['Uzbekneftegaz corporate history'],
      },
    },
  },

  /* ---------------------------------------------------------------- */
  kokand: {
    region: 'Fergana Valley West',
    highlights: [
      'Capital of the Khanate of Kokand (1709–1876)',
      'Khudayar Khan’s palace of 119 rooms',
      'Madrasah city of poets and potters',
      'Gate of the Fergana silk road',
    ],
    eras: {
      islamic: {
        story: [
          'Kokand appears in the records as Kavkand — a small fortress town where the western Fergana caravans watered before crossing the steppe to Tashkent. Its trade grew with the valley’s silk and horses long before its khans arrived.',
        ],
        events: [
          { year: '10th c.', text: 'Kavkand noted as a Fergana way-station on the Kashgar road.' },
          { year: '13th c.', text: 'Mongol armies pass; the fortress rebuilds in brick.' },
        ],
        facts: ['Kokand’s bazaar inherited the Fergana valley’s oldest caravan licence — a Mongol-era tax seal kept in the regional museum.'],
        sources: ['Kokand Regional Studies Museum'],
      },
      khanates: {
        story: [
          'In 1709 the Ming Uzbek chieftain Shahrukh Bey raised a citadel at Kokand and founded a khanate that within a century ruled the whole Fergana valley, Tashkent and the Kazakh steppe roads. Its golden age came under Umar Khan and his wife Nodira — poet, patron and the most celebrated woman of 19th-century Central Asia.',
          'The last khan, Khudayar, answered the age of steam with marble: a palace of 119 rooms finished in 1871 — its throne hall gilded while famine gnawed the valley. Three years later Russian artillery ended the khanate; the palace survived as the empire’s trophy and today as the region’s museum.',
        ],
        figures: [
          { name: 'Umar Khan', years: '1787–1822', role: 'Khan', bio: 'Conqueror-administrator who made Kokand the cultural rival of Bukhara.' },
          { name: 'Nodira', years: '1792–1842', role: 'Queen-poet', bio: 'Ruled as regent, wrote in Uzbek and Persian, built madrasahs and libraries — executed by the Emir of Bukhara, remembered as the valley’s martyred muse.' },
          { name: 'Khudayar Khan', years: '1829–1886', role: 'Last khan', bio: 'Four times khan, four times deposed; his marble palace outlived his throne.' },
        ],
        events: [
          { year: '1709', text: 'Shahrukh Bey founds the Khanate of Kokand.' },
          { year: '1821', text: 'Umar Khan’s court hosts the valley’s poets; Nodira’s salon opens.' },
          { year: '1842', text: 'Bukharan troops execute Nodira; Kokand mourns in verse for a decade.' },
          { year: '1871', text: 'Khudayar Khan’s palace completes — 119 rooms in marble and gold.' },
          { year: '1876', text: 'Russia abolishes the khanate; Fergana becomes a governorate.' },
        ],
        facts: [
          'Only 19 of the palace’s original 119 rooms survive — Russian officers, then Soviet planners, demolished the rest; the throne hall’s gilt ceiling survived by becoming a "museum of atheism".',
          'Nodira’s verses were forbidden after her execution; grandmothers copied them by hand until the 20th century.',
        ],
        sources: ['Khudayar Khan Palace Museum', 'Nodira, Collected Verses (Tashkent ed.)'],
      },
      soviet: {
        story: [
          'Soviet Kokand became the Fergana’s railway hub — the broad-gauge reached it in 1913, and oil, chemicals and cotton machinery followed. The old city’s madrasahs became schools; the palace became the regional museum.',
        ],
        events: [
          { year: '1913', text: 'Railway links Kokand to Tashkent and Andijan.' },
          { year: '1918–24', text: 'Kokand is the crucible of the Turkestan Autonomous movement, crushed by the Red Army.' },
        ],
        facts: ['The 1918 Kokand autonomy — the first Muslim self-declared republic in Central Asia — lasted 72 days; its memory seeded independent Uzbekistan a century later.'],
        sources: ['Turkestan Autonomy archival collection'],
      },
      modern: {
        story: [
          'Today Kokand is the Fergana’s western gate: its Hamza station links the valley to Tashkent in four hours, and the restored palace and Juma mosque draw travellers into the khanate’s gilded echo.',
        ],
        events: [
          { year: '2018', text: 'Kokand’s 1,150th anniversary — palace and madrasah quarter restored.' },
          { year: '2022', text: 'International crafts festival returns to the khanate capital.' },
        ],
        facts: ['Kokand potters still fire the khanate’s signature green glaze in the same kilns their grandfathers rebuilt after the 1918 siege.'],
        sources: ['Kokand Craft Guild Register'],
      },
    },
  },

  /* ---------------------------------------------------------------- */
  margilan: {
    region: 'Fergana Valley East',
    highlights: [
      '2,000 years of silk weaving',
      'Legendary khan-atlas ikat',
      'Living craft workshops of the Fergana',
      'Silk Road’s fabric treasury',
    ],
    eras: {
      ancient: {
        story: [
          'Legend says Alexander’s soldiers demanded silk here as their wages — and Margilan has woven ever since. By the Han chronicles the town was a carpet-and-silk station on the road over the Alai pass to Kashgar.',
        ],
        events: [
          { year: 'c. 2nd c. BCE', text: 'Han envoys record "the town of weavers" beyond the Pamirs.' },
          { year: 'c. 500 CE', text: 'Sogdian merchants export Fergana silk to Byzantium.' },
        ],
        facts: ['Margilan’s silk waste fed the valley’s famous fish ponds — medieval chroniclers noted trout "silver as the cloth".'],
        sources: ['Margilan Silk Heritage Museum'],
      },
      timurid: {
        story: [
          'Timurid Margilan supplied the empire’s courts: khan-atlas ikat — clouds of rainbow dye on silk — for robes of honour, and velvet for the tents of ambassadors. Each bolt passed the shopfronts of the chorsu bazaar that still anchors the old town.',
        ],
        figures: [
          { name: 'Zayniddin Bobur', years: 'c. 1210s', role: 'Sufi patron saint', bio: 'The valley’s beloved saint whose shrine complex anchors Margilan’s spiritual map.' },
        ],
        events: [
          { year: 'c. 1400', text: 'Khan-atlas dye technique codified in Margilan workshops.' },
          { year: '1501', text: 'Babur passes through Margilan on his retreat from the Fergana throne.' },
        ],
        facts: ['Real khan-atlas is dyed before weaving — the pattern is born in the warp, not printed on: seven workshops in Margilan keep the original abr-bandani alive.'],
        sources: ['UNESCO ICH — Atlas silk culture of Margilan'],
      },
      soviet: {
        story: [
          'Soviet Margilan industrialized the looms: the Yodgorlik factory preserved hand-weaving while the giant combinat mechanized it. Margilan silk won prizes from Brussels to Osaka.',
        ],
        events: [
          { year: '1972', text: 'Yodgorlik silk factory opens, keeping hand-ikat alive.' },
          { year: '1986', text: 'Margilan silk takes the Osaka world expo gold medal.' },
        ],
        facts: ['One Margilan silk kerchief takes three days and eleven artisans — and was, for a Soviet bride, the dowry’s crown jewel.'],
        sources: ['Yodgorlik Factory Archive'],
      },
      modern: {
        story: [
          'Today Margilan is the UNESCO-recognized capital of Uzbek silk: workshops fire the vats, grandmothers teach reeling, and the Margilan Crafts Development Centre exports ikat to Paris runways.',
        ],
        events: [
          { year: '2017', text: 'Margilan hosts the first International Atlas Silk Festival.' },
          { year: '2022', text: 'Margilan silk techniques join UNESCO’s Intangible Heritage lists.' },
        ],
        facts: ['Margilan’s silk is legally protected — "khan-atlas of Margilan" carries a geographic appellation like champagne.'],
        sources: ['UNESCO ICH 2022 inscription file'],
      },
    },
  },

  /* ---------------------------------------------------------------- */
  urgench: {
    region: 'Lower Amu Darya',
    highlights: [
      'Gurganj — capital of medieval Khorezm',
      'Kutlug Timur Minaret, 60 m',
      'Gateway to the Golden Ring of Khorezm',
      'Reborn capital of a fertile oasis',
    ],
    eras: {
      ancient: {
        story: [
          'The site of Urgench was a Khorezmian river port where Amu Darya barges unloaded grain and copper for the delta fortresses. Its sister city Kheiva (Khiva) guarded the wells to the south.',
        ],
        events: [
          { year: 'c. 1st c. CE', text: 'River port documented on Khorezmian river charts.' },
        ],
        facts: ['Old Urgench’s bricks were river-fired clay — Khorezm kiln bricks are so hard medieval masons used them to sharpen blades.'],
        sources: ['Khorezm Archaeological Expedition (Tolstov)'],
      },
      islamic: {
        story: [
          'As Gurganj, this was the capital of Khorezm and one of the wonders of the Islamic East: bazaars of a mile, a great cathedral mosque, and scholars — Beruni among them — who measured the Earth from its towers. In 1221 the Mongols broke the Amu Darya dams and drowned the city in weeks; the survivors rebuilt on a new site a mile southeast.',
        ],
        figures: [
          { name: 'Al-Biruni (resident)', years: '973–1048', role: 'Universal scholar', bio: 'Measured the Earth’s radius and wrote India’s first scientific ethnography from Khorezm’s courts.' },
          { name: 'Mamun II', years: 'd. 1220', role: 'Last Khwarazmshah at Gurganj', bio: 'Watched his capital drown beneath the broken dams rather than surrender.' },
        ],
        events: [
          { year: '995', text: 'Gurganj becomes the Khorezm capital under the Mamunids.' },
          { year: '1017', text: 'Mamun Academy founded — the world’s first research institute of its scale.' },
          { year: '1221', text: 'Mongols breach the dams; Gurganj drowns in seven days of battle and flood.' },
        ],
        facts: ['Gurganj’s Mamun Academy predates European universities by two centuries — its observatory measured the solar year to 24 seconds.'],
        sources: ['al-Biruni, Tahdid Nihayat al-Amakin', 'Juvaini, History of the World-Conqueror'],
      },
      timurid: {
        story: [
          'Timur razed rebuilt Gurganj in 1388 and marched its craftsmen to Samarkand. Urgench kept the oasis’s shrines — the Najm ad-Din Kubra complex became a Sufi beacon — and the 60-metre Kutlug Timur minaret kept watch over the ruins of its glory.',
        ],
        figures: [
          { name: 'Najm ad-Din Kubra', years: '1145–1221', role: 'Sufi martyr', bio: 'Founded the Kubrawiyya order; died sword in hand defending Gurganj, his shrine a pilgrimage for eight centuries.' },
        ],
        events: [
          { year: '1388', text: 'Timur’s fifth sack of Gurganj; the artisans deported.' },
        ],
        facts: ['The Kutlug Timur minaret stands 60 metres on a foundation only 1.5 m deep — Khorezm’s master masons balanced a candle-stick of brick against nine centuries of earthquakes.'],
        sources: ['Kunya-Urgench UNESCO Dossier (Turkmenistan №1199)'],
      },
      khanates: {
        story: [
          'Under the Khiva khanate, New Urgench grew as the oasis’s grain market and caravan crossroads, feeding the khan’s armies and the Aral fisher folk alike.',
        ],
        events: [
          { year: '1643', text: 'New Urgench chartered as the khanate’s northern market town.' },
        ],
        facts: ['Urgench melons were carted 600 km to Khiva’s courts packed in wax-sealed gourds — the khanate’s express fruit delivery.'],
        sources: ['Khiva Khanate chronicles (Munis, Firdaus al-Iqbal)'],
      },
      modern: {
        story: [
          'Soviet Urgench became the administrative capital of Khorezm after the 1924 boundaries; modern high-rises stand beside teahouses, and the city is the gateway to Khiva’s walls and the Aral’s ghost shores.',
        ],
        events: [
          { year: '1924', text: 'Urgench made centre of the new Khorezm region.' },
          { year: '1999', text: '1,000th anniversary of the city celebrated with new airport and museums.' },
        ],
        facts: ['Urgench airport’s runways double as emergency landing strips for the Baikonur corridor — Cold War design still on standby.'],
        sources: ['Khorezm Regional Administration archive'],
      },
    },
  },

  /* ---------------------------------------------------------------- */
  nukus: {
    region: 'Karakalpakstan',
    highlights: [
      'Capital of Karakalpakstan',
      'Savitsky Museum — “the desert Louvre”',
      'Gate of the dying Aral Sea',
      'Ancient Zoroastrian dakhma country',
    ],
    eras: {
      ancient: {
        story: [
          'The lands around Nukus held the Zoroastrian towers of silence — dakhma hills where the dead were given to the sky — and canal cities whose farmers fed the Aral delta three thousand years ago.',
        ],
        events: [
          { year: 'c. 800 BCE', text: 'Delta irrigation cultures flourish around the future Nukus.' },
        ],
        facts: ['Chilpik dakhma tower above Nukus was reused as a Silk Road signal tower — Zoroastrian silence became beacon fire.'],
        sources: ['Karakalpak Archaeological Survey'],
      },
      khanates: {
        story: [
          'In khanate times the Nukus lands were the frontier between the Khiva khanate and the Karakalpak tribes whose karakalpa — "black hat" — gave the people their name.',
        ],
        events: [
          { year: '1740', text: 'Karakalpak tribes settle the lower delta under Khiva’s loose rule.' },
        ],
        facts: ['Karakalpak yurt bands weave the only pure-wool pile carpets of Central Asia — their red comes from madder root grown in the delta.'],
        sources: ['Savitsky Museum ethnographic collection'],
      },
      soviet: {
        story: [
          'Nukus was laid out as a Soviet planned capital in 1932 — and became, improbably, one of the world’s great art sanctuaries. Igor Savitsky, painter and collector, smuggled thousands of banned Russian avant-garde and Uzbek modernist canvases to a museum in the desert.',
          'The Aral disaster unfolded in slow motion: the sea that once lapped Karakalpak fishing towns retreated 150 km, leaving rusting trawlers and salt storms. Moynaq’s ship graveyard became the disaster’s icon.',
        ],
        figures: [
          { name: 'Igor Savitsky', years: '1915–1984', role: 'Curator-hero', bio: 'Convinced Moscow the desert needed an avant-garde museum — and saved 44,000 artworks the USSR wanted forgotten.' },
        ],
        events: [
          { year: '1932', text: 'Nukus founded as the planned capital of the Karakalpak ASSR.' },
          { year: '1966', text: 'Savitsky Museum opens with the world’s second-largest Russian avant-garde collection.' },
          { year: '1980s', text: 'The Aral retreat strands Moynaq’s fleet 150 km from water.' },
        ],
        facts: [
          'The Savitsky Museum holds 44,000 works — the second-largest collection of Russian avant-garde on Earth, in the world’s unlikeliest place.',
          'The Aral Sea was once the world’s fourth-largest lake; its fishing industry fed the USSR — the last ship left Moynaq’s harbour in 1979.',
        ],
        sources: ['Savitsky State Museum of Art', 'UNESCO Aral Sea reports'],
      },
      modern: {
        story: [
          'Independent Nukus is the capital of ecological hope: afforestation bands green the dried seabed, the Kokaral dam raised the small Aral’s level by metres, and the Savitsky Museum glows as Central Asia’s finest small museum.',
        ],
        events: [
          { year: '2005', text: 'Kokaral dam completes — the North Aral Sea returns to fishing towns.' },
          { year: '2019', text: 'Savitsky Museum reopens after major expansion.' },
          { year: '2021', text: 'Nukus hosts the Central Asian environmental summit.' },
        ],
        facts: ['Trees now cover 2 million hectares of the dried Aral bed — the world’s fastest-growing man-made forest, planted against the salt wind.'],
        sources: ['IFAS Aral Basin Programme reports'],
      },
    },
  },

  /* ---------------------------------------------------------------- */
  /* Lighter entries for secondary cities                              */

  fergana: {
    region: 'Fergana Valley South',
    highlights: ['Russia’s planned garden city of 1876', 'Gateway of the valley’s south', 'Muyan Mubarak madrasah', 'Oil capital of the valley'],
    eras: {
      khanates: {
        story: ['Fergana city was founded by Russian general Skobelev in 1876 as "New Margilan" — a grid of boulevards and poplar gardens outside the ancient towns. It became the valley’s administrative and oil capital.'],
        events: [{ year: '1876', text: 'Fortress and boulevard grid founded as "New Margilan" (renamed Fergana 1907).' }],
        facts: ['Fergana’s water tower and theatre survive from the tsarist plan — the city was laid out with Parisian boulevard proportions.'],
        sources: ['Fergana Regional Museum'],
      },
      soviet: {
        story: ['Soviet Fergana refined the valley’s oil and built its petrochemical works; the city’s boulevards shaded the republic’s first refinery school.'],
        events: [{ year: '1959', text: 'Fergana refinery doubles capacity; the valley’s petrochemical age begins.' }],
        facts: ['The Fergana valley produces Uzbekistan’s entire oil output — a geological pocket the khanate khans burned as "stone oil" for lamps.'],
        sources: ['Fergana Refinery corporate history'],
      },
      modern: {
        story: ['Modern Fergana is the valley’s southern hub — its airport links the silk towns to Tashkent, and its boulevards host the valley’s largest tea gardens.'],
        events: [{ year: '2018', text: 'Fergana airport reopens to international flights.' }],
        facts: ['Locals call Fergana "the city of swans" — its canal lakes keep a permanent white-feathered population.'],
        sources: ['Fergana City Administration'],
      },
    },
  },

  andijan: {
    region: 'Fergana Valley East',
    highlights: ['Babur’s birthplace', 'Silk Road gate to Kashgar', 'Largest city of the Fergana valley'],
    eras: {
      islamic: {
        story: ['Andijan was the Fergana valley’s capital when the Arabs arrived — a mint city of mulberry groves whose silk and horses crossed the Pamir road to Kashgar. The great earthquake of 880 CE levelled it; the bazaar rebuilt richer.'],
        events: [{ year: '9th c.', text: 'Andijan noted as the valley’s largest town and mint.' }],
        facts: ['Andijan’s silk mulberry groves fed both its weavers and its silkworm exports — Babur wrote home homesick for its plums.'],
        sources: ['Andijan Regional Museum'],
      },
      timurid: {
        story: ['In 1483 Zahiruddin Babur — founder of the Mughal empire — was born in Andijan’s citadel at twelve, ruled the Fergana valley from it at the same age, and lost it. His memoirs open with its orchards: "Andijan produces excellent game and good wines."'],
        figures: [{ name: 'Babur', years: '1483–1530', role: 'Emperor-in-exile', bio: 'Ruled Fergana at twelve, took Kabul at twenty-two, Delhi at forty-three — and never stopped missing Andijan’s melons.' }],
        events: [{ year: '1494', text: 'Babur becomes king of Fergana from Andijan’s citadel, aged twelve.' }],
        facts: ['Babur’s memoirs mention Andijan’s melons eleven times — Mughal emperors later had Andijan melon seed couriered 2,000 km to Agra.'],
        sources: ['Baburnama (Wheeler Thackston trans.)'],
      },
      khanates: {
        story: ['Under the Kokand khans Andijan was the valley’s trade gate: caravans for Kashgar loaded here, and its bazaar sold the famed "Andijan samovar" copper as far as Yarkand.'],
        events: [{ year: '1875', text: 'Andijan joins the Russian protectorate after the Kokand campaign.' }],
        facts: ['The 1898 Andijan uprising — dervish Madali’s revolt against Russian liquor taxes — shook the empire’s Central Asia policy for a decade.'],
        sources: ['Andijan Regional Archive'],
      },
      soviet: {
        story: ['Soviet Andijan became the valley’s machinery city: cotton harvesters, pumps and the great canal pumps that watered the Hungry Steppe were built here.'],
        events: [{ year: '1966', text: 'Andijan Machine Works ships the valley’s first Soviet cotton harvester.' }],
        facts: ['Andijan-built pumps moved more water than any other factory in Central Asia — the Aral Sea’s fate has an Andijan address.'],
        sources: ['Andijan Machine Works museum'],
      },
      modern: {
        story: ['Modern Andijan is the valley’s largest city — its auto plant builds Chevrolet cars for all of Central Asia, and the Babur Literary Museum keeps the exile’s orchards alive in the city’s memory.'],
        events: [{ year: '2008', text: 'General Motors Uzbekistan plant opens — Andijan builds the region’s cars.' }],
        facts: ['The Babur house-museum’s garden grows the exact melon varieties the emperor praised — visitors may taste a 500-year-old memory.'],
        sources: ['Babur Museum, Andijan'],
      },
    },
  },

  navoi: {
    region: 'Zarafshan Middle Course',
    highlights: ['Named for the poet-sage Navoi', 'Gold of Muruntau', 'Sarmysh say petroglyphs nearby'],
    eras: {
      ancient: {
        story: ['On the middle Zarafshan, the ancient town of Nurota guarded the desert road with its hilltop fortress — its springs watered caravans a day before Samarkand.'],
        events: [{ year: 'c. 4th c. BCE', text: 'Nurota fortress raised at the desert’s edge.' }],
        facts: ['Nurota’s Chashma spring complex has refreshed pilgrims 2,300 years — the same water still runs today.'],
        sources: ['Navoi Regional Museum'],
      },
      islamic: {
        story: ['Medieval Nurota fed the caravans of the Bukhara road; its fish lakes — sacred to locals — were stocked by a 10th-century governor and never fished empty since.'],
        events: [{ year: '10th c.', text: 'The sacred lakes of Nurota stocked by Karakhanid decree.' }],
        facts: ['The Nurota lakes’ catfish are protected by a millennium-old custom — harming one is still a village scandal.'],
        sources: ['Navoi Regional Museum'],
      },
      timurid: {
        story: ['Timur’s armies watered at Nurota on the way to the steppe; the town’s caravanserais slept the silk going north to the Kazakh camps.'],
        events: [{ year: '1391', text: 'Timur’s northern campaign passes through Nurota’s gates.' }],
        facts: ['A Timurid milestone stone near Nurota still lists distances to Samarkand in "farasakh" — horse-post units.'],
        sources: ['Navoi Regional Museum'],
      },
      soviet: {
        story: ['In 1958 the Soviets built a metallurgical city in the desert and named it for the poet-sage Alisher Navoi — its combine processed the gold of Muruntau, soon the biggest open-pit gold mine on Earth.'],
        figures: [{ name: 'Alisher Navoi (namesake)', years: '1441–1501', role: 'Poet-minister', bio: 'The Chagatai Shakespeare whose "Khamsa" founded Uzbek literature — the city keeps his statue facing the mountains he wrote of.' }],
        events: [{ year: '1958', text: 'Navoi city founded beside the Kzymkent combine.' }, { year: '1969', text: 'Muruntau opens — the world’s largest open-pit gold mine.' }],
        facts: ['Muruntau has yielded 3,000+ tonnes of gold — at 600 metres deep, its trucks circle the pit like ants on a saucer.'],
        sources: ['NMMC corporate history'],
      },
      modern: {
        story: ['Modern Navoi pairs industry with the past: the Sarmysh say gorge nearby bears 10,000 petroglyphs, and the free economic zone now builds the region’s solar panels.'],
        events: [{ year: '2019', text: 'Navoi Free Economic Zone opens Central Asia’s largest solar factory.' }],
        facts: ['Sarmysh say’s 10,000 rock carvings span 8,000 years — from aurochs hunts to Soviet-era initials scratched by passing shepherds.'],
        sources: ['Sarmyshsay Petroglyph Reserve'],
      },
    },
  },

  jizzakh: {
    region: 'Turkestan Range Foothills',
    highlights: ['Birthplace of Jochi, Genghis’s son (tradition)', 'Gate to the Nuratau mountains', 'Tamerlane’s mountain capital of hunts'],
    eras: {
      ancient: {
        story: ['Jizzakh guarded the "Jizzakh gates" — the mountain pass through which every invader from Alexander to the Arabs entered the Zarafshan plain. Its oasis fed garrisons a thousand years before Moscow existed.'],
        events: [{ year: 'c. 2nd c. BCE', text: 'The "Iron Gates" pass fortified at Jizzakh.' }],
        facts: ['The "Iron Gates" were literally banded with iron — Roman envoys recorded the pass doors bound in blackened metal.'],
        sources: ['Jizzakh Regional Museum'],
      },
      islamic: {
        story: ['Under the Samanids and Karakhanids, Jizzakh was a fortress-mint of the eastern frontier; its scholars kept observatories on the mountains where the Zarafshan rivers rise.'],
        events: [{ year: '10th c.', text: 'Jizzakh mint strikes Karakhanid silver.' }],
        facts: ['Jizzakh mountain honey was tribute-worthy — the chronicles note the khan’s table demanded it every autumn.'],
        sources: ['Jizzakh Regional Museum'],
      },
      timurid: {
        story: ['Timur kept a hunting park in the Jizzakh mountains — the Zarafshan range’s tigers and wild sheep fed his court; Ulugh Beg later measured eclipses from its clear-air slopes.'],
        events: [{ year: '1395', text: 'Timur’s great hunt staged in the Jizzakh foothills.' }],
        facts: ['Jizzakh’s "Timur gate" peak still bears a carved throne — legend says the limping emperor watched his hunts from it.'],
        sources: ['Jizzakh Regional Museum'],
      },
      soviet: {
        story: ['Soviet Jizzakh became the Hungry Steppe’s capital of irrigation — a million hectares of desert went under cotton, watered by pumps and canals engineered from Jizzakh.'],
        events: [{ year: '1956', text: 'The Hungry Steppe campaign launches from Jizzakh HQ.' }],
        facts: ['The Hungry Steppe campaign moved 100,000 settlers — today its canal headworks are an industrial heritage monument.'],
        sources: ['Jizzakh Regional Archive'],
      },
      modern: {
        story: ['Modern Jizzakh is a free-economic-zone city — its industrial parks build tires, cement and solar glass under the mountains Timur hunted.'],
        events: [{ year: '2019', text: 'Jizzakh FEZ opens with 11 major factories.' }],
        facts: ['Jizzakh’s Zomin national park protects the last wild argali sheep of the Nuratau — their horns curve wider than a man’s arm.'],
        sources: ['Zomin National Park service'],
      },
    },
  },

  gulistan: {
    region: 'Syr Darya Steppe',
    highlights: ['Youngest city of the ancient road', 'Cotton capital of the Hungry Steppe', 'Wind-city of the steppe'],
    eras: {
      khanates: {
        story: ['Gulistan began as a Kokand khanate frontier fort amid the steppe grass the Uzbeks called "gulistan" — the flower land. Caravans watered at its wells between Tashkent and Jizzakh.'],
        events: [{ year: '19th c.', text: 'Kokand frontier fort (Achikurgan) founded on the steppe road.' }],
        facts: ['The steppe around Gulistan bloomed tulips each April so vast that travellers named it "the flower land" — the city keeps the name.'],
        sources: ['Sirdaryo Regional Archive'],
      },
      soviet: {
        story: ['Soviet planners made Gulistan the centre of the Hungry Steppe cotton campaign — its rails carried the fibre, its museums keep the settlers’ samovars and letters.'],
        events: [{ year: '1950s', text: 'Gulistan becomes the Hungry Steppe’s rail and processing hub.' }],
        facts: ['Gulistan’s "wind rose" is legendary — steppe gales shaped the city’s low, ducked skyline and its windbreak poplars.'],
        sources: ['Sirdaryo Regional Archive'],
      },
      modern: {
        story: ['Today Gulistan pairs its cotton heritage with new industry — the region’s textile clusters weave Uzbek brand cloth for export, and the steppe blooms with solar panels.'],
        events: [{ year: '2021', text: 'Sirdaryo textile cluster exports to the EU for the first time.' }],
        facts: ['Gulistan solar arrays power 100,000 homes — the wind city now harvests the steppe’s two eternities: sun and wind.'],
        sources: ['Uzbekenergo project files'],
      },
    },
  },
};

/** merge helper: rich content over base city content */
export function getRich(cityId: string): RichCity | undefined {
  return RICH[cityId];
}
