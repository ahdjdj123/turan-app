/**
 * TURAN travel-intelligence layer — the "premium travel app" data model.
 * Deterministic (no APIs): weather is a seasonal climate model, distances
 * are real haversine km between city coordinates, ETAs derive from speed.
 */
import { CITY_GEO } from './geo';
import type { EraId } from './eras';

/* ------------------------------------------------------------------ */
/*  categories                                                         */
/* ------------------------------------------------------------------ */

export type CategoryId = 'unesco' | 'ancient' | 'silkroad' | 'museum' | 'craft' | 'living';

export const CATEGORIES: { id: CategoryId; icon: string; color: string }[] = [
  { id: 'unesco', icon: '🏛️', color: '#D4A53C' },
  { id: 'ancient', icon: '🏺', color: '#C66B4D' },
  { id: 'silkroad', icon: '🐪', color: '#2A9D8F' },
  { id: 'museum', icon: '🖼️', color: '#8E7CC3' },
  { id: 'craft', icon: '🧵', color: '#E08E45' },
  { id: 'living', icon: '🌆', color: '#4A9B8E' },
];

export const CATEGORY_MAP = Object.fromEntries(CATEGORIES.map((c) => [c.id, c])) as Record<
  CategoryId,
  { id: CategoryId; icon: string; color: string }
>;

/* ------------------------------------------------------------------ */
/*  reviews                                                            */
/* ------------------------------------------------------------------ */

export interface Review {
  name: string;
  from: string;
  rating: number;
  when: string;
  text: string;
  helpful: number;
}

/* ------------------------------------------------------------------ */
/*  per-city travel info                                               */
/* ------------------------------------------------------------------ */

export interface TravelInfo {
  /** primary category + extra feed filters */
  category: CategoryId;
  tags: CategoryId[];
  rating: number;
  reviewsCount: number;
  hours: string;
  ticket: string;
  bestTime: string;
  duration: string;
  budget: '$' | '$$' | '$$$';
  family: boolean;
  /** 0–100 popularity used by the feed */
  popularity: number;
  food: string[];
  tips: string[];
  reviews: Review[];
}

const T = (
  category: CategoryId,
  tags: CategoryId[],
  rating: number,
  reviewsCount: number,
  hours: string,
  ticket: string,
  bestTime: string,
  duration: string,
  budget: '$' | '$$' | '$$$',
  family: boolean,
  popularity: number,
  food: string[],
  tips: string[],
  reviews: Review[]
): TravelInfo => ({
  category,
  tags,
  rating,
  reviewsCount,
  hours,
  ticket,
  bestTime,
  duration,
  budget,
  family,
  popularity,
  food,
  tips,
  reviews,
});

export const TRAVEL: Record<string, TravelInfo> = {
  samarkand: T(
    'unesco',
    ['silkroad', 'ancient'],
    4.9,
    18432,
    'Registan 8:00–20:00 · Shah-i-Zinda 7:00–19:00',
    '$8 combo (Registan) · Gur-e-Amir $4',
    'Apr–May & Sep–Oct, golden hour',
    '2–3 days',
    '$$',
    true,
    98,
    ['Oshi pilaf at a chaikhana', 'Samsa from the bazaar tandoor', 'Non bread from Siyob market'],
    [
      'Buy the combined ticket — it covers Registan, Gur-e-Amir and Bibi-Khanym.',
      'Dress modestly for Shah-i-Zinda; scarves are lent free at the gate.',
      'Registan lights up for the sound-and-light show after dusk.',
    ],
    [
      {
        name: 'Amira K.',
        from: 'Dubai, UAE',
        rating: 5,
        when: '2 weeks ago',
        text: 'The Registan at sunset genuinely made me gasp. Tilework that changes colour with the light — nothing prepares you.',
        helpful: 214,
      },
      {
        name: 'Dmitry P.',
        from: 'Moscow, Russia',
        rating: 5,
        when: '1 month ago',
        text: 'Hired a local guide near the ticket office for $15 — best decision. Three thousand years of history in one morning.',
        helpful: 98,
      },
      {
        name: 'Sarah & Tom',
        from: 'Manchester, UK',
        rating: 4,
        when: '2 months ago',
        text: 'Come early — by 10am the tour buses arrive. Siyob bazaar bread is worth the trip alone.',
        helpful: 76,
      },
    ]
  ),

  bukhara: T(
    'unesco',
    ['silkroad'],
    4.8,
    12764,
    'Old town always open · museums 9:00–18:00',
    'Kalyan $3 · Ark $4 · Zindon $3',
    'Apr–May & Sep–Oct, mornings',
    '1–2 days',
    '$$',
    true,
    94,
    ['Pilaf from the big cauldrons', 'Shashlik off the Lyabi-Hauz grills', 'Halva pounded before you'],
    [
      'The old town is car-free — wander from Kalyan to Lyabi-Hauz on foot.',
      'Carpets and suzanis: bargain to roughly half the first price, with tea.',
      'Evening squares fill with locals — best photos come after 17:00.',
    ],
    [
      {
        name: 'Yusuf A.',
        from: 'Istanbul, Türkiye',
        rating: 5,
        when: '3 weeks ago',
        text: 'Bukhara feels lived-in where Samarkand feels curated. Real craftsmen hammering brass two steps from 900-year-old minarets.',
        helpful: 187,
      },
      {
        name: 'Elena V.',
        from: 'Riga, Latvia',
        rating: 5,
        when: '1 month ago',
        text: 'Climbed the Kalyan minaret at dawn — 300 dinars well spent. The city of a thousand and one stories.',
        helpful: 91,
      },
    ]
  ),

  khiva: T(
    'unesco',
    ['silkroad', 'ancient'],
    4.7,
    9312,
    'Itchan Kala 8:00–20:00 (night pass till 22:00)',
    'All-Itchan pass $10 · Juma Mosque $5',
    'May & September, mornings',
    '1 day',
    '$',
    true,
    90,
    ['Shivit oshi — dill noodle pilaf', 'Tuhum barak fried dumplings', 'Khorezm green melon'],
    [
      'Your single ticket covers almost every minaret and madrasah inside the walls.',
      'Climb the Islam Khoja minaret late afternoon for the desert-gold panorama.',
      'Stay inside Itchan Kala — the mud walls glow at sunrise before day-trippers arrive.',
    ],
    [
      {
        name: 'Marion L.',
        from: 'Lyon, France',
        rating: 5,
        when: '1 week ago',
        text: 'Itchan Kala is a film set you can sleep in. We watched the moon rise over the watchtower from a rooftop café.',
        helpful: 143,
      },
      {
        name: 'Kenji O.',
        from: 'Osaka, Japan',
        rating: 4,
        when: '3 weeks ago',
        text: 'Very walkable and compact. The Juma Mosque forest of 200 wooden columns is unlike anything else.',
        helpful: 64,
      },
    ]
  ),

  tashkent: T(
    'living',
    ['museum', 'silkroad'],
    4.6,
    11021,
    'Old town 24h · metro 5:00–24:00 · museums 10:00–17:00',
    'Metro $0.15 per ride · mosques free',
    'Mar–May, evenings on Broadway',
    '2 days',
    '$$',
    true,
    92,
    ['Tashkent oshi pilaf at Besh Qozon', 'Chaykhana kebabs', 'Horse-meat sausage kazy'],
    [
      'Ride the metro — each station is a marble-and-chandelier museum.',
      'Chorsu bazaar mornings: bread, spices and the famous giant cauldrons of plov.',
      'Earthquake of 1966 rebuilt the city — Soviet wide avenues meet carved wooden madrasahs.',
    ],
    [
      {
        name: 'Aigerim T.',
        from: 'Almaty, Kazakhstan',
        rating: 5,
        when: '2 weeks ago',
        text: 'A capital that surprises: silk-cocoon domes next to brutalist theatres, and the best plov on earth.',
        helpful: 122,
      },
      {
        name: 'Robert M.',
        from: 'Berlin, Germany',
        rating: 4,
        when: '1 month ago',
        text: 'Green, huge, friendly. The Applied Arts Museum interior is a hidden masterpiece.',
        helpful: 58,
      },
    ]
  ),

  shakhrisabz: T(
    'unesco',
    ['ancient'],
    4.6,
    5410,
    'Ak-Saray grounds 8:00–19:00',
    'Ak-Saray $2 · Dorut Tilavat free',
    'Apr–Oct, mornings',
    'Half day',
    '$',
    true,
    78,
    ['Green mountain pilaf', 'Qatlama flaky bread', 'Mountain honey'],
    [
      'Ak-Saray’s 38 m gateway stump shows the scale Timur planned — taller than any gate of Samarkand.',
      'The mountain road over the Takhtakaracha pass is a destination itself.',
    ],
    [
      {
        name: 'Oleg S.',
        from: 'Kyiv, Ukraine',
        rating: 5,
        when: '2 months ago',
        text: 'Timur’s hometown, unhurried and authentic. The surviving portal made me feel tiny — in the best way.',
        helpful: 87,
      },
    ]
  ),

  termez: T(
    'ancient',
    ['museum'],
    4.5,
    3980,
    'Site museums 9:00–17:30 · ruins open air',
    'Fayaz Tepa $3 · Kara Tepa $3',
    'Oct–Apr, mornings',
    '1 day',
    '$',
    true,
    72,
    ['Surkhandarya samsa', 'Urauch rice dumplings', 'Sherbet from local mulberries'],
    [
      'Buddhist Uzbekistan: Fayaz Tepa and Kara Tepa predate the Islamic era by a millennium.',
      'Hakim at-Termezi mausoleum is a living pilgrimage site — visit respectfully.',
    ],
    [
      {
        name: 'Claudia B.',
        from: 'Rome, Italy',
        rating: 5,
        when: '1 month ago',
        text: 'Standing caves of Kara Tepa where monks meditated 1,700 years ago — goosebumps. The river border with Afghanistan adds drama.',
        helpful: 71,
      },
    ]
  ),

  karshi: T(
    'ancient',
    [],
    4.4,
    2140,
    'Kosh madrasahs 9:00–18:00',
    'Free · bridge viewpoint free',
    'Mar–May & Sep–Nov',
    'Half day',
    '$',
    true,
    62,
    ['Karshi shashlik', 'Sumsa-lép flatbread', 'Mulberry dried sweets'],
    [
      'Abdullah Khan’s 16th-century brick bridge once spanned the whole river — walk its humped spine.',
    ],
    [
      {
        name: 'Farruh N.',
        from: 'Tashkent, Uzbekistan',
        rating: 4,
        when: '3 weeks ago',
        text: 'Underrated stop between Samarkand and Termez. The twin madrasahs face each other like mirrors.',
        helpful: 33,
      },
    ]
  ),

  kokand: T(
    'craft',
    ['ancient'],
    4.5,
    3120,
    'Khudayar Khan Palace 9:00–17:00',
    'Palace $3 · Norbota free',
    'Mar–May & Sep–Oct',
    'Half day',
    '$',
    true,
    68,
    ['Fergana pilaf with quail eggs', 'Kokand halva', 'Uraida grape molasses'],
    [
      'The Khan’s palace has 19 surviving rooms of the 119 planned — the Throne Court stuns.',
      'Fergana Valley silk and woodcarving make the bazaar a craft safari.',
    ],
    [
      {
        name: 'Aisha R.',
        from: 'London, UK',
        rating: 5,
        when: '1 month ago',
        text: 'The last khan’s palace is faded grandeur done right — chipped turquoise but the gilded ceiling still sings.',
        helpful: 44,
      },
    ]
  ),

  margilan: T(
    'craft',
    ['silkroad'],
    4.6,
    2890,
    'Yodgorlik silk factory 8:30–17:30',
    'Factory tour $3',
    'Weekdays, mornings (looms running)',
    'Half day',
    '$',
    true,
    70,
    ['Margilan nan bread', 'Silk-road samsa', 'Mulberry sherbet'],
    [
      'Yodgorlik still boils cocoons and pulls silk by hand — buy khan-atlas straight from the loom.',
      'Ask to see the ikat dyeing yard: patterns are tied into the threads before weaving.',
    ],
    [
      {
        name: 'Hélène D.',
        from: 'Paris, France',
        rating: 5,
        when: '2 months ago',
        text: 'Watched ikat being born from cocoon to loom. My scarf cost less than lunch in Paris and carries a whole city in it.',
        helpful: 58,
      },
    ]
  ),

  urgench: T(
    'living',
    [],
    4.3,
    1870,
    'City open · regional museum 9:00–17:00',
    'Free',
    'Year-round',
    'Transit + 1 day',
    '$',
    true,
    58,
    ['Khorezm plov', 'Chak-chak sweets', 'Fermented camel milk'],
    [
      'Gateway to Khiva, 30 km west — stay here for cheaper hotels and take a taxi in.',
      'The plane-tree avenues of Independence Park glow amber in October.',
    ],
    [
      {
        name: 'Timur Zh.',
        from: 'Nur-Sultan, Kazakhstan',
        rating: 4,
        when: '2 weeks ago',
        text: 'Practical base for Khorezm. Cheap food, honest taxis, and the best melons I have ever eaten.',
        helpful: 21,
      },
    ]
  ),

  fergana: T(
    'living',
    ['craft'],
    4.4,
    1720,
    'City open · Rishton 20 km east',
    'Free',
    'Mar–May & Sep–Oct',
    '1 day',
    '$',
    true,
    60,
    ['Fergana dimlama stew', 'Rishton blue ceramics', 'Serious apricots'],
    [
      'Fergana city is the valley’s green planned capital — use it as base for Rishton and Margilan.',
    ],
    [
      {
        name: 'Nodira K.',
        from: 'Andijan, Uzbekistan',
        rating: 4,
        when: '1 month ago',
        text: 'Roses, plane trees, tidy boulevards — and the whole valley’s craft scene an hour away.',
        helpful: 19,
      },
    ]
  ),

  andijan: T(
    'living',
    ['ancient'],
    4.3,
    1520,
    'Babur literary museum 9:00–17:00',
    'Free',
    'Apr–Jun, mornings',
    'Half day',
    '$',
    true,
    56,
    ['Andijan nan', 'Babura-style pilaf', 'Boiled lamb with mountain herbs'],
    [
      'Babur’s hometown — the museum garden holds a 600-year-old plane tree he studied under.',
      'Jupiter (Jami) complex still rings five times a day, as it did on the Silk Road.',
    ],
    [
      {
        name: 'Viktor Ch.',
        from: 'Seoul, South Korea',
        rating: 4,
        when: '3 weeks ago',
        text: 'Came for Babur, stayed for the bazaar energy. The old plane tree is a monument to study itself.',
        helpful: 17,
      },
    ]
  ),

  navoi: T(
    'living',
    [],
    4.2,
    980,
    'City open · Sarmysh Gorge 40 km north',
    'Free',
    'Spring & autumn',
    'Transit + half day',
    '$',
    true,
    48,
    ['Navoi plov', 'Steppe lamb kebabs', 'Apricot kernels sweets'],
    [
      'Sarmysh Gorge hides 3,000+ petroglyphs in a canyon — an open-air ancient gallery.',
    ],
    [
      {
        name: 'Jasur M.',
        from: 'Bukhara, Uzbekistan',
        rating: 4,
        when: '1 month ago',
        text: 'A modern town by day, but drive north to Sarmysh and touch stone-age carvings before lunch.',
        helpful: 14,
      },
    ]
  ),

  jizzakh: T(
    'living',
    [],
    4.2,
    860,
    'City open · Zaamin National Park 60 km east',
    'Free',
    'May–Sep (mountain trails)',
    '1 day',
    '$',
    true,
    50,
    ['Jizzakh shurpa', 'Mountain trout', 'Pine-nut halva'],
    [
      'Zaamin is “Uzbek Switzerland” — juniper forest, springs and walnut groves at 1,700 m.',
    ],
    [
      {
        name: 'Anna F.',
        from: 'Warsaw, Poland',
        rating: 4,
        when: '2 months ago',
        text: 'Hiked Zaamin for a day of pine air between desert cities. Hot springs and golden forest.',
        helpful: 12,
      },
    ]
  ),

  gulistan: T(
    'living',
    [],
    4.1,
    640,
    'City open',
    'Free',
    'Year-round',
    'Transit',
    '$',
    true,
    42,
    ['Sirdaryo river fish', 'Melons of Mirzachul', 'Corn samsa'],
    [
      'Capital of the cotton Mirzachul steppe — the regional museum explains how desert became fields.',
    ],
    [
      {
        name: 'Bekzod S.',
        from: 'Tashkent, Uzbekistan',
        rating: 4,
        when: '3 weeks ago',
        text: 'Quiet green stop on the Tashkent–Jizzakh road with surprisingly great melons.',
        helpful: 9,
      },
    ]
  ),

  nukus: T(
    'museum',
    ['ancient'],
    4.7,
    4460,
    'Savitsky Museum 9:00–17:00 (closed Tue)',
    'Savitsky $6 · Mizdakhan free',
    'Year-round, mornings',
    '1 day',
    '$',
    true,
    74,
    ['Karakalpak borsmacak', 'Zhigerde pastry', 'Aral-region fish'],
    [
      'The Savitsky Museum guards the world’s second-largest collection of Russian avant-garde — in a desert capital.',
      'Pair with Mizdakhan necropolis and the ship graveyard of Mo‘ynoq at the dead Aral shore.',
    ],
    [
      {
        name: 'Igor F.',
        from: 'Prague, Czechia',
        rating: 5,
        when: '1 month ago',
        text: 'A museum pilgrimage. Two floors of avant-garde paintings that Stalin locked away, saved by one stubborn man.',
        helpful: 88,
      },
    ]
  ),
};

/* ------------------------------------------------------------------ */
/*  weather — deterministic seasonal climate model                     */
/* ------------------------------------------------------------------ */

export type WeatherCondition = 'sunny' | 'clear' | 'cloudy' | 'rain' | 'snow' | 'wind';

export const WEATHER_STYLE: Record<WeatherCondition, { icon: string }> = {
  sunny: { icon: '☀️' },
  clear: { icon: '🌤️' },
  cloudy: { icon: '☁️' },
  rain: { icon: '🌧️' },
  snow: { icon: '❄️' },
  wind: { icon: '💨' },
};

/** monthly mean high °C by climate band (desert / valley / mountain-edge) */
const CLIMATE: Record<'desert' | 'valley' | 'mountain', number[]> = {
  desert:   [7, 10, 16, 23, 29, 35, 37, 35, 29, 20, 13, 8],
  valley:   [6, 9, 15, 22, 28, 34, 36, 34, 28, 19, 12, 7],
  mountain: [2, 4, 10, 17, 23, 29, 31, 30, 24, 16, 9, 3],
};

const CITY_CLIMATE: Record<string, 'desert' | 'valley' | 'mountain'> = {
  samarkand: 'valley', bukhara: 'desert', khiva: 'desert', urgench: 'desert',
  nukus: 'desert', tashkent: 'valley', margilan: 'valley', kokand: 'valley',
  fergana: 'valley', andijan: 'valley', jizzakh: 'mountain', gulistan: 'valley',
  navoi: 'desert', karshi: 'valley', termez: 'desert', shakhrisabz: 'mountain',
};

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) / 4294967295;
}

export interface Weather {
  tempC: number;
  condition: WeatherCondition;
  icon: string;
}

/** stable pseudo-weather for "right now" — same result all day */
export function weatherFor(cityId: string, now = new Date()): Weather {
  const band = CITY_CLIMATE[cityId] ?? 'valley';
  const month = now.getMonth();
  const mean = CLIMATE[band][month];
  const jitter = Math.round(hash(`${cityId}:${now.getDate()}`) * 6 - 3);
  const tempC = mean + jitter;

  let condition: WeatherCondition;
  if (band === 'desert') {
    condition = month >= 5 && month <= 8 ? 'sunny' : hash(cityId + month) > 0.75 ? 'cloudy' : 'sunny';
  } else if (band === 'mountain') {
    condition = month <= 1 || month === 11 ? 'snow' : hash(cityId + month) > 0.7 ? 'rain' : month >= 4 && month <= 9 ? 'sunny' : 'cloudy';
  } else {
    condition = hash(cityId + month) > 0.78 ? 'rain' : month >= 4 && month <= 9 ? 'sunny' : 'clear';
  }
  if (month === 2 || month === 3) condition = hash(cityId + 'wind') > 0.6 ? 'wind' : condition;

  return { tempC, condition, icon: WEATHER_STYLE[condition].icon };
}

/* ------------------------------------------------------------------ */
/*  distance + ETA (real haversine over WGS84)                         */
/* ------------------------------------------------------------------ */

export function distanceKm(fromCityId: string, toCityId: string): number {
  const a = CITY_GEO[fromCityId];
  const b = CITY_GEO[toCityId];
  if (!a || !b) return 0;
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLon = ((b.lon - a.lon) * Math.PI) / 180;
  const la1 = (a.lat * Math.PI) / 180;
  const la2 = (b.lat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin(dLon / 2) ** 2;
  return Math.round(2 * R * Math.asin(Math.sqrt(h)));
}

/** the visitor's travel hub — where "distance from you" is measured */
export const HOME_CITY = 'tashkent';

export function etaCar(km: number): string {
  const minutes = Math.round((km / 72) * 60);
  if (minutes < 60) return `${minutes} min`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m ? `${h} h ${m} min` : `${h} h`;
}

export function etaWalk(km: number): string | null {
  if (km > 25) return null;
  const minutes = Math.round((km / 4.8) * 60);
  if (minutes < 60) return `${Math.max(1, minutes)} min`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m ? `${h} h ${m} min` : `${h} h`;
}

export function formatKm(km: number): string {
  return km < 1 ? '<1 km' : `${km.toLocaleString('en-US')} km`;
}

/* ------------------------------------------------------------------ */
/*  feed helpers                                                       */
/* ------------------------------------------------------------------ */

/** best showcase era per city for the feed/detail (falls back when missing) */
export const SHOWCASE_ERA: Record<string, EraId> = {
  samarkand: 'timurid',
  bukhara: 'islamic',
  khiva: 'khanates',
  tashkent: 'modern',
  shakhrisabz: 'timurid',
  termez: 'ancient',
  karshi: 'timurid',
  kokand: 'khanates',
  margilan: 'timurid',
  urgench: 'khanates',
  fergana: 'modern',
  andijan: 'timurid',
  navoi: 'soviet',
  jizzakh: 'soviet',
  gulistan: 'soviet',
  nukus: 'modern',
};

export const ALL_CITY_IDS = Object.keys(TRAVEL);
