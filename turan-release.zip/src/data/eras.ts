export type EraId =
  | 'ancient'
  | 'hellenistic'
  | 'islamic'
  | 'timurid'
  | 'khanates'
  | 'soviet'
  | 'modern';

export interface Era {
  id: EraId;
  label: string;
  startYear: number;
  endYear: number;
  color: string;
  icon: string;
  description: string;
}

export const ERAS: Era[] = [
  {
    id: 'ancient',
    label: 'Ancient',
    startYear: -6000,
    endYear: -329,
    color: '#C66B4D',
    icon: '🏛️',
    description: 'First civilizations, Sogdians, Zoroastrianism',
  },
  {
    id: 'hellenistic',
    label: 'Hellenistic',
    startYear: -329,
    endYear: 651,
    color: '#B8952E',
    icon: '⚔️',
    description: 'Alexander, Greco-Bactrian, Kushan Empire',
  },
  {
    id: 'islamic',
    label: 'Islamic Golden',
    startYear: 651,
    endYear: 1220,
    color: '#2A9D8F',
    icon: '🕌',
    description: 'Arab conquest, Samanids, Avicenna, Al-Biruni',
  },
  {
    id: 'timurid',
    label: 'Timurid',
    startYear: 1220,
    endYear: 1500,
    color: '#D4A53C',
    icon: '⭐',
    description: 'Timur, Registan, Ulugh Beg, Golden Age',
  },
  {
    id: 'khanates',
    label: 'Khanates',
    startYear: 1500,
    endYear: 1876,
    color: '#9E2A2B',
    icon: '⚜️',
    description: 'Bukhara, Khiva, Kokand Khanates',
  },
  {
    id: 'soviet',
    label: 'Soviet',
    startYear: 1876,
    endYear: 1991,
    color: '#6C7A89',
    icon: '🔴',
    description: 'Russian conquest, Soviet era, independence',
  },
  {
    id: 'modern',
    label: 'Modern',
    startYear: 1991,
    endYear: 2024,
    color: '#D4A53C',
    icon: '🌆',
    description: 'Independent Uzbekistan, Mirziyoyev era',
  },
];

export const ERA_MAP: Record<EraId, Era> = Object.fromEntries(
  ERAS.map((e) => [e.id, e])
) as Record<EraId, Era>;

export function eraForYear(year: number): Era {
  for (let i = ERAS.length - 1; i >= 0; i--) {
    if (year >= ERAS[i].startYear) return ERAS[i];
  }
  return ERAS[0];
}
