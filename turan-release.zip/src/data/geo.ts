/**
 * TURAN geographic projection — a real equirectangular projection of
 * Uzbekistan (lon 55.5→73.5E, lat 45.7→36.9N) onto a 1000×640 canvas.
 * Shared by MapCanvas (SVG) and the city marker coordinates in cities.ts
 * so markers sit at their true geographic positions.
 */

export const MAP_W = 1000;
export const MAP_H = 640;
/** V3 atlas margins around the country plate (viewBox units) */
export const ATLAS_OX = 240;
export const ATLAS_OY = 190;

const LON_MIN = 55.5;
const LON_MAX = 73.5;
const LAT_MAX = 45.7;
const LAT_MIN = 36.9;

export function project(lon: number, lat: number): { x: number; y: number } {
  return {
    x: ((lon - LON_MIN) / (LON_MAX - LON_MIN)) * MAP_W,
    y: ((LAT_MAX - lat) / (LAT_MAX - LAT_MIN)) * MAP_H,
  };
}

/** same projection expressed in % of the canvas (for HTML markers) */
export function projectPct(lon: number, lat: number): { x: number; y: number } {
  const p = project(lon, lat);
  return { x: (p.x / MAP_W) * 100, y: (p.y / MAP_H) * 100 };
}

/** geographic city positions (WGS84) — the authoritative source of marker x/y */
export const CITY_GEO: Record<string, { lon: number; lat: number }> = {
  samarkand: { lon: 66.96, lat: 39.65 },
  bukhara: { lon: 64.42, lat: 39.77 },
  khiva: { lon: 60.36, lat: 41.38 },
  shakhrisabz: { lon: 66.83, lat: 39.06 },
  termez: { lon: 67.28, lat: 37.23 },
  karshi: { lon: 65.79, lat: 38.86 },
  tashkent: { lon: 69.24, lat: 41.3 },
  margilan: { lon: 71.72, lat: 40.47 },
  kokand: { lon: 70.94, lat: 40.55 },
  urgench: { lon: 60.63, lat: 41.55 },
  fergana: { lon: 71.78, lat: 40.39 },
  andijan: { lon: 72.34, lat: 40.78 },
  navoi: { lon: 65.38, lat: 40.08 },
  jizzakh: { lon: 67.84, lat: 40.12 },
  gulistan: { lon: 68.78, lat: 40.49 },
  nukus: { lon: 59.61, lat: 42.47 },
};

/** Uzbekistan border — [lon, lat] pairs, clockwise from the western Ustyurt */
export const BORDER_GEO: [number, number][] = [
  [56.05, 42.35], [55.99, 43.5], [56.6, 44.4], [57.4, 45.0], [58.5, 45.3],
  [59.2, 45.6], [60.3, 45.45], [61.2, 44.8], [62.0, 44.15], [62.8, 43.7],
  [63.6, 43.5], [64.4, 43.9], [65.4, 43.7], [66.3, 43.4], [66.9, 42.8],
  [67.8, 42.6], [68.6, 42.7], [69.3, 42.1], [69.9, 41.6], [70.6, 41.5],
  [70.85, 42.0], [71.3, 42.5], [71.65, 42.15], [72.2, 41.85], [72.9, 41.55],
  [73.2, 41.0], [73.15, 40.5], [72.85, 40.15], [72.3, 40.1], [71.6, 40.0],
  [70.8, 39.7], [70.0, 39.9], [69.2, 40.1], [68.7, 39.85], [68.3, 39.55],
  [68.5, 39.0], [68.4, 38.6], [67.9, 38.4], [67.6, 38.15], [67.5, 37.6],
  [67.3, 37.25], [66.6, 37.45], [66.0, 37.75], [65.5, 37.9], [64.8, 37.75],
  [64.6, 37.35], [63.5, 37.9], [62.8, 38.2], [62.0, 38.5], [61.0, 38.75],
  [60.3, 39.2], [60.0, 39.75], [59.5, 40.05], [59.0, 40.6], [58.6, 41.0],
  [58.0, 41.35], [57.0, 41.9], [56.4, 42.0],
];

/** Great rivers — polyline geography */
export const RIVERS_GEO: { name: string; pts: [number, number][] }[] = [
  {
    name: 'Amu Darya',
    pts: [
      [67.5, 37.55], [66.6, 38.0], [65.4, 38.35], [64.2, 38.75], [63.2, 39.3],
      [62.4, 40.0], [61.6, 41.0], [60.8, 41.75], [59.9, 42.5], [59.2, 43.4],
      [58.95, 44.4], [59.3, 45.1],
    ],
  },
  {
    name: 'Syr Darya',
    pts: [
      [73.0, 40.5], [71.9, 40.55], [70.4, 40.5], [69.5, 41.05], [68.6, 40.75],
      [67.5, 41.3], [66.3, 42.0], [65.0, 42.75],
    ],
  },
  {
    name: 'Zarafshan',
    pts: [[69.0, 39.35], [67.6, 39.6], [66.2, 39.8], [64.8, 39.9], [63.9, 40.0]],
  },
  {
    name: 'Chirchik',
    pts: [[70.1, 41.9], [69.6, 41.6], [69.25, 41.35]],
  },
];

/** Silk Road caravan routes */
export const ROUTES_GEO: { id: string; pts: [number, number][] }[] = [
  {
    id: 'trunk', // Merv → Bukhara → Samarkand → Tashkent → Fergana → Kashgar
    pts: [
      [61.2, 37.5], [62.6, 38.2], [63.7, 39.0], [64.4, 39.8], [65.6, 39.7],
      [66.9, 39.7], [67.9, 40.15], [68.7, 40.7], [69.3, 41.3], [70.2, 40.95],
      [71.0, 40.6], [72.2, 40.5], [73.4, 40.55],
    ],
  },
  {
    id: 'khiva', // Bukhara → Khiva → Urgench → Mangyshlak
    pts: [[64.4, 39.8], [63.0, 40.3], [61.7, 40.8], [60.7, 41.1], [60.4, 41.45], [59.6, 42.3], [58.9, 43.2]],
  },
  {
    id: 'south', // Samarkand → Shakhrisabz → Karshi → Termez → Balkh
    pts: [[66.9, 39.7], [66.8, 39.05], [66.1, 38.5], [66.4, 37.95], [67.2, 37.4], [67.45, 36.85]],
  },
];

/** Mountain relief zones (Tian Shan / Gissar / Pamir foothills) */
export const MOUNTAIN_ZONES: { pts: [number, number][]; peaks: [number, number][] }[] = [
  {
    // Tian Shan arc along the east
    pts: [[73.4, 42.6], [71.5, 42.4], [70.2, 41.9], [70.4, 41.3], [71.4, 41.0], [72.6, 41.3], [73.4, 41.8]],
    peaks: [[72.4, 41.9], [71.3, 41.6], [70.7, 41.5], [72.9, 41.3], [71.9, 41.2]],
  },
  {
    // Gissar / Turkestan ranges south of the Zarafshan
    pts: [[69.6, 39.4], [68.4, 39.2], [67.2, 39.1], [66.6, 38.9], [67.4, 38.5], [68.6, 38.6], [69.6, 38.9]],
    peaks: [[68.9, 39.0], [68.0, 38.9], [67.3, 38.8], [69.2, 39.1]],
  },
  {
    // Pamir foothills (Surkhandarya southeast)
    pts: [[68.4, 38.4], [67.8, 38.0], [67.5, 37.6], [68.1, 37.5], [68.5, 37.9]],
    peaks: [[68.1, 38.1], [67.8, 37.8]],
  },
];

/** Desert zones — stipple fields */
export const DESERT_ZONES: { cx: number; cy: number; rx: number; ry: number; rot?: number }[] = [
  { cx: 63.0, cy: 41.6, rx: 2.6, ry: 1.5 }, // Kyzylkum core
  { cx: 65.4, cy: 42.6, rx: 2.2, ry: 1.1 }, // Kyzylkum north
  { cx: 61.0, cy: 42.8, rx: 1.8, ry: 1.2 }, // Karakalpak sands
  { cx: 66.4, cy: 40.4, rx: 1.2, ry: 0.8 }, // Nurata steppe edge
];

export const LAKE_GEO = {
  aral: { lon: 59.2, lat: 45.05, rx: 0.85, ry: 0.55, rot: -18 },
  aydarkul: { lon: 66.6, lat: 41.15, rx: 0.55, ry: 0.14, rot: -8 },
  sarykamysh: { lon: 58.6, lat: 40.55, rx: 0.42, ry: 0.3, rot: 0 },
  tugai: null as null, // reserved
};

/** Historical region labels [text, lon, lat] */
export const REGION_LABEL_GEO: { text: string; lon: number; lat: number; size?: number }[] = [
  { text: 'K H O R E Z M', lon: 59.9, lat: 43.2, size: 13 },
  { text: 'KYZYLKUM', lon: 63.6, lat: 41.9, size: 10 },
  { text: 'S O G D I A N A', lon: 64.8, lat: 40.6, size: 13 },
  { text: 'CHACH', lon: 69.7, lat: 42.0, size: 10 },
  { text: 'FERGHANA', lon: 71.8, lat: 40.05, size: 10 },
  { text: 'B A C T R I A', lon: 65.8, lat: 38.2, size: 12 },
];

/** Neighbour labels sit outside the border */
export const NEIGHBOUR_LABEL_GEO: { text: string; lon: number; lat: number }[] = [
  { text: 'KAZAKHSTAN', lon: 63.5, lat: 44.9 },
  { text: 'KARAKALPAKSTAN', lon: 57.6, lat: 44.35 },
  { text: 'TURKMENISTAN', lon: 62.4, lat: 37.5 },
  { text: 'TAJIKISTAN', lon: 70.6, lat: 38.9 },
  { text: 'KYRGYZSTAN', lon: 72.3, lat: 42.3 },
  { text: 'AFGHANISTAN', lon: 68.6, lat: 37.0 },
];
