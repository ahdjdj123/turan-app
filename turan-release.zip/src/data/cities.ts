import type { EraId } from './eras';
import { RICH, type GalleryItem, type Figure, type EraEvent } from './cities-rich';

export type { GalleryItem, Figure, EraEvent };

export interface Landmark {
  name: string;
  detail: string;
}

export interface CityEraContent {
  tagline: string;
  description: string;
  landmarks: Landmark[];
  fact: string;
}

export interface City {
  id: string;
  name: string;
  /** localized city names */
  names: { ru: string; uz: string; ar: string; tr: string };
  founded: string;
  /** position on the geographic map, in % of canvas (see data/geo.ts projection) */
  x: number;
  y: number;
  major?: boolean;
  eras: Partial<Record<EraId, CityEraContent>>;
}

/**
 * The museum-exhibition content for one city×era: the base entry merged
 * with the deep layer in cities-rich.ts (story, figures, events, facts,
 * sources, gallery). Everything degrades gracefully.
 */
export interface MergedEraContent {
  tagline: string;
  /** short 2–4 sentence summary — the collapsed view */
  description: string;
  /** long-form exhibition paragraphs — THE STORY */
  story: string[];
  landmarks: Landmark[];
  figures?: Figure[];
  events?: EraEvent[];
  /** did-you-know cards (base fact first) */
  facts: string[];
  sources?: string[];
  gallery: GalleryItem[];
  region: string;
  highlights: string[];
}

/** merge base + rich for a city era; null when the era has no content */
export function getMergedContent(city: City, eraId: EraId): MergedEraContent | null {
  const base = city.eras[eraId];
  if (!base) return null;
  const rich = RICH[city.id];
  const richEra = rich?.eras[eraId];
  const gallery = [
    ...(rich?.gallery ?? []).filter((g) => !g.eras || g.eras.includes(eraId)),
    ...(richEra?.gallery ?? []),
  ];
  return {
    tagline: base.tagline,
    description: base.description,
    story: richEra?.story ?? (base.description ? [base.description] : []),
    landmarks: base.landmarks,
    figures: richEra?.figures,
    events: richEra?.events,
    facts: [base.fact, ...(richEra?.facts ?? [])],
    sources: richEra?.sources,
    gallery,
    region: rich?.region ?? '',
    highlights: rich?.highlights ?? [],
  };
}

export const CITIES: City[] = [
  {
    id: 'samarkand',
    name: 'Samarkand',
    names: { ru: 'Самарканд', uz: 'Samarqand', ar: 'سمرقند', tr: 'Semerkand' },
    founded: '742 BCE',
    x: 63.7,
    y: 68.8,
    major: true,
    eras: {
      ancient: {
        tagline: 'Maracanda — the city Alexander never forgot',
        description:
          'Known to the ancients as Maracanda, Samarkand was already a fortified capital of Sogdiana when Alexander the Great seized it in 329 BCE. Raised on the loess mound of Afrasiab, the city burned and rose again, its fire temples glowing over orchards fed by the Zarafshan river. Sogdian merchants made it a hinge between Persia, India and the steppe.',
        landmarks: [
          { name: 'Afrasiab Mound', detail: 'The layered ruins of pre-Mongol Samarkand, where archaeologists found the famous 7th-century Sogdian wall paintings of envoys and princesses.' },
          { name: 'Zoroastrian Fire Temple', detail: 'A shrine where the sacred flame was kept alive for centuries, before the city turned to new faiths.' },
        ],
        fact: 'Legend claims Alexander wept at Maracanda, saying he had heard the city was beautiful — but nothing had prepared him. He wed the Sogdian princess Roxana soon after.',
      },
      islamic: {
        tagline: 'Paper, poets and the Samanid orbit',
        description:
          'Under the Samanids of Bukhara, Samarkand became a jewel of the Islamic world. Around 751 CE the secret of paper-making arrived from Chinese captives — refined here and carried west toward Baghdad, transforming how civilizations wrote, traded and remembered. Madrasahs, caravanserais and turquoise domes filled the valley.',
        landmarks: [
          { name: 'Great Mosque of the 9th Century', detail: 'A cathedral-mosque of sun-baked brick at the heart of the early Islamic city, rebuilt many times before the Mongols.' },
          { name: 'Shah-i-Zinda (early shrine)', detail: 'A necropolis built around the grave of Qusam ibn Abbas, cousin of the Prophet — its earliest shrines predate the Timurids.' },
        ],
        fact: 'Samarkand paper was so prized that a 10th-century poet called the city "the mirror of the world" — its paper mills made Baghdad’s scribes envious.',
      },
      timurid: {
        tagline: 'Heart of the Empire',
        description:
          'Timur (Tamerlane) made Samarkand the capital of a world empire in 1370, dragging architects and artisans home from every campaign to build a city of incomparable splendour. His grandson Ulugh Beg raised an observatory here that measured the stars with astonishing precision, and the Registan square became the ceremonial heart of Asia.',
        landmarks: [
          { name: 'Registan Square', detail: 'The grand ensemble anchored by Ulugh Beg’s madrasah of 1420 — a university where astronomy, mathematics and philosophy were taught to thousands.' },
          { name: 'Bibi-Khanym Mosque', detail: 'Timur’s colossal Friday mosque of 1404, raised from the spoils of his Indian campaign, named for his beloved wife.' },
          { name: 'Gur-e Amir Mausoleum', detail: 'The ribbed turquoise dome beneath which Timur, Ulugh Beg and their dynasty rest — a blueprint for the Taj Mahal.' },
          { name: 'Ulugh Beg Observatory', detail: 'A vast sextant sunk into the hill at Rahimabad, where 1,018 stars were catalogued in the Zij-i Sultani of 1437.' },
        ],
        fact: 'The Registan was the ceremonial heart of the Timurid Empire — royal decrees were proclaimed from its portals to drumbeats heard across the city.',
      },
      soviet: {
        tagline: 'Railways, cotton and a brief capital',
        description:
          'The Russian railway reached Samarkand in 1888, and in 1925 the young Uzbek SSR chose it as capital — a title it held until Tashkent took over in 1930. Soviet decades brought trams, theatres and textile mills around the ancient core, while archaeologists quietly excavated Afrasiab.',
        landmarks: [
          { name: 'Samarkand Railway Station', detail: 'A century-old gateway built for the Central Asian railway, its brick façade greeting travelers since tsarist times.' },
          { name: 'Soviet-era Cultural Palace', detail: 'Constructivist civic architecture that framed the new socialist city around the old one.' },
        ],
        fact: 'Samarkand was the capital of the Uzbek SSR from 1925 to 1930 — only nine years, yet long enough to shape its boulevards and universities.',
      },
      modern: {
        tagline: 'UNESCO treasure, Uzbekistan’s shining face',
        description:
          'Independent Uzbekistan has restored Timurid Samarkand into a world stage: the Registan glows under floodlights, the Silk Road tourist city hosts a modern airport and high-speed rail, and in 2001 UNESCO inscribed it as a "Crossroads of Cultures".',
        landmarks: [
          { name: 'Registan (restored)', detail: 'Majolica and gold leaf returned to the madrasah portals — today a stage for the Sharq Taronalari music festival.' },
          { name: 'Silk Road Samarkand Complex', detail: 'A vast modern congress-and-gardens quarter opened in 2022, blending eight 21st-century pavilions with restored craft streets.' },
        ],
        fact: 'UNESCO listed Samarkand in 2001 as the "Crossroads of Cultures" — two thousand years of layered history in a single skyline.',
      },
    },
  },
  {
    id: 'bukhara',
    name: 'Bukhara',
    names: { ru: 'Бухара', uz: 'Buxoro', ar: 'بخارى', tr: 'Buhara' },
    founded: '4th century BCE',
    x: 49.6,
    y: 67.4,
    major: true,
    eras: {
      ancient: {
        tagline: 'Sogdian oasis on the desert road',
        description:
          'Rising from the Kyzylkum’s edge, Bukhara began as a Sogdian trading post where caravans watered before the great desert crossings. Its citadel — the Ark — counted dynasties like sand grains in an hourglass, and its bazaars were a byword for plenty.',
        landmarks: [
          { name: 'The Ark Citadel', detail: 'A fortress-city within a city, rebuilt for over a millennium — its walls later hid emirs, treasures and dungeons alike.' },
          { name: 'Old Caravanserai Quarter', detail: 'Stone courtyards where camel trains slept and silk was weighed against silver.' },
        ],
        fact: 'Bukhara’s bazaars were so legendary that a medieval saying claimed: "If you want to be rich, set your stall in Bukhara."',
      },
      islamic: {
        tagline: 'City of a thousand mosques — capital of the Samanids',
        description:
          'In the 9th and 10th centuries Bukhara was the Samanid capital and one of the great minds of Islam: Avicenna read philosophy in its libraries, al-Farabi walked its courtyards, and the Sufi poet-minister Jami later called it "the dome of Islam". Its brickwork still puzzles engineers.',
        landmarks: [
          { name: 'Samanid Mausoleum', detail: 'Circa 905 CE — a perfect cube-and-dome of woven brick, the oldest surviving Islamic monument in Central Asia.' },
          { name: 'Poi-Kalyan Ensemble', detail: 'The "Foot of the Great" — the Kalyan Minaret of 1127, a mosque that Genghis Khan himself spared.' },
          { name: 'Lyab-i Hauz', detail: 'A 17th-century pool framed by mulberry trees, teahouses and the statue of Khodja Nasreddin riding his donkey backwards.' },
        ],
        fact: 'The Kalyan Minaret earned the grim nickname "Tower of Death" — yet Genghis Khan, who burned Bukhara in 1220, looked up at it and ordered it spared.',
      },
      timurid: {
        tagline: 'The learned sister of Samarkand',
        description:
          'Under the Timurids and their successors, Bukhara thrived as Samarkand’s scholarly twin — a city of madrasahs, astronomical tables and covered bazaars whose domes sheltered booksellers and silk merchants.',
        landmarks: [
          { name: 'Ulugbek Madrasah', detail: 'Built 1417 by the astronomer-king himself, its portal proclaims: "The pursuit of knowledge is a duty on every Muslim." ' },
          { name: 'Domed Trading Arcades', detail: 'Toki — six stone domes built over crossroad bazaars where caps, silks and coins each had their own market.' },
        ],
        fact: 'Bukhara was known across Asia as "Bukhoro-i-Sharif" — Noble Bukhara — so holy that pilgrims ranked it just behind Mecca.',
      },
      khanates: {
        tagline: 'Seat of the Emirs',
        description:
          'From the Sheibanids through the Manghit emirs, Bukhara ruled a khanate that stretched to the Pamirs. Ambassadors, spies and runaway poets all passed through its gates; the bazaars sold Russian cotton, Kashmiri shawls and Bukharan gold embroidery.',
        landmarks: [
          { name: 'Chor Minor', detail: 'A whimsical four-towered gatehouse of 1807, part madrasah, part riddle — unlike anything else in the old city.' },
          { name: 'Bolo Haouz Mosque', detail: 'The emir’s Friday mosque of painted wooden columns facing the Ark, rebuilt in 1917.' },
        ],
        fact: 'When the Emir of Bukhara travelled, a hundred horsemen carried spare silversmith shops with him — the city’s goldwork was worn like armor.',
      },
      soviet: {
        tagline: 'Protectorate, revolution, museum city',
        description:
          'Bukhara became a Russian protectorate in 1868 and fell to the Bolsheviks in 1920, when Red artillery cracked the Ark and fire swept the old town. Restoration began in Soviet times, turning the emirate’s capital into an open-air museum of Islamic architecture.',
        landmarks: [
          { name: 'The Ark (damaged & restored)', detail: 'Shelled in 1920, the citadel was later patched and preserved — today its museum halls trace three thousand years.' },
          { name: 'Soviet Museum Quarter', detail: 'Early conservation studios that saved the Kalyan Minaret and mausoleums from decay.' },
        ],
        fact: 'In 1920 the Bukharan emir fled to Afghanistan on horseback, carrying the Koh-i-Noor-sized Peacock Throne gems — some have never resurfaced.',
      },
      modern: {
        tagline: 'UNESCO World Heritage Site',
        description:
          'UNESCO inscribed Historic Bukhara in 1993: over two hundred monuments — madrasahs, minarets, caravanserais and pools — packed into a living old town where craftsmen still hammer brass a street away from the Samanid dead.',
        landmarks: [
          { name: 'Historic Centre (UNESCO)', detail: 'A seamless medieval townscape preserved block by block since independence.' },
          { name: 'Silk & Spices Festival Streets', detail: 'Each spring the old town fills with ikat, gold embroidery and folk theatre.' },
        ],
        fact: 'More than 140 architectural monuments stand inside Bukhara’s old town — a density almost unmatched anywhere on Earth.',
      },
    },
  },
  {
    id: 'khiva',
    name: 'Khiva',
    names: { ru: 'Хива', uz: 'Xiva', ar: 'خيوة', tr: 'Hive' },
    founded: '6th century BCE',
    x: 27.0,
    y: 49.1,
    major: true,
    eras: {
      ancient: {
        tagline: 'Capital of Khorezm',
        description:
          'In the ancient delta of the Amu Darya, Khorezm grew rich on irrigation canals older than Rome. Tradition says Shem, son of Noah, founded a well here — "Kheyvah" — and pilgrims drank from it for two thousand years.',
        landmarks: [
          { name: 'Ancient Canal Networks', detail: 'Kyzylkum-locked fields fed by hand-dug canals — the hydraulic backbone of old Khorezm.' },
          { name: 'Desert Watch Fortresses', detail: 'Hundreds of mud-brick towers (qalas) stood guard over the delta’s caravan roads.' },
        ],
        fact: 'Ancient Khorezm’s astronomers calculated the solar year with remarkable accuracy centuries before Greenwich existed.',
      },
      islamic: {
        tagline: 'City of caravanserais',
        description:
          'Medieval Khiva grew into a walled ark of Islamic learning and craft. Inside Itchan Kala, the Juma Mosque was held up by a forest of carved columns — some reclaimed from 10th-century mosques — while scholars like al-Khwarizmi’s tradition drew maps of the world from Khorezmian tables.',
        landmarks: [
          { name: 'Itchan Kala', detail: 'The inner walled city — ten-metre walls of dried brick enclosing fifty monuments and hundreds of old courtyard houses.' },
          { name: 'Kunya-Ark Citadel', detail: 'The khans’ own fortress-within-a-fortress: throne room, harem, mint and lookout over the whole oasis.' },
          { name: 'Juma Mosque', detail: '213 wooden columns, some carved a thousand years ago, holding up a low, cool roof of whispering shade.' },
        ],
        fact: 'Some columns in the Juma Mosque were recycled from earlier buildings — the oldest carved pillars date to the 10th century.',
      },
      timurid: {
        tagline: 'Khorezm under the Timurid storm',
        description:
          'Khorezm passed between the Golden Horde and Timur’s empire; its great capital Gurganj (Urgench) was sacked in 1388 and its people carried to Samarkand. Khiva quietly inherited the dying oasis’s trade and crafts.',
        landmarks: [
          { name: 'Said Alauddin Mausoleum', detail: 'A jewel-box tile shrine of 1305 — among the earliest Timurid-era monuments standing in Khiva.' },
          { name: 'Old Caravanserai Gates', detail: 'Bent-axis entrances that still turn a caravan’s back to the desert wind.' },
        ],
        fact: 'After Timur razed Gurganj, the town’s entire population was reportedly marched to Samarkand to build his new capital.',
      },
      khanates: {
        tagline: 'Capital of the Khiva Khanate',
        description:
          'From 1511 Khiva ruled its own khanate — a state of slave-raiders, irrigators, poets and treaty-makers on the edge of empires. Russian officers, British spies and American travelers all left accounts of its slave markets and blue-tiled walls.',
        landmarks: [
          { name: 'Islam Khoja Minaret', detail: 'At 57 metres, the tallest minaret in Uzbekistan, finished in 1910 with glazed bands like a rocket of turquoise.' },
          { name: 'Tash Hauli Palace', detail: 'A 19th-century palace of 150 rooms wrapped around two courtyards of majolica peacocks and gardens.' },
        ],
        fact: 'Khiva’s khanate minted its own coins until 1920 — some bore verses calling the khan "Shadow of God on Earth".',
      },
      soviet: {
        tagline: 'The museum city',
        description:
          'The khanate fell in 1920; by 1967 Soviet planners had made old Khiva a protected museum-reserve, whitewashing its madrasahs and paving the desert road for busloads of curious citizens.',
        landmarks: [
          { name: 'Museum of Khorezm Art', detail: 'Kunya-Ark’s galleries of Khanate-era ceramics, calligraphy and photographs.' },
          { name: 'Itchan Kala Restoration', detail: 'Mid-century conservation that stabilized the walls and minarets visitors walk today.' },
        ],
        fact: 'Khiva became one of the USSR’s first urban museum-reserves — the whole inner city was declared "a monument" in 1967.',
      },
      modern: {
        tagline: 'Open-air museum — UNESCO World Heritage',
        description:
          'Itchan Kala was Uzbekistan’s first UNESCO site (1990). Today Khiva’s walls glow at sunset over a town of hotels in old madrasahs, and tourists walk the ramparts where khans once watched for raiders.',
        landmarks: [
          { name: 'Itchan Kala (UNESCO)', detail: 'Ninety-four monumental buildings inside a single wall — a city that is one museum.' },
          { name: 'Sunset Rampart Walk', detail: 'The ten-metre walls make a perfect promenade above turquoise domes.' },
        ],
        fact: 'Khiva’s Itchan Kala was inscribed by UNESCO in 1990 — the very first World Heritage site in Uzbekistan.',
      },
    },
  },
  {
    id: 'shakhrisabz',
    name: 'Shakhrisabz',
    names: { ru: 'Шахрисабз', uz: 'Shahrisabz', ar: 'شهر سبز', tr: 'Şehrisebz' },
    founded: '7th century BCE',
    x: 63.2,
    y: 75.5,
    eras: {
      ancient: {
        tagline: 'Kesh — the green city of Sogdiana',
        description:
          'Ancient Kesh ("green city") guarded the road over the Tashkurgan pass into Samarkand’s plain. Its Sogdian farmers terraced the foothills and its horsemen were feared across the valley — one of them, centuries later, would shake the world.',
        landmarks: [
          { name: 'Kesh Citadel', detail: 'An early fortress hill at the city’s heart, layered from antiquity to the Middle Ages.' },
          { name: 'Pass Road of Tashkurgan', detail: 'The stone-paved mountain highway linking Kesh to the great trade plains.' },
        ],
        fact: 'The name Shakhrisabz literally means "Green City" — a reference to the gardens that still climb its hillsides.',
      },
      islamic: {
        tagline: 'Early Islamic center of the foothills',
        description:
          'Under early Islamic dynasties Kesh kept its mint, its Friday mosque and its caravans. Artists here perfected the star-pattern brickwork that later blazed across Timurid portals.',
        landmarks: [
          { name: 'Old Friday Mosque Site', detail: 'Foundations of the pre-Timurid congregational mosque within the later complex.' },
          { name: 'Craftsmen’s Bazaar Row', detail: 'Lanes of potters and weavers who fed the building booms of the coming empire.' },
        ],
        fact: 'Kesh minted its own silver dirhams in the 8th century — coins still turn up in the city’s vegetable gardens.',
      },
      timurid: {
        tagline: 'Birthplace of Timur',
        description:
          'On 9 April 1336, a Barlas chieftain’s son named Timur was born in a village near Kesh. As emperor he rebuilt his hometown in marble — Ak-Saray’s gate towered over everything in Asia — and buried his favorite sons here at Dorus Saodat ("Seat of Power").',
        landmarks: [
          { name: 'Ak-Saray Palace', detail: 'Timur’s summer palace (1380–1404), whose surviving gate arch rose perhaps 65 metres — plastered with gold and Kufic mosaics.' },
          { name: 'Dorus Saodat Complex', detail: 'The "Seat of Power": tombs of Timur’s eldest sons Jahangir and Umar Shaykh, and a crypt intended for the emperor himself.' },
          { name: 'Kok Gumbaz Mosque', detail: 'The "Blue Dome" built in 1437 by Ulugh Beg for his father Shah Rukh — a dome of sky-turquoise tiles.' },
        ],
        fact: 'Ak-Saray’s gate inscription boasted: "If you doubt our power — look at our buildings." The arch alone was taller than anything else in Asia.',
      },
      soviet: {
        tagline: 'Agricultural center',
        description:
          'Soviet Shakhrisabz grew cotton and fruit around the crumbling palaces; conservation teams began rescuing Ak-Saray’s mosaics in the 1970s while tractors hummed below the towers.',
        landmarks: [
          { name: 'Ak-Saray Conservation Site', detail: 'Soviet-era stabilization of the great gate, preserving its famous mosaic coat of arms.' },
          { name: 'Orchard Terraces', detail: 'The hillside vineyards and orchards that gave the "Green City" its name.' },
        ],
        fact: 'Soviet engineers nearly built a highway straight through Ak-Saray’s ruins — preservationists stopped them just in time.',
      },
      modern: {
        tagline: 'UNESCO World Heritage Site',
        description:
          'UNESCO inscribed Shakhrisabz in 2000. Today the colossal ruin of Ak-Saray dwarfs a tidy modern city, and every 9 April locals celebrate the emperor born here — flowers on Dorus Saodat, polo in the square.',
        landmarks: [
          { name: 'Ak-Saray Gate (preserved)', detail: 'The surviving 38-metre pylon, its giant mosaic of a tiger chasing a white deer gleaming after restoration.' },
          { name: 'Dorum Tillavat Complex', detail: 'A Timurid necropolis-mosque ensemble with superb carved ceilings.' },
        ],
        fact: 'Shakhrisabz was added to UNESCO’s danger list in 2016 to protect its Timurid core from over-restoration — history’s watchdogs never sleep.',
      },
    },
  },
  {
    id: 'termez',
    name: 'Termez',
    names: { ru: 'Термез', uz: 'Termiz', ar: 'ترمذ', tr: 'Termiz' },
    founded: '5th century BCE',
    x: 65.4,
    y: 96.2,
    eras: {
      ancient: {
        tagline: 'Buddhist center of the Kushan Empire',
        description:
          'On the banks of the Oxus (Amu Darya), Termez flourished as a Buddhist stronghold under the Kushans — monasteries of whitewashed stupa courts faced the river while Sogdian and Indian merchants changed money on the quays.',
        landmarks: [
          { name: 'Kampyr Tepe', detail: 'A river-port citadel with watchtowers above the Oxus, where Buddhist relics and Greek coins were found side by side.' },
          { name: 'Fayaz Tepe', detail: 'A serene 1st-century monastery of courts and Buddha niches beneath the sandstone bluffs.' },
          { name: 'Zurmala Tower', detail: 'The stump of a giant brick stupa, the oldest standing Buddhist structure in Central Asia.' },
        ],
        fact: 'Termez lent its name to one of Islam’s four great schools of hadith — Imam al-Tirmidhi, compiler of the Jami’ at-Tirmidhi, was born here in 824.',
      },
      islamic: {
        tagline: 'Arab garrison town of the Oxus',
        description:
          'The Arab conquest made Termez a garrison and a gateway to Balkh; under the Samanids it grew a citadel, bazaars and scholars, though Mongols later swept it flat. Its mosques and ribats watched the river for a thousand years.',
        landmarks: [
          { name: 'Termez Citadel', detail: 'A fortified heart of the Islamic town, standing guard over the ferry crossings.' },
          { name: 'Sultan Saodat Complex', detail: 'Necropolis of the Termez Sayyids — generations of graves under fluted domes.' },
        ],
        fact: 'Al-Tirmidhi’s hadith collection is one of the "Six Books" of Sunni Islam — studied daily from Jakarta to Dakar.',
      },
      timurid: {
        tagline: 'Border fortress of the empire',
        description:
          'For the Timurids, Termez was the empire’s southern gate — a border fortress bristling with watchtowers, where Amirs reviewed troops before crossing the Oxus toward India or Balkh.',
        landmarks: [
          { name: 'Border Watchtowers', detail: 'Rammed-earth towers that scanned the southern bank for raiders and messengers.' },
          { name: 'Ribat Caravan Station', detail: 'A fortified inn where travelers, mail riders and pilgrims rested before the river crossing.' },
        ],
        fact: 'Timur’s armies crossed the Oxus here on pontoon bridges of leather skins — thousands of horses in a single dawn.',
      },
      soviet: {
        tagline: 'Closed border town',
        description:
          'Soviet Termez was a military town across the river from Afghanistan — closed to foreigners, full of airfields. From the Friendship Bridge, the Red Army rolled into Afghanistan in 1979 and rolled back home in 1989.',
        landmarks: [
          { name: 'Friendship Bridge', detail: 'The 1972 rail-road bridge over the Amu Darya — "the bridge to nowhere" that became the USSR’s gateway to Kabul.' },
          { name: 'Monument of Grief', detail: 'A weeping-mother memorial to the soldiers who never returned from Afghanistan.' },
        ],
        fact: 'The last Soviet soldier, General Boris Gromov, walked off the Friendship Bridge in 1989 — ending a decade of war in fifteen minutes.',
      },
      modern: {
        tagline: 'Gateway to Afghanistan',
        description:
          'Today Termez is Uzbekistan’s southern gate: a rail hub for Afghan trade, an archaeological park of Buddhist stupas, and home to the Termez Archaeological Museum — a small treasure-house of Kushan Buddhas and Bactrian gold.',
        landmarks: [
          { name: 'Termez Archaeological Museum', detail: 'Gandharan Buddhas, Kushan ivories and Graeco-Bactrian coins under one roof.' },
          { name: 'Kara Tepe Caves', detail: 'Rock-cut Buddhist cells dug into the bluffs, some still bearing faded murals.' },
        ],
        fact: 'Termez is the warmest city in Uzbekistan — summer thermometer readings top 45°C, perfect for a desert stupa.',
      },
    },
  },
  {
    id: 'karshi',
    name: 'Karshi',
    names: { ru: 'Карши', uz: 'Qarshi', ar: 'كارشي', tr: 'Karşı' },
    founded: '5th century BCE',
    x: 57.2,
    y: 77.7,
    eras: {
      ancient: {
        tagline: 'Nakhshab — Sogdian trading post',
        description:
          'Ancient Nakhshab sat on the road between Bukhara and Balkh, watered by the Kashka Darya. Sogdian traders, Zoroastrian priests and Persian garrisons all passed its gates — coins of every empire lie beneath its melon fields.',
        landmarks: [
          { name: 'Nakhshab Citadel', detail: 'The ancient tell at the city’s core, holding twenty-five centuries of mud-brick history.' },
          { name: 'Kashka Darya Canals', detail: 'Age-old waterways that made the oasis famous for melons long before cotton.' },
        ],
        fact: 'Nakhshab melons were sent to the caliphs of Baghdad packed in lead boxes — the first "air-freight" fruit of the Silk Road.',
      },
      islamic: {
        tagline: 'Qarakhanid center',
        description:
          'The Qarakhanid Turks made Karshi ("bridge") a center of their realm, building a beautiful domed mosque and caravanserais; the city survived Genghis Khan and prospered again under the khans of Bukhara.',
        landmarks: [
          { name: 'Kok Gumbaz Mosque', detail: 'A Qarakhanid-era domed Friday mosque of 1510, its portal striped with glazed brick.' },
          { name: 'Old Caravanserai (Rabat Malik)', detail: 'A courtyard inn where the Bukhara-Balkh road once collected its tolls.' },
        ],
        fact: 'The city’s very name means "bridge" — Karshi grew rich collecting tolls on the only stone bridge across the Kashka Darya.',
      },
      timurid: {
        tagline: 'Timur’s military base',
        description:
          'Timur loved Karshi: it was his muster-ground for campaigns, and he built a stone bridge here in the 1380s — ten arched spans that still carry pedestrians across the dry riverbed.',
        landmarks: [
          { name: 'Timur’s Bridge', detail: 'The 1380 stone bridge with ten elegant arches — one of the oldest surviving bridges in Central Asia.' },
          { name: 'Amir Timur Muster Field', detail: 'The plain east of the city where tumens assembled before India and Anatolia.' },
        ],
        fact: 'Timur’s Karshi bridge still stands after 600 years — pedestrians cross it today just as cavalry once did.',
      },
      soviet: {
        tagline: 'Cotton and gas',
        description:
          'Soviet Karshi became a cotton-processing center and then a gas-boom town; vast Soviet projects brought water from the Amu Darya to double the oasis in a single generation.',
        landmarks: [
          { name: 'Karshi Main Canal', detail: 'The 1940s mega-canal, dug partly by hand, that redirected the Amu Darya across the steppe.' },
          { name: 'Cotton Mill Quarter', detail: 'The industrial blocks where the oasis’s famous crop was ginned and pressed.' },
        ],
        fact: 'The Karshi canal is so wide that during Soviet celebrations it hosted rowing regattas in the desert.',
      },
      modern: {
        tagline: 'Regional capital',
        description:
          'Now the capital of Qashqadaryo region, Karshi blends a renovated Timurid center with a modern university city — and its melons are as sweet as when they went to Baghdad.',
        landmarks: [
          { name: 'Renovated Old Town Park', detail: 'Landscaped riverfront linking the Timurid bridge with new civic gardens.' },
          { name: 'Qashqadaryo Museum', detail: 'Regional archaeology from Nakhshab to the gas age.' },
        ],
        fact: 'Karshi hosts Uzbekistan’s premier horse-racing festival — the Karshi cup draws riders from all seven eras of its history.',
      },
    },
  },
  {
    id: 'tashkent',
    name: 'Tashkent',
    names: { ru: 'Ташкент', uz: 'Toshkent', ar: 'طشقند', tr: 'Taşkent' },
    founded: '2nd century BCE',
    x: 76.3,
    y: 50.0,
    major: true,
    eras: {
      ancient: {
        tagline: 'Chach — the stone city of the steppe edge',
        description:
          'Ancient Chach (Tashkent) commanded the Syr Darya’s fertile edge and the road north into the steppe. Its Sogdian lords traded horses, metal and grain long before any empire claimed the oasis.',
        landmarks: [
          { name: 'Shashtepa Hill', detail: 'The settlement mound of earliest Tashkent, with panoramic views over the modern capital.' },
          { name: 'Mingurik Mound', detail: 'Remains of the ancient citadel, where 2nd-century silos held the city’s grain.' },
        ],
        fact: '"Tashkent" means "Stone City" — its fortress was one of the few built of hewn stone rather than mud brick.',
      },
      islamic: {
        tagline: 'Qarakhanid center of learning',
        description:
          'Under the Qarakhanids, Tashkent grew a Friday mosque, madrasahs and mausoleums; its craftsmen cast superb bronzes, and Sufi masters drew students from across Mawarannahr.',
        landmarks: [
          { name: 'Kukeldash Madrasah', detail: 'A 16th-century college towering over Chorsu bazaar — once both school and caravanserai.' },
          { name: 'Chorsu Bazaar', detail: 'The ancient four-roads market under its giant green dome — trade here is older than the city walls.' },
        ],
        fact: 'A 9th-century astronomer of Chach, Ahmad al-Farghani’s colleague tradition, helped draw maps used by Columbus centuries later.',
      },
      timurid: {
        tagline: 'Timurid outpost of the north',
        description:
          'The Timurids held Tashkent as a northern outpost; governors minted coins, poets praised its gardens, and Yalangtush-style gateways hinted at the grandeur Samarkand was inventing.',
        landmarks: [
          { name: 'Sheikhantaur Complex', detail: 'Shrines around a legendary 14th-century saint and his miraculous pine trees.' },
          { name: 'Old City Gates Trail', detail: 'Timurid-era gates — Samarkand Darvoza among them — that gave the city its ring-road names.' },
        ],
        fact: 'Timurid Tashkent’s chief export was not silk but scholars — its jurists taught in Samarkand’s Registan.',
      },
      soviet: {
        tagline: 'Capital of the Uzbek SSR — the 1966 earthquake',
        description:
          'Tashkent became Soviet Uzbekistan’s capital in 1930. On 26 April 1966 an earthquake flattened 300,000 people’s homes; the whole USSR rebuilt the city in three years — wide avenues, marble metro stations (the first in Central Asia, 1977) and monumental squares.',
        landmarks: [
          { name: 'Independence Square', detail: 'The city’s ceremonial heart, crowned by the Monument of Independence and the Weeping Mother.' },
          { name: 'Amir Timur Museum', detail: 'A rotunda museum opened in 1996 around a soaring ceiling fresco of the emperor’s life.' },
          { name: 'Tashkent Metro', detail: 'Marble palaces underground — each station a Soviet art piece, and a nuclear shelter by design.' },
        ],
        fact: 'The 1966 Tashkent earthquake measured only 5.2 magnitude — but its shallow depth destroyed 78,000 buildings in eight seconds.',
      },
      modern: {
        tagline: 'Capital of independent Uzbekistan',
        description:
          'Independent Tashkent is Central Asia’s metropolis: glass towers over timber madrasahs, a new Tashkent City quarter, international film and food festivals, and a growing tech scene drawing the region’s youth.',
        landmarks: [
          { name: 'Tashkent City Park', detail: 'A gleaming 21st-century district of towers, fountains and light shows beside the old rows of plane trees.' },
          { name: 'Hazrati Imam Complex', detail: 'Home of the 8th-century Usman Quran — one of the world’s oldest, said to bear the Caliph’s bloodstains.' },
        ],
        fact: 'Tashkent’s Hazrati Imam library keeps the Usman Quran, an 8th-century manuscript many scholars call the world’s oldest complete Quran.',
      },
    },
  },
  {
    id: 'margilan',
    name: 'Margilan',
    names: { ru: 'Маргилан', uz: 'Marg‘ilon', ar: 'مرغيلان', tr: 'Margilan' },
    founded: '2nd century BCE',
    x: 90.1,
    y: 59.4,
    eras: {
      ancient: {
        tagline: 'Silk production center',
        description:
          'Legend says Alexander the Great passed here and was fed a chicken-and-bread feast — "murginon" — giving the town its name. Even earlier, mulberry orchards made Margilan the cradle of Central Asian silk.',
        landmarks: [
          { name: 'Ancient Mulberry Groves', detail: 'Terraces of mulberry trees — food for silkworms and shade for caravans — tended for two millennia.' },
          { name: 'Old Silk Road Bypass', detail: 'The valley track where caravans bought silk before crossing the Alai mountains.' },
        ],
        fact: 'Legend claims a Chinese princess smuggled silkworm eggs to Margilan in her bridal headdress — Central Asian silk began with one secret stolen for love.',
      },
      islamic: {
        tagline: 'Silk Road weaving center',
        description:
          'Medieval Margilan dyed and wove silk for all of Mawarannahr; its ikat (atlas) shimmered with blurred, rainbow patterns that madrasah poets compared to sunset clouds.',
        landmarks: [
          { name: 'Atlas Dye Vats', detail: 'Indigo, saffron and madder dye-pits where the famous "ikat cloud" patterns were tied by hand.' },
          { name: 'Said Akhmad-khoja Madrasah', detail: 'A 19th-century college of weavers, now the Silk Museum with working looms.' },
        ],
        fact: 'True Margilan atlas silk is tied-and-dyed before weaving — every metre is a one-of-a-kind painting.',
      },
      timurid: {
        tagline: 'Silk production heart of the valley',
        description:
          'Timurid Fergana shipped Margilan silk to Samarkand’s looms and beyond; the town’s weavers’ guild held festivals each spring when the mulberry buds broke.',
        landmarks: [
          { name: 'Weavers’ Guild Square', detail: 'The old marketplace where bolts of valley silk were auctioned to caravan merchants.' },
          { name: 'Mulberry Silk Workshops', detail: 'Family looms passing patterns from mother to daughter across centuries.' },
        ],
        fact: 'In Timurid accounts Margilan silk was measured not by metres but by "swords" — the length a sword could cover laid flat.',
      },
      soviet: {
        tagline: 'Textile industry giant',
        description:
          'Soviet power built enormous combine factories in Margilan; state atlas silk won medals at world expos while craft families kept the old hand-loom secrets alive at home.',
        landmarks: [
          { name: 'Margilan Silk Combine', detail: 'The vast Soviet-era mill that mechanized atlas weaving for the whole USSR.' },
          { name: 'Khan Atlas Factory', detail: 'A working factory-museum where visitors follow silk from cocoon to blouse.' },
        ],
        fact: 'Soviet atlas silk from Margilan was flown to Paris fashion shows in the 1960s — couturiers dubbed it "the fabric that blurs".',
      },
      modern: {
        tagline: 'Silk capital of Uzbekistan',
        description:
          'Margilan remains Uzbekistan’s silk capital: the Yodgorlik factory keeps hand-looms clacking, and the city hosts the annual Atlas Bayrami festival of ikat, khan-atlas fashion and mulberry sweets.',
        landmarks: [
          { name: 'Yodgorlik Silk Factory', detail: 'An authentic hand-loom workshop where every stage — cocoon to ikat — is done the ancient way.' },
          { name: 'Atlas Bayrami Festival', detail: 'A September street festival of silk, dance and craft contests.' },
        ],
        fact: 'UNESCO inscribed Margilan’s atlas and adras silk making on the Intangible Heritage list in 2017.',
      },
    },
  },
  {
    id: 'kokand',
    name: 'Kokand',
    names: { ru: 'Коканд', uz: 'Qo‘qon', ar: 'قوكند', tr: 'Kokand' },
    founded: '1732 CE',
    x: 85.8,
    y: 58.5,
    eras: {
      islamic: {
        tagline: 'Gate of the Fergana Valley',
        description:
          'Kokand grew at the valley’s western gate, where caravans paid tolls before climbing into the orchards of Fergana. Small on the Silk Road, it learned early the arts of both trade and war.',
        landmarks: [
          { name: 'Kokand Gate Caravanserai', detail: 'A toll-station inn at the valley mouth, where merchants rested before the climb.' },
          { name: 'Old Mosque Quarter', detail: 'Modest pre-khanate mosques that served the oasis towns around the future capital.' },
        ],
        fact: 'Kokand’s location made it "the gate of Fergana" — even today every road into the valley passes its outskirts.',
      },
      khanates: {
        tagline: 'Capital of the Kokand Khanate',
        description:
          'From 1709 the Ming dynasty of Kokand ruled a khanate from Tashkent to the Pamirs. Its grandest monument — Khudayar Khan’s palace of 1871 — has 119 rooms and a portal that took a thousand builders three years; the khanate fell to Russia only four years later.',
        landmarks: [
          { name: 'Palace of Khudayar Khan', detail: 'The "Urus Beg" palace: 19 surviving rooms of majolica, carved ganch and gilded ceilings.' },
          { name: 'Juma Mosque of 1818', detail: 'Umar Khan’s Friday mosque of 98 painted columns and a peaceful fig-tree courtyard.' },
          { name: 'Mausoleum of Umar Khan', detail: 'Tomb of the poet-khan and his family — Umar’s verses are still sung in Fergana.' },
        ],
        fact: 'Khudayar Khan built his palace with a hidden courtyard — legends say his 40 wives were never seen by the same man twice.',
      },
      soviet: {
        tagline: 'Regional center',
        description:
          'After 1918 Kokand briefly headed an anti-Bolshevik autonomy, was stormed, and settled into Soviet industry — chemical plants, railways and a famous engineering college.',
        landmarks: [
          { name: 'Kokand Railway Station', detail: 'A 1913 tsarist-era station that linked the valley to the wider empire.' },
          { name: 'Khudayar Palace Museum', detail: 'Soviet conservation turned the khan’s palace into the city’s museum heart.' },
        ],
        fact: 'Kokand’s 1917–18 Turkestan Autonomy lasted just 74 days — but it planted the first seeds of Central Asian self-rule.',
      },
      modern: {
        tagline: 'Cultural center of the valley',
        description:
          'Modern Kokand is Fergana’s cultural capital — restored palace, international film festival (the "Kokand Silk Road Fest"), and craft schools of woodcarving and knife-making.',
        landmarks: [
          { name: 'Restored Khudayar Palace', detail: 'Renovated halls and a new museum wing opened in the 2020s.' },
          { name: 'Craftsmen’s Quarter', detail: 'Woodcarvers, coppersmiths and the famous Kokand pichoq knife-makers at work.' },
        ],
        fact: 'A Kokand knife is a valued gift across Central Asia — blades are folded so finely they show water-like patterns.',
      },
    },
  },
  {
    id: 'urgench',
    name: 'Urgench',
    names: { ru: 'Ургенч', uz: 'Urganch', ar: 'أورگنج', tr: 'Ürgenç' },
    founded: 'Ancient',
    x: 28.5,
    y: 47.2,
    eras: {
      ancient: {
        tagline: 'Capital of Khorezm',
        description:
          'Gurganj — old Urgench — rose where caravan roads met the Amu Darya delta: capital of ancient Khorezm, city of irrigated gardens, astrologers and goldsmiths, the richest market between Baghdad and the Yellow River.',
        landmarks: [
          { name: 'Gurganj Citadel', detail: 'The great capital fortress of Khorezm, gate to a thousand canals.' },
          { name: 'Delta Irrigation Works', detail: 'A hydraulic lattice that turned desert into orchard — visible from satellite even today.' },
        ],
        fact: 'Gurganj was called "the crossroads of nations" — its bazaar sold jet stones from Persia, furs from the Volga and porcelain from China.',
      },
      islamic: {
        tagline: 'Khorezm’s golden age',
        description:
          'Under the Mamunids, Gurganj hosted the Mamun Academy — al-Biruni calculated the Earth’s radius here, Ibn Sina debated medicine in its libraries, and its minarets led the skyline of the Islamic east.',
        landmarks: [
          { name: 'Mamun Academy', detail: 'The world-class academy (c. 1000 CE) where al-Biruni and Avicenna worked under one patron.' },
          { name: 'Great Minaret of Gurganj', detail: 'A forerunner of the Kutlug Timur tower, its call to prayer floated over the delta.' },
        ],
        fact: 'Al-Biruni measured the Earth’s circumference at Gurganj in 1017 — within 2% of the modern value, using a mountain and an astrolabe.',
      },
      timurid: {
        tagline: 'Destroyed by Timur',
        description:
          'In 1388 Timur razed Gurganj after five brutal sieges; the canals were cut and the population marched to Samarkand. The city never recovered its old site — a new Urgench grew 30 km south, and the ruins passed to the desert.',
        landmarks: [
          { name: 'Kutlug Timur Minaret (ruins)', detail: 'A 60-metre tower that survived the massacre — the tallest pre-Timurid minaret standing in Central Asia.' },
          { name: 'Torebeg Hanym Mausoleum', detail: 'A stunning tile dome of the 12th century, spared amid the destruction.' },
        ],
        fact: 'Timur ordered the Amu Darya’s canals cut after taking Gurganj — the desert swallowed the capital within a decade.',
      },
      khanates: {
        tagline: 'Oasis town of the Khiva Khanate',
        description:
          'Under the Khiva khans, the ruined region slowly revived; new Urgench was a market town of Karakalpak and Turkmen herders at the edge of Khorezm’s recovering canals.',
        landmarks: [
          { name: 'New Urgench Bazaar', detail: 'The revived market linking Khiva to the Kazakh steppe trade.' },
          { name: 'Canal Reconstruction', detail: 'Khanate-era repairs of old Khorezm waterways.' },
        ],
        fact: 'For two centuries the ruins of old Gurganj were known as "Urgench the Dead" — shepherds pastured flocks inside minarets’ shadows.',
      },
      modern: {
        tagline: 'Gateway to ancient Khorezm',
        description:
          'Today Urgench is a bright modern city of cotton processing and aviation — the jumping-off point for Khiva, and for the monumental ruins of Konye-Urgench just across the Turkmen border.',
        landmarks: [
          { name: 'Urgench Aviation Museum', detail: 'A regional museum tracing flight over the Aral and Khorezm oases.' },
          { name: 'SavitISKAYA Street Gardens', detail: 'The green heart of the modern city, shaded by century-old plane trees.' },
        ],
        fact: 'Old Gurganj’s ruins across the border are now UNESCO-listed — modern Urgench keeps its name but not its ancient stones.',
      },
    },
  },
  {
    id: 'fergana',
    name: 'Fergana',
    names: { ru: 'Фергана', uz: 'Farg‘ona', ar: 'فرغانة', tr: 'Fergana' },
    founded: '1876 CE',
    x: 90.4,
    y: 60.3,
    eras: {
      khanates: {
        tagline: 'Orchards under the Kokand khans',
        description:
          'Before the Russians came, "New Margelan" was a khans’ estate of orchards and melon fields — the heart of a valley so fertile Chinese poets called it "the land of heavenly horses".',
        landmarks: [
          { name: 'Khan’s Orchard Estate', detail: 'The fruit gardens that fed the Kokand khans’ court.' },
          { name: 'Valley Horse Plains', detail: 'Pastures of the legendary Ferghana horses, coveted by Han emperors two millennia ago.' },
        ],
        fact: 'The "Heavenly Horses of Ferghana" made the Chinese Emperor Wudi launch a war in 104 BCE just to buy 3,000 of them.',
      },
      soviet: {
        tagline: 'Russian foundation, Soviet industry',
        description:
          'Founded as "New Margelan" in 1876 by General Skobelev, renamed Fergana in 1910 — the city became the valley’s oil, chemical and fertilizer hub, planned in broad Russian boulevards.',
        landmarks: [
          { name: 'Skobelev’s Grid Plan', detail: 'The rational boulevard layout with canals and poplars that still defines the center.' },
          { name: 'Fergana Oil Refinery', detail: 'One of the USSR’s earliest refineries, distilling valley crude since 1899.' },
        ],
        fact: 'Fergana was founded in 1876 — the same year the khanate fell, the valley’s newest city was born on its oldest orchards.',
      },
      modern: {
        tagline: 'Green capital of the valley',
        description:
          'Modern Fergana is the valley’s greenest city — plane-tree avenues, a scientific city of universities and museums, gateway to Margilan’s silks and the pamir road.',
        landmarks: [
          { name: 'Regional Museum of Local Lore', detail: 'Valley history from the Kushans to the refinery, under stately 19th-century facades.' },
          { name: 'Plane-Tree Boulevards', detail: 'A century of avenues so leafy the city is called "little Petersburg of the valley".' },
        ],
        fact: 'Fergana’s famous plane trees were planted in a single Soviet campaign — today they shade 40 kilometres of streets.',
      },
    },
  },
  {
    id: 'andijan',
    name: 'Andijan',
    names: { ru: 'Андижан', uz: 'Andijon', ar: 'أندجان', tr: 'Andican' },
    founded: '9th century CE (recorded)',
    x: 93.6,
    y: 55.9,
    eras: {
      islamic: {
        tagline: 'Silk Road city of the eastern valley',
        description:
          'Recorded from the 9th century, Andijan thrived as an eastern Fergana market town of cotton, fruit and craftsmen, surviving Mongol storms under its shaded bazaars.',
        landmarks: [
          { name: 'Old Town Bazaar', detail: 'The caravan market at the valley’s eastern mouth, trading silk for steppe horses.' },
          { name: 'Juma Mosque Foundations', detail: 'Early Islamic prayer hall rebuilt many times through the centuries.' },
        ],
        fact: 'Andijan’s bazaar was so central to valley life that medieval writers called the town simply "the market".',
      },
      timurid: {
        tagline: 'Birthplace of Babur',
        description:
          'In 1483 Zahiruddin Babur — heir of Timur and founder of the Mughal dynasty — was born in Andijan’s citadel. His memoirs sing of its pomegranates, its Friday mosque and its quick-witted people.',
        landmarks: [
          { name: 'Babur’s Citadel (site)', detail: 'The fortress where the young prince grew up, now marked by a memorial garden.' },
          { name: 'Babur Literary Museum', detail: 'Manuscripts and Mughal-era art celebrating Andijan’s most famous son.' },
        ],
        fact: 'Babur founded the Mughal Empire — the dynasty behind the Taj Mahal — after losing Andijan at age 12 and dreaming of it all his life.',
      },
      khanates: {
        tagline: 'Stronghold of the Kokand khans',
        description:
          'Andijan was a Kokand khanate stronghold, its walls repelling the khan’s rivals; its bazaars sold valley silk to Kashgar caravans over the mountains.',
        landmarks: [
          { name: 'Jami Madrasah', detail: 'A khanate-era college with a magnificent carved portal, still standing at the bazaar.' },
          { name: 'Kashgar Caravan Route Station', detail: 'The yard where traders loaded silk and paper for the mountain passes.' },
        ],
        fact: 'Andijan’s Jami Madrasah portal hides a maze of carved rosettes — no two of its 200 ornaments repeat.',
      },
      soviet: {
        tagline: 'Industrial engine of the valley',
        description:
          'Soviet Andijan built machine plants, a giant hydro dam (Andijan Reservoir) and textile mills; by the 1980s it was the most populous and industrious corner of the valley.',
        landmarks: [
          { name: 'Andijan Machine-Building Works', detail: 'A flagship Soviet plant producing cotton harvesters for the entire union.' },
          { name: 'Andijan Reservoir Dam', detail: 'The "Andijan Sea" — a mountain reservoir feeding valley irrigation canals.' },
        ],
        fact: 'Soviet Andijan built the world’s first cotton-picking machine plant — its harvesters worked fields from Uzbekistan to Egypt.',
      },
      modern: {
        tagline: 'The valley’s bustling north',
        description:
          'Independent Andijan is the valley’s most populous city — dynamic bazaars, the restored Babur Square, and a border-trade engine connecting Uzbekistan to Kyrgyzstan and China.',
        landmarks: [
          { name: 'Babur Square & Memorial', detail: 'A landscaped park honoring the Mughal founder with fountains and a statue.' },
          { name: 'Devonaboy Complex', detail: 'A grand modern mosque-and-market quarter in classic Timurid-revival style.' },
        ],
        fact: 'Andijan is among Uzbekistan’s densest cities — over 500,000 people live where Babur once raised his first standard.',
      },
    },
  },
  {
    id: 'navoi',
    name: 'Navoi',
    names: { ru: 'Навои', uz: 'Navoiy', ar: 'نافوي', tr: 'Nevay' },
    founded: '1958 CE',
    x: 54.9,
    y: 63.9,
    eras: {
      ancient: {
        tagline: 'Karmana — an oasis on the road to Bukhara',
        description:
          'Long before the industrial city, the ancient town of Karmana stood here — a Sogdian oasis stop on the Samarkand–Bukhara road, with forts, caravanserais and fig orchards.',
        landmarks: [
          { name: 'Karmana Settlement', detail: 'The ancient precursor town, its mounds still rising beside the modern city.' },
          { name: 'Nurata Road Caravanserai', detail: 'A wayside inn on the desert road north to the Nurata hills.' },
        ],
        fact: 'Ancient Karmana was praised as "the fig garden of Sogdiana" — its figs were tribute for Persian kings.',
      },
      islamic: {
        tagline: 'Caravan waystation of Mawarannahr',
        description:
          'Medieval Karmana kept its Friday mosque and caravanserais; Sufi travellers and merchants paused here between the two great capitals of Bukhara and Samarkand.',
        landmarks: [
          { name: 'Rabati Malik Caravanserai', detail: 'The "Royal Inn" of the 11th century — a fortress caravanserai on the Bukhara–Samarkand road.' },
          { name: 'Sardoba Malik', detail: 'A domed underground cistern of cool water, feeding caravans for 800 years.' },
        ],
        fact: 'The Sardoba Malik cistern could hold 3,000 cubic metres of water — an eleventh-century "gas station" for camel caravans.',
      },
      timurid: {
        tagline: 'Timurid road station',
        description:
          'Timur’s couriers galloped the Bukhara road past Karmana; the city supplied horses and grain to the imperial post system (yam) that linked Samarkand to the empire’s ends.',
        landmarks: [
          { name: 'Yam Courier Station', detail: 'Relay stables where imperial mail riders changed horses at full gallop.' },
          { name: 'Karmana Mosque (rebuilt)', detail: 'A Timurid-era congregational mosque serving the road town.' },
        ],
        fact: 'Timur’s couriers could carry a letter from Karmana to Samarkand — 160 km of desert — in under six hours, by relay.',
      },
      soviet: {
        tagline: 'Industrial city named for a poet',
        description:
          'The modern city was founded 1958 beside the Navoiy mining-chemical combine — named for the great Uzbek poet Alisher Navoi. It became the USSR’s uranium and gold heart: Muruntau mine in the nearby desert is the largest open-pit gold mine on Earth.',
        landmarks: [
          { name: 'Navoi Mining & Metallurgical Combine', detail: 'The industrial giant that processes Muruntau gold and uranium ores.' },
          { name: 'Alisher Navoi Central Park', detail: 'A vast green memorial park with the poet’s monument and rose gardens.' },
        ],
        fact: 'Muruntau, near Navoi, is the world’s largest open-pit gold mine — a 1.5 km-wide pit visible from space.',
      },
      modern: {
        tagline: 'Free economic zone and mining capital',
        description:
          'Independent Navoi leads Uzbekistan’s mining-tech boom: a special economic zone, a Chinese-Uzbek industrial park, and gold that now anchors the national economy.',
        landmarks: [
          { name: 'Navoi Free Economic Zone', detail: 'A modern industrial park of dozens of international factories.' },
          { name: 'Regional Theater of Navoi', detail: 'A landmark Soviet-modernist theater hosting Uzbek opera and drama.' },
        ],
        fact: 'Uzbekistan ranks among the world’s top-5 gold producers — most of it flows through Navoi’s mills.',
      },
    },
  },
  {
    id: 'jizzakh',
    name: 'Jizzakh',
    names: { ru: 'Джизак', uz: 'Jizzax', ar: 'جيزك', tr: 'Cizre (Cizah)' },
    founded: '1st millennium BCE',
    x: 69,
    y: 63.4,
    eras: {
      ancient: {
        tagline: 'Yaksiart — fortress on the steppe road',
        description:
          'Ancient Yaksiart (Jizzakh) guarded the "gate of Tamgaly" between steppe and sown. Sogdian farmers and Scythian riders met here — a frontier town of forts, horses and amber traders.',
        landmarks: [
          { name: 'Tamgaly Gates Fortress', detail: 'The mountain-pass fort that watched the steppe road for millennia.' },
          { name: 'Zaamin Forest Edge', detail: 'Ancient juniper woodland — a green wall between oasis and steppe.' },
        ],
        fact: 'Jizzakh means "salt flat" — the city grew rich taxing the white gold that caravans carried from the steppe pans.',
      },
      islamic: {
        tagline: 'Qarakhanid fortress town',
        description:
          'Under the Qarakhanids, Jizzakh was a fortress of the steppe frontier; its walls saw the last Muslim kingdoms resist the Mongol flood in 1219.',
        landmarks: [
          { name: 'Jizzakh Fortress', detail: 'A Qarakhanid stronghold, rebuilt under the khans and later the emirs.' },
          { name: 'Old Wall Bazaar', detail: 'A market that never closed — even under siege, bread was sold at the gate.' },
        ],
        fact: 'When Genghis Khan’s envoys demanded Jizzakh surrender, the defenders answered with arrows — the Mongols leveled the fort in 1220.',
      },
      timurid: {
        tagline: 'Timur’s northern muster camp',
        description:
          'Timur rebuilt Jizzakh as a muster camp against the Golden Horde; from here he rode north to defeat Tokhtamysh, and its gardens fed the largest army of its age.',
        landmarks: [
          { name: 'Amir Timur Muster Ground', detail: 'The plain where the army gathered before the great northern campaigns.' },
          { name: 'Jizzakh Usturapi Gardens', detail: 'Imperial gardens planted to feed and shade the troops.' },
        ],
        fact: 'Timur chose Jizzakh’s plains because its grass could feed 200,000 horses — an army that mowed the steppe like a locust swarm.',
      },
      soviet: {
        tagline: 'Cotton belt of the republic',
        description:
          'Soviet Jizzakh grew into a cotton and irrigation center, with vast canals, a university town and the Gagarin sanatorium in the juniper hills of Zaamin.',
        landmarks: [
          { name: 'Great Jizzakh Canal', detail: 'A Soviet-era waterway that greened the Hungry Steppe’s eastern edge.' },
          { name: 'Zaamin Sanatorium', detail: 'A mountain spa of juniper air, beloved across the USSR.' },
        ],
        fact: 'The Hungry Steppe around Jizzakh was called "Golodnaya Step" — Soviet canals turned 300,000 hectares of it into cotton.',
      },
      modern: {
        tagline: 'Free economic zone rising',
        description:
          'Independent Jizzakh hosts one of Uzbekistan’s largest special economic zones — dozens of factories, a modern zoo and lake, and the sprouting ski resort of Zaamin above.',
        landmarks: [
          { name: 'Jizzakh SEZ', detail: 'A fast-growing zone of foreign factories on the old cotton plain.' },
          { name: 'Zaamin National Park', detail: 'Ancient junipers, marals and the first Uzbek mountain ski resort.' },
        ],
        fact: 'Zaamin’s juniper forest is over 1,000 years old — some trees watched the Silk Road caravans pass below.',
      },
    },
  },
  {
    id: 'gulistan',
    name: 'Gulistan',
    names: { ru: 'Гулистан', uz: 'Guliston', ar: 'غليستان', tr: 'Gülistan' },
    founded: '19th century CE',
    x: 73.8,
    y: 59.2,
    eras: {
      khanates: {
        tagline: 'Ak-Kurgan fort of the Hungry Steppe',
        description:
          'Before the city, a Kokand-era fort called Ak-Kurgan ("white fortress") stood in the waveless wheat-colored steppe; herders and tax caravans crossed its horizon.',
        landmarks: [
          { name: 'Ak-Kurgan Fort', detail: 'The white-walled khanate fort at the edge of the steppe sea.' },
          { name: 'Nomad Route Wells', detail: 'Wells that stitched the waterless steppe between Tashkent and Jizzakh.' },
        ],
        fact: 'The Hungry Steppe once stretched 10,000 km² with not a single tree — Gulistan means "flower garden", the name of what it became.',
      },
      soviet: {
        tagline: 'Capital of the cotton frontier',
        description:
          'Founded 1891 as Golodnaya Stepka, Gulistan became the administrative capital of Syr Darya’s cotton colonization: canals, Russian settlers, Uzbeks, Kazakhs and Koreans built a green city in the desert.',
        landmarks: [
          { name: 'Grand Canal Headworks', detail: 'Where the Southern Golodnostepsky canal leaves the Syr Darya to water the steppe.' },
          { name: 'Gulistan Teacher’s College', detail: 'A 1920s modernist landmark of the frontier city.' },
        ],
        fact: 'In the 1950s Gulistan’s canal diggers included students from all over the USSR — turning "the Hungry Steppe" into a flower garden by hand.',
      },
      modern: {
        tagline: 'Regional capital',
        description:
          'Now the capital of Sirdaryo region, Gulistan processes grain, sugar and cotton, and its university quarter draws students from across the valley and steppe.',
        landmarks: [
          { name: 'Sirdaryo Regional Theater', detail: 'A modern stage in a green town, hosting Uzbek and Kazakh repertoire.' },
          { name: 'Gulistan Stadium Quarter', detail: 'A new sports cluster built for the city’s football renaissance.' },
        ],
        fact: 'Gulistan’s name was a Soviet-era promise kept — over 2 million trees now shade a city born in treeless dust.',
      },
    },
  },
  {
    id: 'nukus',
    name: 'Nukus',
    names: { ru: 'Нукус', uz: 'Nukus', ar: 'نوكوس', tr: 'Nukus' },
    founded: '1932 CE (modern)',
    x: 22.8,
    y: 36.7,
    eras: {
      ancient: {
        tagline: 'Shurcha — an oasis on the Amu Darya',
        description:
          'Long before the modern city, a small agricultural settlement called Shurcha stood on Nukus’ site, on the old channels of the Amu Darya delta, among the fortresses of ancient Khorezm.',
        landmarks: [
          { name: 'Shurcha Settlement', detail: 'The ancient precursor mound within the modern city’s edge.' },
          { name: 'Ayaz Qala View', detail: 'Desert fortresses on the horizon, guarding the delta for two millennia.' },
        ],
        fact: 'Nukus is ringed by over 50 desert fortresses (qalas) — the densest cluster of ancient forts on Earth.',
      },
      khanates: {
        tagline: 'Karakalpak lands under the khans',
        description:
          'In khanate times the delta was the Karakalpak homeland, contested by Khiva and Bukhara; herders and fishermen rowed the great river arms under Khivan tax riders.',
        landmarks: [
          { name: 'Karakalpak Yurt Camps', detail: 'Felt-domed camps along the river arms, patterned with red and white woven bands.' },
          { name: 'Khivan Tax Route Fort', detail: 'A small outpost where Khiva collected tribute from the fisherfolk.' },
        ],
        fact: 'The Karakalpaks are named for their black hats — "kara kalpak" means "black hat" — and their yurt bands record tribe and history.',
      },
      soviet: {
        tagline: 'Capital of Karakalpakstan — the Savitsky miracle',
        description:
          'Made capital of the Karakalpak ASSR in 1932, Nukus became famous for one man: Igor Savitsky, who smuggled tens of thousands of forbidden Russian avant-garde paintings to this desert city — now one of the world’s great art collections.',
        landmarks: [
          { name: 'Savitsky Museum (Nukus Museum of Art)', detail: '82,000 works — the world’s second-largest collection of Russian avant-garde, saved from Stalin’s censors in the desert.' },
          { name: 'Mizdakhan Necropolis', detail: 'A hill of mausoleums and a "watchtower of the silent" just outside the city.' },
        ],
        fact: 'The Savitsky Museum holds 82,000 artworks — including avant-garde pieces destroyed everywhere else, saved by a curator who pretended to "collect examples of decadence".',
      },
      modern: {
        tagline: 'Capital at the edge of the Aral',
        description:
          'Modern Nukus faces the Aral Sea crisis head-on: international donors, the Aral Sea museum, and resilient Karakalpak culture — with new eco-tourism to ship graveyards and drying seabed.',
        landmarks: [
          { name: 'Moenymak Ship Graveyard', detail: 'Rusted trawlers beached in the sand where the Aral Sea’s fishing fleet was left to die.' },
          { name: 'Aral Sea Ecology Museum', detail: 'A sober museum of the sea’s vanishing — and of the people who stayed.' },
        ],
        fact: 'The Aral Sea lost 90% of its volume in 50 years — Nukus’ fishing port of Moenymak now stands 150 km from open water.',
      },
    },
  },
];

export const CITY_MAP: Record<string, City> = Object.fromEntries(
  CITIES.map((c) => [c.id, c])
);

/** total discoverable city-era combinations */
export const TOTAL_COMBINATIONS = CITIES.reduce(
  (sum, c) => sum + Object.keys(c.eras).length,
  0
);
