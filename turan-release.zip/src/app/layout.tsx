import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond } from "next/font/google";
import "./globals.css";

/* the historical display serif — titles, city names, year numerals */
const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["500", "600", "700"],
  variable: "--font-cormorant",
  display: "swap",
});

export const metadata: Metadata = {
  title: "TURAN — The Heart of the Silk Road",
  description:
    "An interactive journey through 8,000 years of Uzbekistan history. Explore Samarkand, Bukhara, Khiva and more across seven historical eras.",
  keywords: [
    "Turan", "Silk Road", "Uzbekistan", "Samarkand", "Bukhara", "Khiva",
    "history", "interactive museum", "Timurids", "Timur",
  ],
  authors: [{ name: "Z.ai" }],
  manifest: "/manifest.webmanifest",
  applicationName: "TURAN",
  icons: {
    icon: [
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/icons/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  openGraph: {
    title: "TURAN — The Heart of the Silk Road",
    description: "An interactive historical museum of Uzbekistan — 8,000 years on the Silk Road.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#0D0B1A",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning className={cormorant.variable}>
      <body className="antialiased">{children}</body>
    </html>
  );
}
