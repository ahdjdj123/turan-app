import { NextRequest, NextResponse } from 'next/server';
import { createHash } from 'crypto';
import fs from 'fs/promises';
import path from 'path';

export const runtime = 'nodejs';

/**
 * POST /api/narrate
 * Body: { text: string, speed?: number }
 * Returns: audio/wav stream of the narrated text.
 * Generated WAVs are cached on disk (keyed by text+voice+speed) so repeated
 * narrations are served instantly without hitting the TTS backend again.
 * The z-ai-web-dev-sdk is used server-side only.
 */

const CACHE_DIR = path.join(process.cwd(), '.cache', 'narration');

async function readCache(key: string): Promise<Buffer | null> {
  try {
    const p = path.join(CACHE_DIR, `${key}.wav`);
    const stat = await fs.stat(p);
    if (stat.size > 500) return await fs.readFile(p);
  } catch {
    /* not cached */
  }
  return null;
}

async function writeCache(key: string, buf: Buffer): Promise<void> {
  try {
    await fs.mkdir(CACHE_DIR, { recursive: true });
    await fs.writeFile(path.join(CACHE_DIR, `${key}.wav`), buf);
  } catch {
    /* cache write is best-effort */
  }
}

function audioResponse(buf: Buffer, cache: 'HIT' | 'MISS') {
  return new NextResponse(new Uint8Array(buf), {
    status: 200,
    headers: {
      'Content-Type': 'audio/wav',
      'Content-Length': buf.length.toString(),
      'X-Narrate-Cache': cache,
      'Cache-Control': 'no-cache',
    },
  });
}

export async function POST(req: NextRequest) {
  try {
    const { text, speed } = (await req.json()) as { text?: string; speed?: number };

    if (!text || !text.trim()) {
      return NextResponse.json({ error: 'text is required' }, { status: 400 });
    }

    // enforce the 1024-char API limit: trim to the last full sentence under the cap
    let input = text.replace(/\s+/g, ' ').trim();
    if (input.length > 1000) {
      const cut = input.slice(0, 1000);
      const lastStop = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('! '), cut.lastIndexOf('? '));
      input = lastStop > 200 ? cut.slice(0, lastStop + 1) : cut;
    }

    const safeSpeed =
      typeof speed === 'number' && speed >= 0.5 && speed <= 2 ? speed : 0.95;

    const key = createHash('sha256')
      .update(`${input}::jam::${safeSpeed}`)
      .digest('hex');

    const cached = await readCache(key);
    if (cached) return audioResponse(cached, 'HIT');

    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();

    const response = await zai.audio.tts.create({
      input,
      voice: 'jam',
      speed: safeSpeed,
      response_format: 'wav',
      stream: false,
    });

    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(new Uint8Array(arrayBuffer));

    if (buffer.length < 500) {
      return NextResponse.json({ error: 'empty audio generated' }, { status: 502 });
    }

    void writeCache(key, buffer);
    return audioResponse(buffer, 'MISS');
  } catch (error) {
    console.error('TTS narrate error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'narration failed' },
      { status: 500 }
    );
  }
}
