import { NextResponse } from 'next/server';
import { readdir } from 'fs/promises';
import path from 'path';

export const dynamic = 'force-dynamic';

let cached: { count: number; at: number } | null = null;

/** Counts city-era artwork files (excludes menu_caravan and non-png). */
export async function GET() {
  // tiny cache to avoid re-listing on every settings visit
  if (cached && Date.now() - cached.at < 30_000) {
    return NextResponse.json(
      { count: cached.count },
      { headers: { 'X-Artwork-Cache': 'HIT' } }
    );
  }
  try {
    const dir = path.join(process.cwd(), 'public', 'images', 'cities');
    const files = await readdir(dir);
    const count = files.filter((f) => f.endsWith('.png') && f !== 'menu_caravan.png').length;
    cached = { count, at: Date.now() };
    return NextResponse.json({ count }, { headers: { 'X-Artwork-Cache': 'MISS' } });
  } catch {
    return NextResponse.json({ count: null, error: 'unavailable' }, { status: 200 });
  }
}
