import { TuranApp } from '@/components/turan/TuranApp';

export default function Page() {
  return <TuranApp />;
}
