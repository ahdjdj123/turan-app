'use client';

import { useTuranStore } from '@/lib/store';

const SW_URL = '/sw.js';

/** resolve once the current registration is fully gone (unregistration is async) */
async function waitUnregistered(timeoutMs = 3000): Promise<void> {
  const start = Date.now();
  while ((await navigator.serviceWorker.getRegistration()) && Date.now() - start < timeoutMs) {
    await new Promise((r) => setTimeout(r, 120));
  }
}

/**
 * Offline museum mode: registers the artwork-precaching service worker when
 * enabled, and fully removes it (plus its caches) when disabled.
 * A cache-busting query is used on (re)enable so the browser always starts a
 * fresh worker — re-registering the identical URL right after unregister can
 * silently skip the install (and therefore the precache) in some engines.
 */
export async function applyOfflineMode(enabled: boolean): Promise<void> {
  if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return;
  try {
    if (enabled) {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg) {
        await reg.unregister();
        await waitUnregistered();
      }
      await navigator.serviceWorker.register(`${SW_URL}?v=${Date.now()}`, { scope: '/' });
    } else {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg) {
        const worker = reg.active ?? reg.waiting ?? reg.installing;
        if (worker) {
          worker.postMessage('turan-clear-art');
          // give the SW a moment to clear caches before unregistering
          await new Promise((r) => setTimeout(r, 250));
        }
        await reg.unregister();
        await waitUnregistered();
      }
      const keys = await caches.keys();
      await Promise.all(
        keys.filter((k) => k.startsWith('turan-art-') || k.startsWith('turan-manifest-')).map((k) => caches.delete(k))
      );
    }
  } catch {
    /* SW unsupported/blocked (e.g. insecure context) — the app works fine without it */
  }
}

/** Wire the setting once at app start and on every change. */
export function watchOfflineMode(): () => void {
  let last = useTuranStore.getState().settings.offlineMode;
  void applyOfflineMode(last);
  const unsub = useTuranStore.subscribe((s) => {
    if (s.settings.offlineMode !== last) {
      last = s.settings.offlineMode;
      void applyOfflineMode(last);
    }
  });
  return unsub;
}
