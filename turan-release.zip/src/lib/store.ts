import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { EraId } from '@/data/eras';
import { ERA_MAP, eraForYear } from '@/data/eras';
import {
  DEFAULT_SETTINGS,
  type Settings,
  type Screen,
  type FocusCity,
  type AccentId,
  type ThemeId,
  type FontSizeId,
  type AnimSpeed,
  type QualityId,
  type LangId,
  type QuizDifficulty,
} from './turan-types';

const AUTOSAVE_FLAG_KEY = 'turan-autosave';

function autoSaveEnabled(): boolean {
  if (typeof window === 'undefined') return true;
  return window.localStorage.getItem(AUTOSAVE_FLAG_KEY) !== 'off';
}

const storage = {
  getItem: (name: string): string | null => {
    if (typeof window === 'undefined') return null;
    return window.localStorage.getItem(name);
  },
  setItem: (name: string, value: string): void => {
    if (typeof window === 'undefined') return;
    if (autoSaveEnabled()) {
      try {
        window.localStorage.setItem(name, value);
      } catch {
        /* storage full or blocked — ignore */
      }
    }
  },
  removeItem: (name: string): void => {
    if (typeof window === 'undefined') return;
    window.localStorage.removeItem(name);
  },
};

interface TuranState {
  hydrated: boolean;
  screen: Screen;
  year: number;
  discovered: string[];
  pendingFocus: FocusCity | null;
  lastSaved: number | null;
  quizBest: number;
  quizDifficulty: QuizDifficulty;
  /** best moves for the great caravan (8 pairs) */
  memoryBest: number;
  /** best moves for the small caravan (6 pairs) */
  memoryBest6: number;
  /** best moves for the caravan cub (4 pairs) */
  memoryBest4: number;
  /** total Random Discovery wheel spins */
  spinCount: number;
  /** spins that revealed a combination NOT yet in the journal */
  spinNew: number;
  /** per-era quiz answers, keyed by era id: { asked, correct } */
  quizMastery: Partial<Record<EraId, { asked: number; correct: number }>>;
  settings: Settings;

  setScreen: (s: Screen) => void;
  setYear: (y: number) => void;
  jumpToEra: (eraId: EraId) => void;
  discover: (cityId: string, eraId: EraId) => boolean;
  openCity: (cityId: string, eraId: EraId, save: boolean) => void;
  consumeFocus: () => FocusCity | null;
  clearFocus: () => void;
  setSetting: <K extends keyof Settings>(key: K, value: Settings[K]) => void;
  markSavedNow: () => void;
  recordQuizScore: (score: number) => void;
  setQuizDifficulty: (d: QuizDifficulty) => void;
  recordMemoryWin: (moves: number, pairs: 4 | 6 | 8) => void;
  /** count a Random Discovery spin; wasNew = roll was not yet in the journal */
  recordSpin: (wasNew: boolean) => void;
  /** tally one quiz answer into the per-era mastery record */
  recordQuizAnswer: (eraId: EraId, wasCorrect: boolean) => void;
  importData: (data: { year?: number; discovered?: string[]; settings?: Partial<Settings>; quizBest?: number; quizDifficulty?: QuizDifficulty; memoryBest?: number; memoryBest6?: number; memoryBest4?: number; spinCount?: number; spinNew?: number; quizMastery?: Partial<Record<EraId, { asked: number; correct: number }>> }) => void;
  resetAll: () => void;
}

export const useTuranStore = create<TuranState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      screen: 'menu',
      year: 1400,
      discovered: [],
      pendingFocus: null,
      lastSaved: null,
      quizBest: 0,
      quizDifficulty: 'normal',
      memoryBest: 0,
      memoryBest6: 0,
      memoryBest4: 0,
      spinCount: 0,
      spinNew: 0,
      quizMastery: {},
      settings: DEFAULT_SETTINGS,

      setScreen: (s) => set({ screen: s }),

      setYear: (y) => set({ year: y }),

      jumpToEra: (eraId) => {
        const era = ERA_MAP[eraId];
        if (!era) return;
        const year = Math.round((era.startYear + era.endYear) / 2);
        set({ year });
      },

      discover: (cityId, eraId) => {
        const key = `${cityId}:${eraId}`;
        if (get().discovered.includes(key)) return false;
        set((s) => ({
          discovered: [...s.discovered, key],
          lastSaved: s.settings.autoSave ? Date.now() : s.lastSaved,
        }));
        return true;
      },

      openCity: (cityId, eraId, save) => {
        set({ pendingFocus: { cityId, eraId } });
        if (save) get().discover(cityId, eraId);
      },

      consumeFocus: () => {
        const f = get().pendingFocus;
        if (f) set({ pendingFocus: null });
        return f;
      },

      clearFocus: () => set({ pendingFocus: null }),

      setSetting: (key, value) => {
        set((s) => {
          const settings = { ...s.settings, [key]: value };
          if (key === 'autoSave') {
            window.localStorage.setItem(
              AUTOSAVE_FLAG_KEY,
              settings.autoSave ? 'on' : 'off'
            );
          }
          return { settings, lastSaved: settings.autoSave ? Date.now() : s.lastSaved };
        });
      },

      markSavedNow: () => set({ lastSaved: Date.now() }),

      recordQuizScore: (score: number) =>
        set((s) => ({
          quizBest: Math.max(s.quizBest, score),
          lastSaved: s.settings.autoSave ? Date.now() : s.lastSaved,
        })),

      setQuizDifficulty: (d) =>
        set((s) => ({ quizDifficulty: d, lastSaved: s.settings.autoSave ? Date.now() : s.lastSaved })),

      recordMemoryWin: (moves: number, pairs: 4 | 6 | 8) =>
        set((s) => ({
          memoryBest:
            pairs === 8 ? (s.memoryBest === 0 ? moves : Math.min(s.memoryBest, moves)) : s.memoryBest,
          memoryBest6:
            pairs === 6 ? (s.memoryBest6 === 0 ? moves : Math.min(s.memoryBest6, moves)) : s.memoryBest6,
          memoryBest4:
            pairs === 4 ? (s.memoryBest4 === 0 ? moves : Math.min(s.memoryBest4, moves)) : s.memoryBest4,
          lastSaved: s.settings.autoSave ? Date.now() : s.lastSaved,
        })),

      recordSpin: (wasNew: boolean) =>
        set((s) => ({
          spinCount: s.spinCount + 1,
          spinNew: wasNew ? s.spinNew + 1 : s.spinNew,
          lastSaved: s.settings.autoSave ? Date.now() : s.lastSaved,
        })),

      recordQuizAnswer: (eraId, wasCorrect) =>
        set((s) => {
          const prev = s.quizMastery[eraId] ?? { asked: 0, correct: 0 };
          return {
            quizMastery: {
              ...s.quizMastery,
              [eraId]: { asked: prev.asked + 1, correct: prev.correct + (wasCorrect ? 1 : 0) },
            },
            lastSaved: s.settings.autoSave ? Date.now() : s.lastSaved,
          };
        }),

      importData: (data) => {
        set((s) => {
          const year = typeof data.year === 'number' ? data.year : s.year;
          const discovered = Array.isArray(data.discovered)
            ? data.discovered.filter((d) => typeof d === 'string' && d.includes(':'))
            : s.discovered;
          const settings = { ...s.settings, ...(data.settings ?? {}) };
          const quizBest =
            typeof data.quizBest === 'number' ? Math.max(s.quizBest, data.quizBest) : s.quizBest;
          const quizDifficulty: QuizDifficulty =
            data.quizDifficulty === 'easy' || data.quizDifficulty === 'normal' || data.quizDifficulty === 'hard'
              ? data.quizDifficulty
              : s.quizDifficulty;
          const memoryBest =
            typeof data.memoryBest === 'number' && data.memoryBest > 0
              ? s.memoryBest === 0
                ? data.memoryBest
                : Math.min(s.memoryBest, data.memoryBest)
              : s.memoryBest;
          const memoryBest6 =
            typeof data.memoryBest6 === 'number' && data.memoryBest6 > 0
              ? s.memoryBest6 === 0
                ? data.memoryBest6
                : Math.min(s.memoryBest6, data.memoryBest6)
              : s.memoryBest6;
          const memoryBest4 =
            typeof data.memoryBest4 === 'number' && data.memoryBest4 > 0
              ? s.memoryBest4 === 0
                ? data.memoryBest4
                : Math.min(s.memoryBest4, data.memoryBest4)
              : s.memoryBest4;
          const spinCount = typeof data.spinCount === 'number' && data.spinCount >= 0 ? Math.max(s.spinCount, data.spinCount) : s.spinCount;
          const spinNew = typeof data.spinNew === 'number' && data.spinNew >= 0 ? Math.max(s.spinNew, data.spinNew) : s.spinNew;
          const quizMastery = (() => {
            if (!data.quizMastery) return s.quizMastery;
            // merge per-era: keep the higher asked/correct counts per era
            const merged: typeof s.quizMastery = { ...s.quizMastery };
            (Object.keys(data.quizMastery) as EraId[]).forEach((eraId) => {
              const inc = data.quizMastery![eraId];
              if (!inc || typeof inc.asked !== 'number' || typeof inc.correct !== 'number') return;
              const cur = merged[eraId] ?? { asked: 0, correct: 0 };
              merged[eraId] = {
                asked: Math.max(cur.asked, inc.asked),
                correct: Math.max(cur.correct, inc.correct),
              };
            });
            return merged;
          })();
          if (typeof data.settings?.autoSave === 'boolean') {
            window.localStorage.setItem(
              AUTOSAVE_FLAG_KEY,
              data.settings.autoSave ? 'on' : 'off'
            );
          }
          return { year, discovered, settings, quizBest, quizDifficulty, memoryBest, memoryBest6, memoryBest4, spinCount, spinNew, quizMastery, lastSaved: Date.now() };
        });
      },

      resetAll: () => {
        set({ discovered: [], year: 1400, lastSaved: null, quizBest: 0, quizDifficulty: 'normal', memoryBest: 0, memoryBest6: 0, memoryBest4: 0, spinCount: 0, spinNew: 0, quizMastery: {}, settings: DEFAULT_SETTINGS });
      },
    }),
    {
      name: 'turan-save-v1',
      storage: createJSONStorage(() => storage),
      partialize: (state) => ({
        year: state.year,
        discovered: state.discovered,
        lastSaved: state.lastSaved,
        quizBest: state.quizBest,
        quizDifficulty: state.quizDifficulty,
        memoryBest: state.memoryBest,
        memoryBest6: state.memoryBest6,
        memoryBest4: state.memoryBest4,
        spinCount: state.spinCount,
        spinNew: state.spinNew,
        quizMastery: state.quizMastery,
        settings: state.settings,
      }),
      onRehydrateStorage: () => (state) => {
        if (state) {
          state.hydrated = true;
          // ensure era highlight matches restored year
          eraForYear(state.year);
        }
      },
      // deep-merge persisted settings over the defaults so saves written by
      // older versions never miss newly added setting keys (e.g. offlineMode)
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<TuranState>;
        return {
          ...current,
          ...p,
          settings: { ...DEFAULT_SETTINGS, ...(p.settings ?? {}) },
        };
      },
    }
  )
);

// Selector helpers
export const selectCurrentEra = (s: { year: number }) => eraForYear(s.year);

// Convenience typed setters for settings groups
export function setTheme(v: ThemeId) {
  useTuranStore.getState().setSetting('theme', v);
}
export function setAccent(v: AccentId) {
  useTuranStore.getState().setSetting('accent', v);
}
export function setFontSize(v: FontSizeId) {
  useTuranStore.getState().setSetting('fontSize', v);
}
export function setLanguage(v: LangId) {
  useTuranStore.getState().setSetting('language', v);
}
export function setAnimSpeed(v: AnimSpeed) {
  useTuranStore.getState().setSetting('animSpeed', v);
}
export function setQuality(v: QualityId) {
  useTuranStore.getState().setSetting('quality', v);
}
