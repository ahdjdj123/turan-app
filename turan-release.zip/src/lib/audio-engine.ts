/**
 * Turan audio engine — fully synthesized with WebAudio (no external files).
 * Provides an ambient background drone with occasional plucked notes in a
 * Hijaz-like scale, plus UI sound effects. All volumes respect the master
 * volume from settings.
 */

type SfxName = 'hover' | 'click' | 'discover' | 'era' | 'spin';

class TuranAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private musicNodes: { stop: () => void } | null = null;
  private pluckTimer: ReturnType<typeof setTimeout> | null = null;
  private lastHover = 0;

  private volume = 0.55;
  private musicOn = false;
  private sfxOn = true;

  init() {
    if (this.ctx) return;
    try {
      const Ctor =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new Ctor();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.volume * 0.9;
      this.master.connect(this.ctx.destination);
      this.musicBus = this.ctx.createGain();
      this.musicBus.gain.value = 0.5;
      this.musicBus.connect(this.master);
      this.sfxBus = this.ctx.createGain();
      this.sfxBus.gain.value = 0.7;
      this.sfxBus.connect(this.master);

      /* performance + courtesy: suspend the whole engine while the tab is hidden */
      if (typeof document !== 'undefined') {
        document.addEventListener('visibilitychange', () => {
          if (!this.ctx) return;
          if (document.hidden) {
            void this.ctx.suspend().catch(() => {});
          } else if (this.ctx.state === 'suspended') {
            void this.ctx.resume().catch(() => {});
          }
        });
      }
    } catch {
      this.ctx = null;
    }
  }

  setVolume(v: number) {
    this.volume = Math.min(1, Math.max(0, v / 100));
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(this.volume * 0.9, this.ctx.currentTime, 0.05);
    }
  }

  setSfx(on: boolean) {
    this.sfxOn = on;
  }

  setMusic(on: boolean) {
    this.musicOn = on;
    if (on) {
      this.init();
      if (this.ctx && this.ctx.state === 'suspended') void this.ctx.resume();
      this.startMusic();
    } else {
      this.stopMusic();
    }
  }

  /** Called on first user gesture to unlock audio. */
  unlock() {
    this.init();
    if (this.ctx && this.ctx.state === 'suspended') void this.ctx.resume();
    if (this.musicOn) this.startMusic();
  }

  private startMusic() {
    if (!this.ctx || !this.musicBus || this.musicNodes) return;
    const ctx = this.ctx;

    // deep drone: two detuned oscillators through a slow-sweeping lowpass
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 420;
    lp.Q.value = 0.6;

    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    lfo.frequency.value = 0.07;
    lfoGain.gain.value = 180;
    lfo.connect(lfoGain);
    lfoGain.connect(lp.frequency);

    const oscA = ctx.createOscillator();
    oscA.type = 'triangle';
    oscA.frequency.value = 73.4; // D2
    const oscB = ctx.createOscillator();
    oscB.type = 'sine';
    oscB.frequency.value = 110.0; // A2
    oscB.detune.value = 6;
    const oscC = ctx.createOscillator();
    oscC.type = 'sine';
    oscC.frequency.value = 146.8; // D3
    oscC.detune.value = -5;

    const droneGain = ctx.createGain();
    droneGain.gain.value = 0.0001;
    droneGain.gain.setTargetAtTime(0.05, ctx.currentTime, 2.5);

    // soft desert wind: filtered noise
    const noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const data = noiseBuf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * 0.4;
    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuf;
    noise.loop = true;
    const noiseFilter = ctx.createBiquadFilter();
    noiseFilter.type = 'bandpass';
    noiseFilter.frequency.value = 500;
    noiseFilter.Q.value = 0.4;
    const noiseGain = ctx.createGain();
    noiseGain.gain.value = 0.012;

    oscA.connect(lp);
    oscB.connect(lp);
    oscC.connect(lp);
    lp.connect(droneGain);
    droneGain.connect(this.musicBus);
    noise.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(this.musicBus);

    oscA.start();
    oscB.start();
    oscC.start();
    lfo.start();
    noise.start();

    const stopAll = () => {
      try {
        oscA.stop();
        oscB.stop();
        oscC.stop();
        lfo.stop();
        noise.stop();
      } catch {
        /* already stopped */
      }
    };
    this.musicNodes = { stop: stopAll };

    this.schedulePluck();
  }

  private stopMusic() {
    if (this.musicNodes) {
      this.musicNodes.stop();
      this.musicNodes = null;
    }
    if (this.pluckTimer) {
      clearTimeout(this.pluckTimer);
      this.pluckTimer = null;
    }
  }

  /** Occasional pentatonic/Hijaz pluck over the drone. */
  private schedulePluck() {
    if (!this.ctx || !this.musicBus || !this.musicOn) return;
    const delay = 2200 + Math.random() * 4800;
    this.pluckTimer = setTimeout(() => {
      if (!this.ctx || !this.musicBus || !this.musicOn) return;
      const scale = [146.83, 155.56, 185.0, 196.0, 220.0, 233.08, 293.66, 311.13];
      const freq = scale[Math.floor(Math.random() * scale.length)];
      const ctx = this.ctx;
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = freq;
      const vib = ctx.createOscillator();
      const vibGain = ctx.createGain();
      vib.frequency.value = 5.2;
      vibGain.gain.value = 2.4;
      vib.connect(vibGain);
      vibGain.connect(osc.frequency);
      const gain = ctx.createGain();
      const t = ctx.currentTime;
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(0.055, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 2.4);
      osc.connect(gain);
      gain.connect(this.musicBus);
      osc.start(t);
      vib.start(t);
      osc.stop(t + 2.6);
      vib.stop(t + 2.6);
      this.schedulePluck();
    }, delay);
  }

  play(name: SfxName) {
    if (!this.sfxOn) return;
    this.init();
    if (!this.ctx || !this.sfxBus) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;

    const tone = (
      freq: number,
      start: number,
      dur: number,
      type: OscillatorType,
      vol: number
    ) => {
      const osc = ctx.createOscillator();
      osc.type = type;
      osc.frequency.value = freq;
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(vol, start + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + dur);
      osc.connect(gain);
      gain.connect(this.sfxBus!);
      osc.start(start);
      osc.stop(start + dur + 0.05);
    };

    if (name === 'hover') {
      if (now - this.lastHover < 0.08) return;
      this.lastHover = now;
      tone(1180, now, 0.07, 'sine', 0.025);
    } else if (name === 'click') {
      tone(520, now, 0.09, 'triangle', 0.08);
      tone(780, now + 0.05, 0.1, 'sine', 0.05);
    } else if (name === 'discover') {
      const notes = [293.66, 369.99, 440.0, 587.33];
      notes.forEach((f, i) => tone(f, now + i * 0.09, 0.35, 'triangle', 0.07));
    } else if (name === 'spin') {
      for (let i = 0; i < 10; i++) {
        tone(300 + i * 90, now + i * 0.06, 0.05, 'sine', 0.02 + i * 0.004);
      }
    } else if (name === 'era') {
      // whoosh: sweeping filtered noise
      const dur = 0.7;
      const buf = ctx.createBuffer(1, ctx.sampleRate * dur, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * 0.5;
      const src = ctx.createBufferSource();
      src.buffer = buf;
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.Q.value = 1.4;
      filter.frequency.setValueAtTime(300, now);
      filter.frequency.exponentialRampToValueAtTime(2400, now + dur * 0.6);
      filter.frequency.exponentialRampToValueAtTime(400, now + dur);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.09, now + 0.12);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);
      src.connect(filter);
      filter.connect(gain);
      gain.connect(this.sfxBus);
      src.start(now);
    }
  }
}

export const audio = new TuranAudio();
