import { ERAS, type Era, type EraId } from '@/data/eras';

/** Map a slider position t in [0,1] onto a year, giving each era an equal share of the track. */
export function yearFromT(t: number): number {
  const clamped = Math.min(1, Math.max(0, t));
  const pos = clamped * ERAS.length; // continuous era index space [0, 7]
  const idx = Math.min(ERAS.length - 1, Math.floor(pos));
  const era = ERAS[idx];
  const frac = pos - idx;
  const year = era.startYear + frac * (era.endYear - era.startYear);
  return Math.round(year);
}

/** Inverse mapping: year -> slider position t in [0,1]. */
export function tFromYear(year: number): number {
  for (let i = 0; i < ERAS.length; i++) {
    const era = ERAS[i];
    if (year <= era.endYear || i === ERAS.length - 1) {
      const dur = era.endYear - era.startYear;
      const frac = Math.min(1, Math.max(0, (year - era.startYear) / dur));
      return (i + frac) / ERAS.length;
    }
  }
  return 1;
}

/** Mid-year of an era, used when jumping to an era chip. */
export function eraMidYear(era: Era): number {
  return Math.round((era.startYear + era.endYear) / 2);
}

export function formatYear(year: number, bceLabel: string, ceLabel: string): string {
  const y = Math.abs(year);
  const formatted = y >= 10000 ? y.toLocaleString('en-US') : String(y);
  return year < 0 ? `${formatted} ${bceLabel}` : `${formatted} ${ceLabel}`;
}

export function formatYearWithLang(year: number, bce: string, ce: string): string {
  return formatYear(year, bce, ce);
}

const FOUNDED_ROMAN: Record<number, string> = {
  1: 'I', 2: 'II', 3: 'III', 4: 'IV', 5: 'V', 6: 'VI', 7: 'VII', 8: 'VIII',
  9: 'IX', 10: 'X', 11: 'XI', 12: 'XII', 13: 'XIII', 14: 'XIV', 15: 'XV',
  16: 'XVI', 17: 'XVII', 18: 'XVIII', 19: 'XIX', 20: 'XX',
};

export interface FoundedLabels {
  bce: string;
  ce: string;
  ancient: string;
  centuryBce: string;
  centuryCe: string;
  millenniumBce: string;
  modern: string;
  recorded: string;
}

/**
 * Localize a city's raw English "founded" string for display.
 * Handles every shape found in the city data:
 *   '742 BCE' · '1732 CE' · '4th century BCE' · '19th century CE'
 *   '1st millennium BCE' · '1932 CE (modern)' · '9th century CE (recorded)' · 'Ancient'
 * English keeps the curated raw string; other languages rebuild it from
 * translated templates ({n} = Roman numeral for century/millennium).
 */
export function formatFounded(founded: string, lang: string, labels: FoundedLabels): string {
  const raw = founded.trim();
  if (lang === 'en') return raw;
  const paren = raw.match(/\(([^)]+)\)/)?.[1]?.toLowerCase();
  const base = raw.replace(/\s*\([^)]*\)/, '').trim();
  const tail =
    paren === 'modern' ? ` · ${labels.modern}` :
    paren === 'recorded' ? ` · ${labels.recorded}` : '';
  if (/^ancient$/i.test(base)) return labels.ancient + tail;
  const num = parseInt(base, 10);
  if (Number.isNaN(num)) return labels.ancient + tail;
  const roman = FOUNDED_ROMAN[num] ?? String(num);
  if (/millennium/i.test(base)) return labels.millenniumBce.replace('{n}', roman) + tail;
  if (/century/i.test(base)) {
    const tpl = /bce/i.test(base) ? labels.centuryBce : labels.centuryCe;
    return tpl.replace('{n}', roman) + tail;
  }
  const suffix = /bce/i.test(base) ? ` ${labels.bce}` : ` ${labels.ce}`;
  return `${num}${suffix}${tail}`;
}

export function isDiscovered(discovered: string[], cityId: string, eraId: EraId): boolean {
  return discovered.includes(`${cityId}:${eraId}`);
}

export function discoveryKey(cityId: string, eraId: EraId): string {
  return `${cityId}:${eraId}`;
}
