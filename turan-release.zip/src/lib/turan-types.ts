import type { EraId } from '@/data/eras';

export type Screen = 'menu' | 'map' | 'explore' | 'random' | 'leisure' | 'settings' | 'journal';
export type ThemeId = 'classic' | 'parchment' | 'contrast';
export type AccentId = 'gold' | 'turquoise' | 'crimson' | 'deepblue';
export type FontSizeId = 'sm' | 'md' | 'lg';
export type AnimSpeed = 'slow' | 'normal' | 'fast';
export type QualityId = '720' | '1080' | '1440';
export type LangId = 'en' | 'ru' | 'uz' | 'ar' | 'tr';

export interface Settings {
  theme: ThemeId;
  accent: AccentId;
  fontSize: FontSizeId;
  language: LangId;
  masterVolume: number;
  music: boolean;
  narration: boolean;
  /** playback pace for TTS narrated tours (0.8 slow · 0.95 normal · 1.15 brisk) */
  narrationSpeed: number;
  sfx: boolean;
  quality: QualityId;
  animSpeed: AnimSpeed;
  glass: boolean;
  showCompass: boolean;
  showProgress: boolean;
  /** precache all city artworks via service worker for offline museum visits */
  offlineMode: boolean;
  autoSave: boolean;
}

export interface FocusCity {
  cityId: string;
  eraId: EraId;
}

export type QuizDifficulty = 'easy' | 'normal' | 'hard';

export const DEFAULT_SETTINGS: Settings = {
  theme: 'classic',
  accent: 'gold',
  fontSize: 'md',
  language: 'en',
  masterVolume: 55,
  music: false,
  narration: false,
  narrationSpeed: 0.95,
  sfx: true,
  quality: '1080',
  animSpeed: 'normal',
  glass: true,
  showCompass: true,
  showProgress: true,
  offlineMode: true,
  autoSave: true,
};

export const ACCENT_COLORS: Record<AccentId, string> = {
  gold: '#D4A53C',
  turquoise: '#2A9D8F',
  crimson: '#9E2A2B',
  deepblue: '#1B2A4A',
};

export const DISCOVERY_KEY = 'turan-discovered';
