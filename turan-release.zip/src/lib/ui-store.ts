import { create } from 'zustand';

/**
 * Ephemeral UI state (never persisted): help plaque + map legend toggles.
 */
interface UIState {
  helpOpen: boolean;
  legendOpen: boolean;
  setHelpOpen: (v: boolean) => void;
  setLegendOpen: (v: boolean) => void;
  toggleHelp: () => void;
  toggleLegend: () => void;
}

export const useUIStore = create<UIState>()((set) => ({
  helpOpen: false,
  legendOpen: false,
  setHelpOpen: (v) => set({ helpOpen: v }),
  setLegendOpen: (v) => set({ legendOpen: v }),
  toggleHelp: () => set((s) => ({ helpOpen: !s.helpOpen })),
  toggleLegend: () => set((s) => ({ legendOpen: !s.legendOpen })),
}));
