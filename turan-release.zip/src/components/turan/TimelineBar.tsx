'use client';

import { useMemo } from 'react';
import { Star } from 'lucide-react';
import { ERAS, ERA_MAP } from '@/data/eras';
import { TOTAL_COMBINATIONS } from '@/data/cities';
import { useTuranStore } from '@/lib/store';
import { useTuranLang } from './useTuranLang';
import { EraGlyph } from './glyphs';
import { yearFromT, tFromYear, formatYear } from '@/lib/turan-utils';
import { audio } from '@/lib/audio-engine';

export function TimelineBar() {
  const year = useTuranStore((s) => s.year);
  const setYear = useTuranStore((s) => s.setYear);
  const jumpToEra = useTuranStore((s) => s.jumpToEra);
  const discovered = useTuranStore((s) => s.discovered);
  const { t, eraLabel } = useTuranLang();

  const currentEra = useMemo(() => ERAS.find((e) => year <= e.endYear) ?? ERAS[ERAS.length - 1], [year]);

  const sliderColors = useMemo(() => {
    const stops: string[] = [];
    ERAS.forEach((e, i) => {
      const start = (i / ERAS.length) * 100;
      const end = ((i + 1) / ERAS.length) * 100;
      stops.push(`${e.color} ${start}%`, `${e.color} ${end}%`);
    });
    return stops.join(', ');
  }, []);

  /** era boundary ruler: one diamond per era start (era 0 owns the left edge) */
  const eraTicks = useMemo(
    () =>
      ERAS.slice(1).map((e) => ({
        id: e.id,
        color: e.color,
        pct: tFromYear(e.startYear) * 100,
        year: formatYear(e.startYear, t('common.bce'), t('common.ce')),
      })),
    [t]
  );

  const progress = Math.round((discovered.length / TOTAL_COMBINATIONS) * 100);

  return (
    <div className="timeline-bar glass" role="region" aria-label="Time travel and discovery progress">
      {/* top row: year + era + discovery */}
      <div className="flex items-center justify-between gap-3 mb-1">
        <div className="flex items-baseline gap-2 min-w-0">
          <span className="text-lg font-bold gold-glow-text tabular-nums" style={{ fontFamily: 'var(--font-display)' }}>
            {formatYear(year, t('common.bce'), t('common.ce'))}
          </span>
          <span className="text-xs tracking-[0.16em] uppercase text-subtle truncate inline-flex items-center gap-1.5">
            <EraGlyph eraId={currentEra.id} size={12} strokeWidth={1.8} />
            {eraLabel(currentEra.id)}
          </span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Star size={13} style={{ color: 'var(--t-accent)' }} aria-hidden="true" />
          <span className="text-xs text-subtle tabular-nums">
            {discovered.length}/{TOTAL_COMBINATIONS} · {progress}%
          </span>
        </div>
      </div>

      {/* slider */}
      <input
        type="range"
        className="timeline-slider"
        min={0}
        max={1}
        step={0.001}
        value={tFromYear(year)}
        onChange={(e) => {
          setYear(yearFromT(parseFloat(e.target.value)));
          audio.play('hover');
        }}
        aria-label={t('common.year')}
        style={{ '--slider-colors': sliderColors } as React.CSSProperties}
      />

      {/* era boundary ruler */}
      <div className="era-ruler" aria-hidden="true">
        {eraTicks.map((tick) => (
          <span
            key={tick.id}
            className={`era-tick ${currentEra.id === tick.id ? 'active' : ''}`}
            style={{ left: `${tick.pct}%`, '--tick-color': tick.color } as React.CSSProperties}
            title={`${tick.year}`}
          />
        ))}
      </div>

      {/* discovery thin line */}
      <div className="discovery-track mt-0.5" role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}>
        <div className="discovery-fill" style={{ width: `${progress}%` }} />
      </div>

      {/* era chips */}
      <div className="hidden sm:flex items-center justify-between gap-1 mt-1.5">
        {ERAS.map((e) => (
          <button
            key={e.id}
            className={`era-chip ${e.id === currentEra.id ? 'active' : ''}`}
            onClick={() => {
              jumpToEra(e.id);
              audio.play('click');
            }}
            title={t(`era.${e.id}.desc` as 'era.ancient.desc')}
          >
            {eraLabel(e.id)}
          </button>
        ))}
      </div>
    </div>
  );
}
