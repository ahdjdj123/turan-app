'use client';

import { ERA_MAP, type EraId } from '@/data/eras';
import { useTuranLang } from './useTuranLang';

interface CompassProps {
  rotation: number;
  eraId: EraId;
  onReset: () => void;
}

export function Compass({ rotation, eraId, onReset }: CompassProps) {
  const { t } = useTuranLang();
  const era = ERA_MAP[eraId];
  const eraClass = eraId === 'timurid' ? 'timurid' : eraId === 'soviet' ? 'soviet' : '';

  return (
    <button
      className={`turan-compass ${eraClass}`}
      style={{ '--t-glow-color': `${era.color}66` } as React.CSSProperties}
      onClick={onReset}
      onMouseEnter={() => undefined}
      aria-label={t('map.reset')}
      title={t('map.reset')}
    >
      {/* star flashes when the Timurid golden age is entered (remount on key) */}
      {eraId === 'timurid' && (
        <span key="timurid-star" className="compass-star-flash flash" aria-hidden="true">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2 L14.5 9.5 L22 12 L14.5 14.5 L12 22 L9.5 14.5 L2 12 L9.5 9.5 Z"/></svg>
        </span>
      )}
      <svg
        className="compass-rose"
        style={{ transform: `rotate(${rotation}deg)` }}
        width="44"
        height="44"
        viewBox="0 0 44 44"
        aria-hidden="true"
      >
        {/* brass bezel */}
        <circle cx="22" cy="22" r="20" fill="none" stroke="#b8952e" strokeWidth="2" />
        <circle cx="22" cy="22" r="16.5" fill="none" stroke="#b8952e" strokeWidth="0.6" opacity="0.6" />
        {/* ticks */}
        {[0, 90, 180, 270].map((a) => (
          <line
            key={a}
            x1="22" y1="4.5" x2="22" y2="8"
            stroke="#d4a53c" strokeWidth="1.6"
            transform={`rotate(${a} 22 22)`}
          />
        ))}
        {[45, 135, 225, 315].map((a) => (
          <line
            key={a}
            x1="22" y1="5.5" x2="22" y2="8"
            stroke="#b8952e" strokeWidth="1"
            transform={`rotate(${a} 22 22)`}
          />
        ))}
        {/* needle — north gold, south tarnished */}
        <polygon points="22,7 25,22 19,22" fill="#d4a53c" />
        <polygon points="22,37 25,22 19,22" fill="#7d6a3f" />
        <circle cx="22" cy="22" r="2.4" fill="#ffe9ae" stroke="#8a6a25" strokeWidth="1" />
      </svg>
    </button>
  );
}
