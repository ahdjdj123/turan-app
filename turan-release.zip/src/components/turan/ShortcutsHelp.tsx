'use client';

import { useEffect, useRef } from 'react';
import { X, Keyboard } from 'lucide-react';
import { ERAS } from '@/data/eras';
import { useTuranStore } from '@/lib/store';
import { useUIStore } from '@/lib/ui-store';
import { useTuranLang } from './useTuranLang';

function Kbd({ children }: { children: React.ReactNode }) {
  return <kbd className="turan-kbd">{children}</kbd>;
}

function Row({ keys, label }: { keys: string[]; label: string }) {
  return (
    <div className="shortcut-row">
      <span className="flex flex-wrap gap-1.5 min-w-[92px]">
        {keys.map((k) => (
          <Kbd key={k}>{k}</Kbd>
        ))}
      </span>
      <span className="text-sm text-subtle">{label}</span>
    </div>
  );
}

export function ShortcutsHelp() {
  const open = useUIStore((s) => s.helpOpen);
  const setHelpOpen = useUIStore((s) => s.setHelpOpen);
  const jumpToEra = useTuranStore((s) => s.jumpToEra);
  const { t, eraLabel } = useTuranLang();
  const panelRef = useRef<HTMLDivElement>(null);

  // focus + Escape handling while open
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        setHelpOpen(false);
      }
    };
    window.addEventListener('keydown', onKey, true);
    panelRef.current?.focus();
    return () => window.removeEventListener('keydown', onKey, true);
  }, [open, setHelpOpen]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[90] grid place-items-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label={t('help.title')}
      onClick={(e) => {
        if (e.target === e.currentTarget) setHelpOpen(false);
      }}
    >
      <div className="absolute inset-0" style={{ background: 'rgba(8,6,18,0.55)', backdropFilter: 'blur(4px)' }} aria-hidden="true" />

      <div ref={panelRef} tabIndex={-1} className="help-plaque glass-strong ornate relative w-full max-w-lg max-h-[86vh] overflow-y-auto turan-scroll p-6 sm:p-8 outline-none">
        <button
          className="absolute top-3 right-3 w-9 h-9 rounded-full glass grid place-items-center"
          onClick={() => setHelpOpen(false)}
          aria-label={t('popup.close')}
        >
          <X size={18} />
        </button>

        <header className="text-center mb-5">
          <Keyboard size={26} className="mx-auto mb-2" style={{ color: 'var(--t-accent)' }} aria-hidden="true" />
          <h2 className="text-xl font-bold tracking-[0.16em] uppercase text-heading" style={{ fontFamily: 'var(--font-display)' }}>
            {t('help.title')}
          </h2>
          <p className="text-xs text-subtle mt-1">{t('help.desc')}</p>
        </header>

        <div className="ornament text-xs mb-4" aria-hidden="true">✦</div>

        <section aria-label={t('help.nav')}>
          <h3 className="text-[11px] tracking-[0.24em] uppercase font-semibold mb-2" style={{ color: 'var(--t-accent)' }}>
            {t('help.nav')}
          </h3>
          <Row keys={['B']} label={t('help.begin')} />
          <Row keys={['M']} label={t('help.menu')} />
          <Row keys={['R']} label={t('menu.random')} />
          <Row keys={['L']} label={t('menu.leisure')} />
          <Row keys={['J']} label={t('journal.open')} />
          <Row keys={['S']} label={t('menu.settings')} />
          <Row keys={['Esc']} label={t('help.back')} />
          <Row keys={['?']} label={t('help.toggle')} />
        </section>

        <section aria-label={t('help.map')} className="mt-5">
          <h3 className="text-[11px] tracking-[0.24em] uppercase font-semibold mb-2" style={{ color: 'var(--t-accent)' }}>
            {t('help.map')}
          </h3>
          <Row keys={['←', '↑', '→', '↓']} label={t('help.pan')} />
          <Row keys={['+', '−']} label={t('help.zoom')} />
          <div className="shortcut-row">
            <span className="flex flex-wrap gap-1.5 min-w-[92px]">
              {ERAS.map((e, i) => (
                <button
                  key={e.id}
                  className="turan-kbd era-kbd"
                  style={{ borderColor: e.color }}
                  onClick={() => {
                    jumpToEra(e.id);
                    setHelpOpen(false);
                  }}
                  title={eraLabel(e.id)}
                >
                  {i + 1}
                </button>
              ))}
            </span>
            <span className="text-sm text-subtle">{t('help.jump')}</span>
          </div>
        </section>
      </div>
    </div>
  );
}
