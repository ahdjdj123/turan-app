'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { RotateCcw, Timer, Footprints, Trophy } from 'lucide-react';
import { toast } from 'sonner';
import { useTuranStore } from '@/lib/store';
import { useTuranLang } from './useTuranLang';
import { EraGlyph, GlyphCamel, GlyphScroll } from './glyphs';
import { audio } from '@/lib/audio-engine';
import type { EraId } from '@/data/eras';

type MemTier = 4 | 6 | 8;

interface PairDef {
  cityId: string;
  city: string;
  eraId: EraId;
  landmark: string;
}

/** City ↔ landmark pairs — every landmark is a real dataset entry. */
const PAIRS: PairDef[] = [
  { cityId: 'samarkand', city: 'Samarkand', eraId: 'timurid', landmark: 'Registan Square' },
  { cityId: 'bukhara', city: 'Bukhara', eraId: 'islamic', landmark: 'Poi-Kalyan Ensemble' },
  { cityId: 'khiva', city: 'Khiva', eraId: 'islamic', landmark: 'Itchan Kala' },
  { cityId: 'shakhrisabz', city: 'Shakhrisabz', eraId: 'timurid', landmark: 'Ak-Saray Palace' },
  { cityId: 'termez', city: 'Termez', eraId: 'ancient', landmark: 'Zurmala Tower' },
  { cityId: 'kokand', city: 'Kokand', eraId: 'khanates', landmark: 'Palace of Khudayar Khan' },
  { cityId: 'tashkent', city: 'Tashkent', eraId: 'timurid', landmark: 'Amir Timur Museum' },
  { cityId: 'margilan', city: 'Margilan', eraId: 'ancient', landmark: 'Ancient Mulberry Groves' },
];

interface Card {
  key: string;
  pairId: string;
  face: string;
  eraId?: EraId;
  sub?: string;
  kind: 'city' | 'landmark';
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function buildDeck(pairs: MemTier): Card[] {
  const chosen = shuffle(PAIRS).slice(0, pairs);
  return shuffle(
    chosen.flatMap((p) => [
      { key: `${p.cityId}-city`, pairId: p.cityId, face: p.city, kind: 'city' as const },
      { key: `${p.cityId}-land`, pairId: p.cityId, face: p.landmark, eraId: p.eraId, kind: 'landmark' as const },
    ])
  );
}

export function CaravanMemory() {
  const { t } = useTuranLang();
  const memoryBest = useTuranStore((s) => s.memoryBest);
  const memoryBest6 = useTuranStore((s) => s.memoryBest6);
  const memoryBest4 = useTuranStore((s) => s.memoryBest4);
  const recordMemoryWin = useTuranStore((s) => s.recordMemoryWin);

  const [tier, setTier] = useState<MemTier>(8);
  const [deck, setDeck] = useState<Card[]>([]);
  const [playing, setPlaying] = useState(false);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<Set<string>>(new Set());
  const [moves, setMoves] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [won, setWon] = useState(false);
  const lockRef = useRef(false);

  // timer
  useEffect(() => {
    if (!playing || won) return;
    const id = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(id);
  }, [playing, won]);

  const deal = useCallback(() => {
    setDeck(buildDeck(tier));
    setPlaying(true);
    setFlipped([]);
    setMatched(new Set());
    setMoves(0);
    setSeconds(0);
    setWon(false);
    lockRef.current = false;
    audio.play('click');
  }, [tier]);

  const totalPairs = tier;
  const tierBest = tier === 8 ? memoryBest : tier === 6 ? memoryBest6 : memoryBest4;

  const flip = (idx: number) => {
    if (!playing || lockRef.current || won) return;
    if (flipped.includes(idx) || matched.has(deck[idx].pairId)) return;
    audio.play('hover');

    const next = [...flipped, idx];
    setFlipped(next);
    if (next.length < 2) return;

    lockRef.current = true;
    const newMoves = moves + 1;
    setMoves(newMoves);
    const [a, b] = next;
    const isMatch = deck[a].pairId === deck[b].pairId;

    setTimeout(
      () => {
        if (isMatch) {
          const nextMatched = new Set(matched);
          nextMatched.add(deck[a].pairId);
          setMatched(nextMatched);
          setFlipped([]);
          lockRef.current = false;
          if (nextMatched.size === totalPairs) {
            setWon(true);
            audio.play('discover');
            recordMemoryWin(newMoves, tier);
            toast.success(t('memory.win'), {
              description: `${newMoves} ${t('memory.moves').toLowerCase()} · ${seconds}s${tierBest === newMoves ? ` — ${t('memory.perfect')}` : ''}`,
            });
          }
          return;
        }
        setFlipped([]);
        lockRef.current = false;
      },
      isMatch ? 500 : 900
    );
  };

  const mmss = useMemo(() => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  }, [seconds]);

  return (
    <div className="flex flex-col gap-4 min-h-[380px]">
      <header className="text-center">
        <div className="mb-1" style={{ color: 'var(--t-accent)' }} aria-hidden="true"><GlyphScroll size={30} strokeWidth={1.3} /></div>
        <h2 className="text-lg font-bold tracking-[0.16em] uppercase gold-glow-text" style={{ fontFamily: 'var(--font-display)' }}>
          {t('memory.title')}
        </h2>
        <p className="text-xs text-subtle mt-1">{t('memory.tagline')}</p>
      </header>

      {/* caravan size tiers */}
      <div className="flex flex-col items-center gap-1.5">
        <span className="text-[10px] tracking-[0.24em] uppercase text-subtle font-semibold">{t('memory.tier')}</span>
        <div className="mem-tiers" role="radiogroup" aria-label={t('memory.tier')}>
          <button
            role="radio"
            aria-checked={tier === 4}
            className={tier === 4 ? 'active' : ''}
            disabled={playing && !won}
            onClick={() => {
              audio.play('click');
              setTier(4);
            }}
          >
            <GlyphCamel size={16} strokeWidth={1.8} /> {t('memory.tierCub')}<span className="tier-pairs">4</span>
          </button>
          <button
            role="radio"
            aria-checked={tier === 6}
            className={tier === 6 ? 'active' : ''}
            disabled={playing && !won}
            onClick={() => {
              audio.play('click');
              setTier(6);
            }}
          >
            <GlyphCamel size={19} strokeWidth={1.8} /> {t('memory.tierSmall')}<span className="tier-pairs">6</span>
          </button>
          <button
            role="radio"
            aria-checked={tier === 8}
            className={tier === 8 ? 'active' : ''}
            disabled={playing && !won}
            onClick={() => {
              audio.play('click');
              setTier(8);
            }}
          >
            <GlyphCamel size={22} strokeWidth={1.8} /> {t('memory.tierGreat')}<span className="tier-pairs">8</span>
          </button>
        </div>
      </div>

      {/* stats */}
      <div className="flex items-center justify-center gap-2 text-xs flex-wrap">
        <span className="stat-chip">
          <Footprints size={12} aria-hidden="true" />
          {t('memory.moves')}: <b className="tabular-nums">{moves}</b>
        </span>
        <span className="stat-chip">
          <Timer size={12} aria-hidden="true" />
          {t('memory.time')}: <b className="tabular-nums">{mmss}</b>
        </span>
        {tierBest > 0 && (
          <span className="stat-chip" style={{ borderColor: 'var(--t-accent)' }}>
            <Trophy size={12} aria-hidden="true" />
            {t('memory.best')}: <b className="tabular-nums">{tierBest}</b>
          </span>
        )}
        {playing && !won && (
          <button className="stat-chip cursor-pointer hover:opacity-80" onClick={deal} aria-label={t('memory.again')}>
            <RotateCcw size={12} aria-hidden="true" />
            {t('memory.again')}
          </button>
        )}
      </div>

      {!playing ? (
        <div className="flex-1 grid place-items-center">
          <button className="btn-glass btn-accent px-6 py-3 text-sm" onClick={deal}>
            <GlyphScroll size={17} strokeWidth={1.7} /> {t('memory.play')}
          </button>
        </div>
      ) : (
        <>
          <div className={`mem-grid ${tier === 6 ? 'pairs-6' : tier === 4 ? 'pairs-4' : ''}`} role="grid" aria-label={t('memory.title')}>
            {deck.map((card, i) => {
              const isUp = flipped.includes(i);
              const isMatched = matched.has(card.pairId);
              return (
                <button
                  key={card.key}
                  className={`mem-card ${isUp || isMatched ? 'flipped' : ''} ${isMatched ? 'matched' : ''}`}
                  onClick={() => flip(i)}
                  aria-label={isUp || isMatched ? card.face : 'card'}
                  aria-pressed={isUp}
                >
                  <span className="mem-inner">
                    <span className="mem-face mem-back" aria-hidden="true">
                      <span className="mem-back-star">✦</span>
                    </span>
                    <span className={`mem-face mem-front ${card.kind}`}>
                      {card.kind === 'city' ? (
                        <span className="mem-city serif">{card.face}</span>
                      ) : (
                        <span className="mem-landmark">
                          {card.eraId && <EraGlyph eraId={card.eraId} size={16} strokeWidth={1.6} />}
                          {card.face}
                        </span>
                      )}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>

          {won && (
            <div className="mem-win ink-fade text-center">
              <p className="text-base font-semibold" style={{ color: 'var(--t-accent)', fontFamily: 'var(--font-display)' }}>
                ✦ {t('memory.win')} ✦
              </p>
              <p className="text-xs text-subtle mt-1">
                {moves} {t('memory.moves').toLowerCase()} · {mmss}
                {tierBest === moves ? ` — ${t('memory.perfect')}` : ''}
              </p>
              <button className="btn-glass btn-accent px-5 py-2.5 text-sm mt-3 mx-auto" onClick={deal}>
                {t('memory.again')}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
