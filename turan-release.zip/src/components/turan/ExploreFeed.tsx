'use client';

import { useCallback, useMemo, useRef, useState } from 'react';
import { Search, Star, Bookmark, Navigation, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { CITIES, CITY_MAP, getMergedContent, type City } from '@/data/cities';
import { ERA_MAP, type EraId } from '@/data/eras';
import {
  TRAVEL, CATEGORIES, CATEGORY_MAP, SHOWCASE_ERA, HOME_CITY,
  weatherFor, distanceKm, etaCar, formatKm,
  type CategoryId,
} from '@/data/travel';
import { useTuranStore } from '@/lib/store';
import { audio } from '@/lib/audio-engine';
import { useTuranLang } from './useTuranLang';

/* ------------------------------------------------------------------ */
/*  shimmer-in image (Instagram-style loading)                         */
/* ------------------------------------------------------------------ */

export function FeedImage({
  src, alt, className = '', eager = false,
}: { src: string; alt: string; className?: string; eager?: boolean }) {
  const [loaded, setLoaded] = useState(false);
  return (
    <span className={`feed-img-wrap ${className}`}>
      {!loaded && <span className="feed-img-shimmer" aria-hidden="true" />}
      <img
        src={src}
        alt={alt}
        loading={eager ? 'eager' : 'lazy'}
        decoding="async"
        onLoad={() => setLoaded(true)}
        className={`feed-img ${loaded ? 'loaded' : ''}`}
      />
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  destination card                                                   */
/* ------------------------------------------------------------------ */

function destinationEra(city: City): EraId {
  const showcase = SHOWCASE_ERA[city.id];
  if (showcase && city.eras[showcase]) return showcase;
  return (Object.keys(city.eras) as EraId[])[0];
}

function DestinationCard({ city, tall, onOpen }: { city: City; tall: boolean; onOpen: (city: City) => void }) {
  const { t, cityName, eraLabel } = useTuranLang();
  const info = TRAVEL[city.id];
  const eraId = destinationEra(city);
  const era = ERA_MAP[eraId];
  const content = getMergedContent(city, eraId);
  const cat = CATEGORY_MAP[info.category];
  const weather = weatherFor(city.id);
  const km = distanceKm(HOME_CITY, city.id);
  const saves = Math.round(info.popularity * 231 + (info.reviewsCount % 17));

  return (
    <button
      className={`dest-card ${tall ? 'tall' : ''}`}
      onClick={() => onOpen(city)}
      aria-label={`${cityName(city.name, city.names)} — ${cat.icon} ${t(`cat.${cat.id}` as 'cat.unesco')}`}
    >
      <FeedImage
        src={`/images/cities/${city.id}_${eraId}.png`}
        alt={`${cityName(city.name, city.names)} — ${eraLabel(eraId)}`}
        className="dest-card-img"
      />
      <span className="dest-card-shade" aria-hidden="true" />

      <span className="dest-card-top">
        <span className="dest-cat-chip" style={{ background: `${cat.color}2b`, borderColor: `${cat.color}88` }}>
          <span aria-hidden="true">{cat.icon}</span> {t(`cat.${cat.id}` as 'cat.unesco')}
        </span>
        <span className="dest-weather-chip" title={t(`weather.${weather.condition}` as 'weather.sunny')}>
          <span aria-hidden="true">{weather.icon}</span> {weather.tempC}°
        </span>
      </span>

      <span className="dest-card-body">
        <span className="dest-card-name">{cityName(city.name, city.names)}</span>
        {content?.tagline && <span className="dest-card-story">{content.tagline}</span>}
        <span className="dest-card-meta">
          <span className="dest-rating">
            <Star size={11} aria-hidden="true" /> {info.rating.toFixed(1)}
          </span>
          <span aria-hidden="true">·</span>
          <span className="inline-flex items-center gap-1">
            <Navigation size={10} aria-hidden="true" /> {formatKm(km)}
          </span>
          <span aria-hidden="true">·</span>
          <span className="inline-flex items-center gap-1">
            <Bookmark size={10} aria-hidden="true" /> {saves > 999 ? `${(saves / 1000).toFixed(1)}k` : saves}
          </span>
        </span>
      </span>
    </button>
  );
}

/* ------------------------------------------------------------------ */
/*  story bubble (featured destinations)                               */
/* ------------------------------------------------------------------ */

function StoryBubble({ city, onOpen }: { city: City; onOpen: (city: City) => void }) {
  const { cityName } = useTuranLang();
  const eraId = destinationEra(city);
  return (
    <button className="story-bubble" onClick={() => onOpen(city)} aria-label={cityName(city.name, city.names)}>
      <span className="story-ring" aria-hidden="true">
        <FeedImage
          src={`/images/cities/${city.id}_${eraId}.png`}
          alt=""
          className="story-img"
        />
      </span>
      <span className="story-name">{cityName(city.name, city.names)}</span>
    </button>
  );
}

/* ------------------------------------------------------------------ */
/*  Explore feed                                                       */
/* ------------------------------------------------------------------ */

type Filter = CategoryId | 'all';

export function ExploreFeed() {
  const { t, cityName } = useTuranLang();
  const setScreen = useTuranStore((s) => s.setScreen);

  const [filter, setFilter] = useState<Filter>('all');
  const [query, setQuery] = useState('');
  const [pullY, setPullY] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [seed, setSeed] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const touchStart = useRef<{ y: number } | null>(null);

  const homeWeather = weatherFor(HOME_CITY);

  /* deterministic shuffle so a refresh visibly re-mixes the feed */
  const orderedCities = useMemo(() => {
    const arr = [...CITIES];
    let s = seed * 2654435761 + 1;
    const rnd = () => {
      s = (s * 1664525 + 1013904223) >>> 0;
      return s / 4294967296;
    };
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(rnd() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    // majors always present near the top on first paint
    if (seed === 0) {
      arr.sort((a, b) => (b.major ? 1 : 0) - (a.major ? 1 : 0));
    }
    return arr;
  }, [seed]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return orderedCities.filter((c) => {
      const info = TRAVEL[c.id];
      if (!info) return false;
      if (filter !== 'all' && info.category !== filter && !info.tags.includes(filter)) return false;
      if (q && !`${c.name} ${Object.values(c.names).join(' ')}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [orderedCities, filter, query]);

  const featured = useMemo(() => CITIES.filter((c) => c.major || c.id === 'nukus' || c.id === 'shakhrisabz'), []);

  const doRefresh = useCallback(() => {
    setRefreshing(true);
    audio.play('era');
    setTimeout(() => {
      setSeed((s) => s + 1);
      setRefreshing(false);
      toast.success(t('explore.refreshed'));
    }, 850);
  }, [t]);

  /* -------- pull to refresh (touch) -------- */
  const onTouchStart = (e: React.TouchEvent) => {
    const el = scrollRef.current;
    if (!el || el.scrollTop > 4 || refreshing) return;
    touchStart.current = { y: e.touches[0].clientY };
  };
  const onTouchMove = (e: React.TouchEvent) => {
    if (!touchStart.current) return;
    const dy = e.touches[0].clientY - touchStart.current.y;
    if (dy > 0) setPullY(Math.min(dy * 0.5, 110));
  };
  const onTouchEnd = () => {
    if (pullY > 52 && !refreshing) doRefresh();
    touchStart.current = null;
    setPullY(0);
  };

  const openDestination = useCallback(
    (city: City) => {
      const eraId = destinationEra(city);
      if (!CITY_MAP[city.id]?.eras[eraId]) return;
      audio.play('click');
      const store = useTuranStore.getState();
      store.openCity(city.id, eraId, false);
      store.setScreen('map');
    },
    []
  );

  return (
    <div className="explore-screen turan-root">
      <div
        ref={scrollRef}
        className="explore-scroll turan-scroll"
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
        {/* pull-to-refresh indicator */}
        <div
          className={`feed-ptr ${refreshing || pullY > 0 ? 'show' : ''}`}
          style={{ height: refreshing ? 56 : pullY, opacity: refreshing ? 1 : Math.min(1, pullY / 70) }}
          aria-hidden={!refreshing && pullY === 0}
        >
          <RefreshCw size={20} className={refreshing ? 'animate-spin' : ''} style={{ transform: refreshing ? undefined : `rotate(${pullY * 3}deg)` }} />
          <span className="text-[11px] tracking-[0.14em] uppercase text-subtle">
            {refreshing ? t('explore.refreshing') : t('explore.pull')}
          </span>
        </div>

        <div className="explore-inner">
          {/* header */}
          <header className="explore-head">
            <div className="flex items-end justify-between gap-3 flex-wrap">
              <div>
                <h1 className="explore-title" style={{ fontFamily: 'var(--font-display)' }}>{t('explore.title')}</h1>
                <p className="explore-sub">{t('explore.subtitle')}</p>
              </div>
              <span className="explore-weather glass" title={t('visit.weather')}>
                <span aria-hidden="true">{homeWeather.icon}</span>
                <span className="tabular-nums">{homeWeather.tempC}°</span>
                <span className="text-subtle hidden sm:inline">{cityName('Tashkent', CITY_MAP.tashkent.names)}</span>
              </span>
            </div>

            {/* search */}
            <div className="feed-search">
              <Search size={15} aria-hidden="true" style={{ color: 'var(--t-accent)', flexShrink: 0 }} />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t('explore.search')}
                aria-label={t('explore.search')}
                className="feed-search-input"
                type="search"
              />
              <button
                className="btn-glass py-1 px-2.5 text-xs shrink-0"
                onClick={doRefresh}
                aria-label={t('explore.pull')}
                title={t('explore.pull')}
              >
                <RefreshCw size={13} className={refreshing ? 'animate-spin' : ''} />
              </button>
            </div>
          </header>

          {/* stories */}
          <section aria-label={t('explore.stories')}>
            <div className="ornament text-[11px] tracking-[0.24em] uppercase mb-2.5 mt-1">{t('explore.stories')}</div>
            <div className="stories-row turan-scroll">
              {featured.map((c) => (
                <StoryBubble key={c.id} city={c} onOpen={openDestination} />
              ))}
            </div>
          </section>

          {/* category pills */}
          <div className="feed-pills" role="tablist" aria-label={t('explore.filterAll')}>
            <button
              className={`feed-pill ${filter === 'all' ? 'active' : ''}`}
              onClick={() => { audio.play('hover'); setFilter('all'); }}
              role="tab"
              aria-selected={filter === 'all'}
            >
              {t('explore.filterAll')}
            </button>
            {CATEGORIES.map((c) => (
              <button
                key={c.id}
                className={`feed-pill ${filter === c.id ? 'active' : ''}`}
                style={filter === c.id ? { borderColor: c.color, color: c.color } : undefined}
                onClick={() => { audio.play('hover'); setFilter(c.id); }}
                role="tab"
                aria-selected={filter === c.id}
              >
                <span aria-hidden="true">{c.icon}</span> {t(`cat.${c.id}` as 'cat.unesco')}
              </button>
            ))}
          </div>

          {/* masonry grid */}
          {filtered.length > 0 ? (
            <div className="feed-grid">
              {filtered.map((c, i) => (
                <DestinationCard key={c.id} city={c} tall={i % 4 === 0 || i % 4 === 3} onOpen={openDestination} />
              ))}
            </div>
          ) : (
            <p className="archive-empty mt-6">{t('explore.empty')}</p>
          )}

          <div className="h-24 md:h-8" aria-hidden="true" />
        </div>
      </div>
    </div>
  );
}
