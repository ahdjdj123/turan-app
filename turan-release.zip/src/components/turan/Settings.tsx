'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft, Palette, Languages, Volume2, Monitor, DatabaseBackup, Info,
  CircleHelp, ShieldCheck, Download, Upload, Trash2, Save, Globe, Check, FileJson,
} from 'lucide-react';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { toast } from 'sonner';
import { useTuranStore } from '@/lib/store';
import { useTuranLang } from './useTuranLang';
import { GlyphCoin, GlyphFortress } from './glyphs';
import { LANGUAGES } from '@/data/translations';
import { CITIES, TOTAL_COMBINATIONS } from '@/data/cities';
import { ERAS } from '@/data/eras';
import { audio } from '@/lib/audio-engine';
import type { AccentId, ThemeId, FontSizeId, AnimSpeed, QualityId } from '@/lib/turan-types';

type SectionId = 'theme' | 'language' | 'audio' | 'display' | 'progression' | 'about' | 'faq' | 'privacy';

const SECTION_ICONS: Record<SectionId, React.ComponentType<{ size?: number }>> = {
  theme: Palette,
  language: Languages,
  audio: Volume2,
  display: Monitor,
  progression: DatabaseBackup,
  about: Info,
  faq: CircleHelp,
  privacy: ShieldCheck,
};

const SECTION_KEYS: Record<SectionId, 'settings.theme' | 'settings.language' | 'settings.audio' | 'settings.display' | 'settings.progression' | 'settings.about' | 'settings.faq' | 'settings.privacy'> = {
  theme: 'settings.theme',
  language: 'settings.language',
  audio: 'settings.audio',
  display: 'settings.display',
  progression: 'settings.progression',
  about: 'settings.about',
  faq: 'settings.faq',
  privacy: 'settings.privacy',
};

function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      className={`turan-switch ${on ? 'on' : ''}`}
      onClick={() => onChange(!on)}
      role="switch"
      aria-checked={on}
      aria-label={label}
    />
  );
}

function Row({ title, desc, children }: { title: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 py-3.5 border-b" style={{ borderColor: 'var(--t-glass-border)' }}>
      <div className="min-w-0">
        <div className="font-semibold text-sm">{title}</div>
        {desc && <div className="text-xs text-subtle mt-0.5 leading-relaxed">{desc}</div>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

const ACCENTS: { id: AccentId; color: string }[] = [
  { id: 'gold', color: '#D4A53C' },
  { id: 'turquoise', color: '#2A9D8F' },
  { id: 'crimson', color: '#9E2A2B' },
  { id: 'deepblue', color: '#1B2A4A' },
];

const THEMES: { id: ThemeId; preview: string; labelKey: 'theme.dark' | 'theme.parchment' | 'theme.contrast'; descKey: 'theme.darkDesc' | 'theme.parchmentDesc' | 'theme.contrastDesc' }[] = [
  { id: 'classic', preview: 'linear-gradient(135deg, #0D0B1A 0%, #1A1533 60%, #D4A53C 140%)', labelKey: 'theme.dark', descKey: 'theme.darkDesc' },
  { id: 'parchment', preview: 'linear-gradient(135deg, #FDF8EF 0%, #E7DABC 70%, #B8952E 140%)', labelKey: 'theme.parchment', descKey: 'theme.parchmentDesc' },
  { id: 'contrast', preview: 'linear-gradient(135deg, #000 0%, #222 70%, #fff 140%)', labelKey: 'theme.contrast', descKey: 'theme.contrastDesc' },
];

export function Settings() {
  const setScreen = useTuranStore((s) => s.setScreen);
  const settings = useTuranStore((s) => s.settings);
  const setSetting = useTuranStore((s) => s.setSetting);
  const discovered = useTuranStore((s) => s.discovered);
  const lastSaved = useTuranStore((s) => s.lastSaved);
  const markSavedNow = useTuranStore((s) => s.markSavedNow);
  const importData = useTuranStore((s) => s.importData);
  const resetAll = useTuranStore((s) => s.resetAll);
  const { t, eraLabel } = useTuranLang();
  const [section, setSection] = useState<SectionId>('theme');
  const [artworkCount, setArtworkCount] = useState<number | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  // live artwork count for the Museum Collection panel (About)
  useEffect(() => {
    let alive = true;
    fetch('/api/artworks')
      .then((r) => (r.ok ? r.json() : null))
      .then((d: { count?: number | null } | null) => {
        if (alive && d && typeof d.count === 'number') setArtworkCount(d.count);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, []);

  const navItems = useMemo(
    () => (Object.keys(SECTION_KEYS) as SectionId[]).map((id) => ({ id, label: t(SECTION_KEYS[id]), Icon: SECTION_ICONS[id] })),
    [t]
  );

  /* ---------- progression actions ---------- */

  const exportJournal = () => {
    const lines: string[] = [
      '═══════════════════════════════════════',
      '  TURAN — The Heart of the Silk Road',
      '  Travel Journal',
      `  Exported: ${new Date().toLocaleString()}`,
      `  Entries: ${discovered.length}`,
      '═══════════════════════════════════════',
      '',
    ];
    discovered.forEach((key) => {
      const [cityId, eraId] = key.split(':');
      const city = CITIES.find((c) => c.id === cityId);
      const content = city?.eras[eraId as keyof typeof city.eras];
      if (city && content) {
        lines.push(`◆ ${city.name} — ${eraLabel(eraId as 'ancient')}`);
        lines.push(`  ${content.tagline}`);
        lines.push(`  ${content.description}`);
        lines.push(`  ${t('popup.didYouKnow')} ${content.fact}`);
        lines.push('');
      }
    });
    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `turan-journal-${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(t('toast.exported'));
  };

  /** full backup: the ONLY format /import can restore (see onImportFile) */
  const exportSaveFile = () => {
    const s = useTuranStore.getState();
    const payload = {
      app: 'turan',
      version: 1,
      exportedAt: new Date().toISOString(),
      year: s.year,
      discovered: s.discovered,
      settings: s.settings,
      quizBest: s.quizBest,
      quizDifficulty: s.quizDifficulty,
      memoryBest: s.memoryBest,
      memoryBest6: s.memoryBest6,
      memoryBest4: s.memoryBest4,
      spinCount: s.spinCount,
      spinNew: s.spinNew,
      quizMastery: s.quizMastery,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `turan-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(t('toast.exported'));
  };

  const onImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(String(reader.result));
        if (data?.app !== 'turan') throw new Error('bad file');
        importData({
          year: data.year,
          discovered: data.discovered,
          settings: data.settings,
          quizBest: data.quizBest,
          quizDifficulty: data.quizDifficulty,
          memoryBest: data.memoryBest,
          memoryBest6: data.memoryBest6,
          memoryBest4: data.memoryBest4,
          spinCount: data.spinCount,
          spinNew: data.spinNew,
          quizMastery: data.quizMastery,
        });
        toast.success(t('toast.imported'));
      } catch {
        toast.error(t('toast.importFail'));
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const clearAll = () => {
    window.localStorage.removeItem('turan-save-v1');
    resetAll();
    toast.success(t('toast.cleared'));
  };

  const lastSavedText = lastSaved
    ? new Date(lastSaved).toLocaleString(settings.language === 'en' ? 'en-GB' : settings.language)
    : t('prog.never');

  return (
    <main className="turan-root min-h-screen flex flex-col px-3 sm:px-6 py-4">
      {/* header */}
      <header className="w-full max-w-4xl mx-auto flex items-center justify-between mb-4">
        <button
          className="btn-glass py-2 px-3.5 text-sm"
          onClick={() => {
            audio.play('click');
            setScreen('menu');
          }}
        >
          <ArrowLeft size={16} className="flip-rtl" aria-hidden="true" />
          <span className="hidden sm:inline">{t('common.backToMenu')}</span>
        </button>
        <h1 className="text-lg sm:text-2xl font-bold tracking-[0.18em] uppercase text-heading" style={{ fontFamily: 'var(--font-display)' }}>
          <GlyphCoin size={19} strokeWidth={1.6} />
          {t('settings.title')}
        </h1>
        <div className="w-[104px] hidden sm:block" />
      </header>

      <div className="w-full max-w-4xl mx-auto flex-1 flex flex-col md:flex-row gap-4 min-h-0">
        {/* nav */}
        <nav className="glass p-2 md:w-60 shrink-0 flex md:flex-col overflow-x-auto md:overflow-visible gap-1" aria-label={t('settings.title')}>
          {navItems.map(({ id, label, Icon }) => (
            <button
              key={id}
              className={`settings-nav-item ${section === id ? 'active' : ''}`}
              onClick={() => {
                setSection(id);
                audio.play('click');
              }}
            >
              <Icon size={17} />
              <span className="whitespace-nowrap">{label}</span>
            </button>
          ))}
        </nav>

        {/* panel */}
        <section className="glass-strong ornate flex-1 p-5 sm:p-6 min-h-0 turan-scroll" aria-label={t(SECTION_KEYS[section])}>
          {/* ---------------- THEME ---------------- */}
          {section === 'theme' && (
            <div className="ink-fade">
              <h2 className="text-lg font-bold mb-4 gold-glow-text tracking-wider">{t('settings.theme')}</h2>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
                {THEMES.map((th) => (
                  <button
                    key={th.id}
                    className={`rounded-2xl p-3 text-start transition-all border ${
                      settings.theme === th.id ? 'scale-[1.02]' : 'opacity-80 hover:opacity-100'
                    }`}
                    style={{
                      borderColor: settings.theme === th.id ? 'var(--t-accent)' : 'var(--t-glass-border)',
                      background: 'var(--t-panel)',
                      boxShadow: settings.theme === th.id ? '0 0 18px var(--t-accent-glow)' : 'none',
                    }}
                    onClick={() => {
                      setSetting('theme', th.id);
                      audio.play('click');
                    }}
                    aria-pressed={settings.theme === th.id}
                  >
                    <div className="h-16 rounded-xl mb-2 border" style={{ background: th.preview, borderColor: 'var(--t-glass-border)' }} />
                    <div className="text-sm font-semibold">{t(th.labelKey)}</div>
                    <div className="text-[11px] text-subtle mt-0.5 leading-snug">{t(th.descKey)}</div>
                  </button>
                ))}
              </div>

              <Row title={t('theme.accent')} desc={t('theme.accentDesc')}>
                <div className="flex gap-2">
                  {ACCENTS.map((a) => (
                    <button
                      key={a.id}
                      className="w-8 h-8 rounded-full grid place-items-center transition-transform hover:scale-110"
                      style={{
                        background: a.color,
                        border: settings.accent === a.id ? '2px solid var(--t-text)' : '2px solid transparent',
                        boxShadow: settings.accent === a.id ? `0 0 12px ${a.color}` : 'none',
                      }}
                      onClick={() => {
                        setSetting('accent', a.id);
                        audio.play('click');
                      }}
                      aria-label={a.id}
                      aria-pressed={settings.accent === a.id}
                    >
                      {settings.accent === a.id && <Check size={14} color="#fff" />}
                    </button>
                  ))}
                </div>
              </Row>

              <Row title={t('theme.font')}>
                <div className="seg-group">
                  {(['sm', 'md', 'lg'] as FontSizeId[]).map((fs) => (
                    <button
                      key={fs}
                      className={`seg-option ${settings.fontSize === fs ? 'active' : ''}`}
                      onClick={() => {
                        setSetting('fontSize', fs);
                        audio.play('click');
                      }}
                    >
                      {fs === 'sm' ? t('theme.fontSm') : fs === 'md' ? t('theme.fontMd') : t('theme.fontLg')}
                    </button>
                  ))}
                </div>
              </Row>
            </div>
          )}

          {/* ---------------- LANGUAGE ---------------- */}
          {section === 'language' && (
            <div className="ink-fade">
              <h2 className="text-lg font-bold mb-1 gold-glow-text tracking-wider">{t('settings.language')}</h2>
              <p className="text-xs text-subtle mb-4">{t('lang.desc')}</p>
              <div className="flex flex-col gap-2">
                {LANGUAGES.map((l) => (
                  <button
                    key={l.id}
                    className="landmark-item px-4 py-3 flex items-center justify-between text-start"
                    onClick={() => {
                      setSetting('language', l.id);
                      audio.play('click');
                    }}
                    aria-pressed={settings.language === l.id}
                  >
                    <span className="flex items-center gap-3">
                      <Globe size={16} style={{ color: 'var(--t-accent)' }} aria-hidden="true" />
                      <span className="font-semibold">{l.native}</span>
                      <span className="text-xs text-subtle">{t(`lang.${l.id}`)}</span>
                    </span>
                    {settings.language === l.id && <Check size={16} style={{ color: 'var(--t-accent)' }} aria-label="selected" />}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* ---------------- AUDIO ---------------- */}
          {section === 'audio' && (
            <div className="ink-fade">
              <h2 className="text-lg font-bold mb-4 gold-glow-text tracking-wider">{t('settings.audio')}</h2>

              <Row title={`${t('audio.master')} — ${settings.masterVolume}%`}>
                <div className="w-40">
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={settings.masterVolume}
                    onChange={(e) => {
                      setSetting('masterVolume', parseInt(e.target.value, 10));
                      audio.setVolume(parseInt(e.target.value, 10));
                    }}
                    className="volume-slider"
                    style={{ ['--fill' as string]: `${settings.masterVolume}%` }}
                    aria-label={t('audio.master')}
                  />
                </div>
              </Row>

              <Row title={t('audio.music')} desc={t('audio.musicDesc')}>
                <Toggle
                  on={settings.music}
                  label={t('audio.music')}
                  onChange={(v) => {
                    setSetting('music', v);
                    audio.setVolume(settings.masterVolume);
                    audio.setMusic(v);
                  }}
                />
              </Row>

              <Row title={t('audio.narration')} desc={t('audio.narrationDesc')}>
                <Toggle on={settings.narration} label={t('audio.narration')} onChange={(v) => setSetting('narration', v)} />
              </Row>

              <Row title={t('audio.narrSpeed')} desc={t('audio.narrSpeedDesc')}>
                <div className="seg-group">
                  {([0.8, 0.95, 1.15] as const).map((sp) => (
                    <button
                      key={sp}
                      className={`seg-option ${settings.narrationSpeed === sp ? 'active' : ''}`}
                      onClick={() => {
                        setSetting('narrationSpeed', sp);
                        audio.play('click');
                      }}
                    >
                      {sp === 0.8 ? t('display.animSlow') : sp === 0.95 ? t('display.animNormal') : t('display.animFast')}
                    </button>
                  ))}
                </div>
              </Row>

              <Row title={t('audio.sfx')} desc={t('audio.sfxDesc')}>
                <Toggle
                  on={settings.sfx}
                  label={t('audio.sfx')}
                  onChange={(v) => {
                    setSetting('sfx', v);
                    audio.setSfx(v);
                    if (v) audio.play('click');
                  }}
                />
              </Row>
            </div>
          )}

          {/* ---------------- DISPLAY ---------------- */}
          {section === 'display' && (
            <div className="ink-fade">
              <h2 className="text-lg font-bold mb-4 gold-glow-text tracking-wider">{t('settings.display')}</h2>

              <Row title={t('display.quality')} desc={t('display.qualityDesc')}>
                <div className="seg-group">
                  {(['720', '1080', '1440'] as QualityId[]).map((q) => (
                    <button
                      key={q}
                      className={`seg-option ${settings.quality === q ? 'active' : ''}`}
                      onClick={() => {
                        setSetting('quality', q);
                        audio.play('click');
                      }}
                    >
                      {q}p
                    </button>
                  ))}
                </div>
              </Row>

              <Row title={t('display.fullscreen')} desc={t('display.fullscreenDesc')}>
                <Toggle
                  on={Boolean(document.fullscreenElement)}
                  label={t('display.fullscreen')}
                  onChange={(v) => {
                    if (v) {
                      document.documentElement.requestFullscreen?.().catch(() => undefined);
                    } else {
                      document.exitFullscreen?.().catch(() => undefined);
                    }
                  }}
                />
              </Row>

              <Row title={t('display.anim')}>
                <div className="seg-group">
                  {(['slow', 'normal', 'fast'] as AnimSpeed[]).map((a) => (
                    <button
                      key={a}
                      className={`seg-option ${settings.animSpeed === a ? 'active' : ''}`}
                      onClick={() => {
                        setSetting('animSpeed', a);
                        audio.play('click');
                      }}
                    >
                      {a === 'slow' ? t('display.animSlow') : a === 'normal' ? t('display.animNormal') : t('display.animFast')}
                    </button>
                  ))}
                </div>
              </Row>

              <Row title={t('display.glass')} desc={t('display.glassDesc')}>
                <Toggle on={settings.glass} label={t('display.glass')} onChange={(v) => setSetting('glass', v)} />
              </Row>

              <Row title={t('display.compass')}>
                <Toggle on={settings.showCompass} label={t('display.compass')} onChange={(v) => setSetting('showCompass', v)} />
              </Row>

              <Row title={t('display.progress')}>
                <Toggle on={settings.showProgress} label={t('display.progress')} onChange={(v) => setSetting('showProgress', v)} />
              </Row>

              <Row title={t('display.offline')} desc={t('display.offlineDesc')}>
                <Toggle on={settings.offlineMode} label={t('display.offline')} onChange={(v) => setSetting('offlineMode', v)} />
              </Row>
            </div>
          )}

          {/* ---------------- PROGRESSION ---------------- */}
          {section === 'progression' && (
            <div className="ink-fade">
              <h2 className="text-lg font-bold mb-4 gold-glow-text tracking-wider">{t('settings.progression')}</h2>

              <Row title={t('prog.autoSave')} desc={t('prog.autoSaveDesc')}>
                <Toggle on={settings.autoSave} label={t('prog.autoSave')} onChange={(v) => setSetting('autoSave', v)} />
              </Row>

              <Row title={t('prog.lastSaved')} desc={lastSavedText}>
                <button
                  className="btn-glass py-2 px-3.5 text-xs"
                  onClick={() => {
                    markSavedNow();
                    audio.play('click');
                    toast.success(t('toast.saved'));
                  }}
                >
                  <Save size={14} aria-hidden="true" />
                  {t('prog.saveNow')}
                </button>
              </Row>

              <Row title={t('prog.export')} desc={t('prog.exportDesc')}>
                <button className="btn-glass py-2 px-3.5 text-xs" onClick={exportJournal}>
                  <Download size={14} aria-hidden="true" />
                  {t('prog.export')}
                </button>
              </Row>

              <Row title={t('prog.exportSave')} desc={t('prog.exportSaveDesc')}>
                <button className="btn-glass py-2 px-3.5 text-xs" onClick={exportSaveFile}>
                  <FileJson size={14} aria-hidden="true" />
                  {t('prog.exportSave')}
                </button>
              </Row>

              <Row title={t('prog.import')} desc={t('prog.importDesc')}>
                <button className="btn-glass py-2 px-3.5 text-xs" onClick={() => fileRef.current?.click()}>
                  <Upload size={14} aria-hidden="true" />
                  {t('prog.import')}
                </button>
                <input ref={fileRef} type="file" accept=".json,application/json" className="hidden" onChange={onImportFile} aria-hidden="true" />
              </Row>

              <Row title={t('prog.clear')} desc={t('prog.clearDesc')}>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <button className="btn-glass py-2 px-3.5 text-xs" style={{ borderColor: '#9E2A2B', color: '#e07a7a' }}>
                      <Trash2 size={14} aria-hidden="true" />
                      {t('prog.clear')}
                    </button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="glass-strong">
                    <AlertDialogHeader>
                      <AlertDialogTitle className="text-heading">{t('prog.clearTitle')}</AlertDialogTitle>
                      <AlertDialogDescription className="text-subtle">{t('prog.clearBody')}</AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="btn-glass py-2 px-4 text-sm">{t('prog.clearCancel')}</AlertDialogCancel>
                      <AlertDialogAction
                        className="btn-glass py-2 px-4 text-sm"
                        style={{ background: '#9E2A2B', color: '#fff', borderColor: '#9E2A2B' }}
                        onClick={clearAll}
                      >
                        {t('prog.clearYes')}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </Row>
            </div>
          )}

          {/* ---------------- ABOUT ---------------- */}
          {section === 'about' && (
            <div className="ink-fade">
              <h2 className="text-lg font-bold mb-5 gold-glow-text tracking-wider">{t('settings.about')}</h2>
              <div className="text-center mb-6">
                <div className="mb-2" aria-hidden="true" style={{ color: 'var(--t-accent)' }}><GlyphFortress size={40} strokeWidth={1.2} /></div>
                <div className="turan-title text-4xl inline-block">TURAN</div>
                <p className="text-subtle text-sm mt-1">{t('about.name')}</p>
              </div>

              {/* museum collection stats */}
              <div className="about-stats" role="group" aria-label={t('about.collection')}>
                <div className="about-stats-title">
                  <span className="ornament-dot" aria-hidden="true">✦</span>
                  {t('about.collection')}
                  <span className="ornament-dot" aria-hidden="true">✦</span>
                </div>
                <div className="about-stats-grid">
                  {[
                    { label: t('about.statCities'), value: String(CITIES.length) },
                    { label: t('about.statEras'), value: String(ERAS.length) },
                    { label: t('about.statScenes'), value: String(TOTAL_COMBINATIONS) },
                    {
                      label: t('about.statLandmarks'),
                      value: String(
                        CITIES.reduce(
                          (n, c) => n + Object.values(c.eras).reduce((m, e) => m + (e?.landmarks.length ?? 0), 0),
                          0
                        )
                      ),
                    },
                    { label: t('about.statArtworks'), value: artworkCount === null ? '…' : `${artworkCount}/${TOTAL_COMBINATIONS}` },
                    { label: t('about.statJournal'), value: `${discovered.length}/${TOTAL_COMBINATIONS}` },
                  ].map((s, i) => (
                    <div key={s.label} className="about-stat-tile" style={{ animationDelay: `${i * 60}ms` }}>
                      <span className="about-stat-value tabular-nums">{s.value}</span>
                      <span className="about-stat-label">{s.label}</span>
                    </div>
                  ))}
                </div>
                {artworkCount !== null && artworkCount < TOTAL_COMBINATIONS && (
                  <div className="about-stats-progress" aria-hidden="true">
                    <div className="about-stats-progress-fill" style={{ width: `${Math.round((artworkCount / TOTAL_COMBINATIONS) * 100)}%` }} />
                  </div>
                )}
              </div>

              <dl className="text-sm space-y-2.5">
                {[
                  [t('about.version'), '2.0.0'],
                  [t('about.developer'), t('about.developerName')],
                  [t('about.date'), t('about.dateValue')],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between border-b pb-2" style={{ borderColor: 'var(--t-glass-border)' }}>
                    <dt className="text-subtle">{k}</dt>
                    <dd className="font-semibold">{v}</dd>
                  </div>
                ))}
              </dl>

              {/* version history plaque */}
              <div className="changelog mt-6" role="group" aria-label={t('about.changelog')}>
                <div className="about-stats-title mb-3">
                  <span className="ornament-dot" aria-hidden="true">✦</span>
                  {t('about.changelog')}
                  <span className="ornament-dot" aria-hidden="true">✦</span>
                </div>
                <ol className="changelog-list turan-scroll">
                  {([
                    ['1.9', 'about.changelog9'],
                    ['1.8', 'about.changelog8'],
                    ['1.7', 'about.changelog7'],
                    ['1.6', 'about.changelog6'],
                    ['1.5', 'about.changelog5'],
                    ['1.4', 'about.changelog4'],
                    ['1.3', 'about.changelog3'],
                    ['1.2', 'about.changelog2'],
                    ['1.0', 'about.changelog1'],
                  ] as const).map(([ver, key], i) => (
                    <li key={ver} className="changelog-row" style={{ animationDelay: `${i * 55}ms` }}>
                      <span className="changelog-ver tabular-nums">v{ver}</span>
                      <span className="changelog-text">{t(key as 'about.changelog1')}</span>
                    </li>
                  ))}
                </ol>
              </div>
              <p className="text-sm leading-relaxed mt-5">{t('about.desc')}</p>
              <h3 className="text-sm font-bold mt-5 mb-1" style={{ color: 'var(--t-accent)' }}>{t('about.credits')}</h3>
              <p className="text-xs text-subtle leading-relaxed">{t('about.creditsText')}</p>
              <h3 className="text-sm font-bold mt-5 mb-1" style={{ color: 'var(--t-accent)' }}>{t('about.license')}</h3>
              <p className="text-xs text-subtle leading-relaxed">{t('about.licenseText')}</p>
            </div>
          )}

          {/* ---------------- FAQ ---------------- */}
          {section === 'faq' && (
            <div className="ink-fade">
              <h2 className="text-lg font-bold mb-4 gold-glow-text tracking-wider">{t('settings.faq')}</h2>
              <Accordion type="single" collapsible className="w-full">
                {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                  <AccordionItem key={i} value={`q${i}`} style={{ borderColor: 'var(--t-glass-border)' }}>
                    <AccordionTrigger className="text-sm text-start hover:no-underline">
                      {t(`faq.q${i}` as 'faq.q1')}
                    </AccordionTrigger>
                    <AccordionContent className="text-sm text-subtle leading-relaxed">
                      {t(`faq.a${i}` as 'faq.a1')}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          )}

          {/* ---------------- PRIVACY ---------------- */}
          {section === 'privacy' && (
            <div className="ink-fade">
              <h2 className="text-lg font-bold mb-4 gold-glow-text tracking-wider">{t('settings.privacy')}</h2>
              <div className="flex flex-col gap-4">
                {[
                  ['privacy.storage', 'privacy.storageText'],
                  ['privacy.noCollection', 'privacy.noCollectionText'],
                  ['privacy.clear', 'privacy.clearText'],
                  ['privacy.third', 'privacy.thirdText'],
                  ['privacy.images', 'privacy.imagesText'],
                ].map(([k, dk]) => (
                  <div key={k} className="landmark-item p-4">
                    <div className="flex items-center gap-2 font-semibold text-sm mb-1">
                      <ShieldCheck size={15} style={{ color: 'var(--t-accent)' }} aria-hidden="true" />
                      {t(k as 'privacy.storage')}
                    </div>
                    <p className="text-xs text-subtle leading-relaxed">{t(dk as 'privacy.storageText')}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
