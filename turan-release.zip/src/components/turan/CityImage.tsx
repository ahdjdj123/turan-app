'use client';

import { useState } from 'react';

interface CityImageProps {
  cityId: string;
  eraId: string;
  cityName: string;
  eraLabel: string;
  className?: string;
}

/**
 * Renders an AI-painted city artwork when available, otherwise falls back to
 * a beautiful parchment "archive plate" placeholder with the city name + era.
 */
export function CityImage({ cityId, eraId, cityName, eraLabel, className = '' }: CityImageProps) {
  const [failed, setFailed] = useState(false);
  const src = `/images/cities/${cityId}_${eraId}.png`;

  if (failed) {
    return (
      <div className={`placeholder-art flex flex-col items-center justify-center gap-2 ${className}`}>
        <svg
          viewBox="0 0 100 60"
          className="w-24 h-14 opacity-70"
          fill="none"
          stroke="#8b6b2b"
          strokeWidth="1.2"
          aria-hidden="true"
        >
          {/* stylized skyline: domes + minaret */}
          <path d="M8 52 L8 30 L16 30 L16 52" />
          <path d="M24 52 L24 26 Q31 12 38 26 L38 52" />
          <circle cx="31" cy="22" r="2.4" />
          <path d="M31 12 L31 8 M29.6 9.6 L32.4 9.6" />
          <path d="M46 52 L46 32 L58 32 L58 52" />
          <path d="M52 32 L52 22" />
          <path d="M66 52 L66 26 Q73 10 80 26 L80 52" />
          <circle cx="73" cy="22" r="2.6" />
          <path d="M73 12 L73 8 M71.5 9.6 L74.5 9.6" />
          <path d="M88 52 L88 34 L94 34 L94 52" />
          <path d="M2 52 L98 52" />
        </svg>
        <div className="text-center px-4" style={{ color: '#6b5a3e' }}>
          <div className="text-lg font-bold tracking-[0.18em] uppercase">{cityName}</div>
          <div className="text-xs tracking-[0.28em] uppercase mt-1">{eraLabel}</div>
          <div className="text-[10px] tracking-[0.3em] uppercase mt-3 opacity-70">
            Turan Archive
          </div>
        </div>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={`${cityName} during the ${eraLabel} era`}
      className={`object-cover ${className}`}
      loading="lazy"
      onError={() => setFailed(true)}
    />
  );
}
