'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { useTuranStore } from '@/lib/store';

export type NarrationState = 'idle' | 'loading' | 'playing';

/* ---------------- session audio cache ----------------
 * Generated WAV blobs are kept for the whole session so replaying a
 * narration (reopening a popup, re-listening to a fact) is instant and
 * costs zero network. FIFO-capped to bound memory (~4-5 MB). */
const NARRATION_CACHE_MAX = 12;
const narrationCache = new Map<string, Blob>();

function narrationKey(text: string, speed: number): string {
  return `${speed}|${text}`;
}

function cacheNarration(key: string, blob: Blob) {
  if (narrationCache.has(key)) narrationCache.delete(key); // refresh LRU position
  narrationCache.set(key, blob);
  if (narrationCache.size > NARRATION_CACHE_MAX) {
    const oldest = narrationCache.keys().next().value;
    if (oldest !== undefined) narrationCache.delete(oldest);
  }
}

/**
 * On-demand narrated tour: posts text to /api/narrate (server-side z-ai TTS)
 * and plays the returned WAV. Respects the narration setting and master volume.
 * Blobs are cached per session — the server also keeps a disk cache.
 */
export function useNarration(getText: () => string) {
  const [state, setState] = useState<NarrationState>('idle');
  const [error, setError] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const urlRef = useRef<string | null>(null);
  const masterVolume = useTuranStore((s) => s.settings.masterVolume);
  const narrationOn = useTuranStore((s) => s.settings.narration);
  const narrSpeed = useTuranStore((s) => s.settings.narrationSpeed);

  const stop = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current = null;
    }
    if (urlRef.current) {
      URL.revokeObjectURL(urlRef.current);
      urlRef.current = null;
    }
    setState('idle');
  }, []);

  const toggle = useCallback(async () => {
    if (state === 'playing') {
      stop();
      return;
    }
    if (state === 'loading') return;
    setState('loading');
    setError(false);
    try {
      const key = narrationKey(getText(), narrSpeed);
      // session cache hit: instant replay, no fetch at all
      const cached = narrationCache.get(key);
      const blob = cached ?? await (async () => {
        const res = await fetch('/api/narrate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: getText(), speed: narrSpeed }),
        });
        if (!res.ok) throw new Error(`status ${res.status}`);
        const b = await res.blob();
        cacheNarration(key, b);
        return b;
      })();
      const url = URL.createObjectURL(blob);
      urlRef.current = url;
      const audio = new Audio(url);
      audio.volume = Math.min(1, (masterVolume / 100) * 0.95);
      audio.onended = () => stop();
      audio.onerror = () => {
        setError(true);
        stop();
      };
      audioRef.current = audio;
      await audio.play();
      setState('playing');
    } catch {
      setError(true);
      setState('idle');
    }
  }, [state, stop, getText, masterVolume, narrSpeed]);

  // stop when the narration setting is switched OFF mid-playback
  // (zustand subscribe: only reacts to CHANGES, not to the initial value)
  const prevNarrationOn = useRef(narrationOn);
  useEffect(() => {
    prevNarrationOn.current = useTuranStore.getState().settings.narration;
    const unsub = useTuranStore.subscribe((s) => {
      const now = s.settings.narration;
      if (prevNarrationOn.current && !now) stop();
      prevNarrationOn.current = now;
    });
    return unsub;
  }, [stop]);

  // cleanup on unmount
  useEffect(() => stop, [stop]);

  return { state, error, toggle, stop };
}
