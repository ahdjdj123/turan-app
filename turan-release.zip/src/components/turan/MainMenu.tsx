'use client';

import { useEffect, useMemo, useState } from 'react';
import { Dices, Gamepad2, Settings2, BookOpen, WifiOff, Download, MonitorSmartphone, ChevronRight, Star } from 'lucide-react';
import { useTuranStore } from '@/lib/store';
import { toast } from 'sonner';
import { useUIStore } from '@/lib/ui-store';
import { useTuranLang } from './useTuranLang';
import { CityImage } from './CityImage';
import { EraGlyph, GlyphCamel, GlyphCompassRose } from './glyphs';
import { ERA_MAP, type EraId } from '@/data/eras';
import { CITIES, TOTAL_COMBINATIONS, type City } from '@/data/cities';
import { audio } from '@/lib/audio-engine';

interface TodayPick {
  city: City;
  eraId: EraId;
}

/** minimal shape of the browser's deferred install prompt */
interface InstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

/** true once the app already runs as an installed PWA */
function isStandalone(): boolean {
  return typeof window !== 'undefined' && (
    window.matchMedia('(display-mode: standalone)').matches ||
    // iOS Safari
    (window.navigator as Navigator & { standalone?: boolean }).standalone === true
  );
}

/** deterministic city×era for the current local date — changes at midnight */
function pickToday(): TodayPick {
  const combos: TodayPick[] = CITIES.flatMap((city) =>
    (Object.keys(city.eras) as EraId[]).map((eraId) => ({ city, eraId }))
  );
  const d = new Date();
  const seed = d.getFullYear() * 372 + (d.getMonth() + 1) * 31 + d.getDate();
  return combos[seed % combos.length];
}

export function MainMenu() {
  const setScreen = useTuranStore((s) => s.setScreen);
  const discovered = useTuranStore((s) => s.discovered);
  const openCity = useTuranStore((s) => s.openCity);
  const { t, eraLabel, eraDesc, cityName } = useTuranLang();
  const today = useMemo(() => pickToday(), []);
  const [online, setOnline] = useState(true);
  const [installEvt, setInstallEvt] = useState<InstallPromptEvent | null>(null);
  const [standalone, setStandalone] = useState(() => isStandalone());

  useEffect(() => {
    const upd = () => setOnline(navigator.onLine);
    upd();
    window.addEventListener('online', upd);
    window.addEventListener('offline', upd);
    const onInstallAvailable = (e: Event) => {
      e.preventDefault(); // keep TURAN's own install chip
      setInstallEvt(e as InstallPromptEvent);
    };
    const onInstalled = () => {
      setInstallEvt(null);
      setStandalone(true);
    };
    window.addEventListener('beforeinstallprompt', onInstallAvailable);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('online', upd);
      window.removeEventListener('offline', upd);
      window.removeEventListener('beforeinstallprompt', onInstallAvailable);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);

  const installApp = async () => {
    if (!installEvt || typeof installEvt.prompt !== 'function') return;
    audio.play('click');
    installEvt.prompt();
    try {
      const choice = await installEvt.userChoice;
      if (choice.outcome === 'accepted') toast.success(t('menu.installDone'));
    } catch {
      /* user dismissed or browser closed the prompt */
    }
    setInstallEvt(null);
  };

  const go = (screen: 'map' | 'random' | 'leisure' | 'settings' | 'journal') => {
    audio.play('click');
    setScreen(screen);
  };

  const openToday = () => {
    audio.play('click');
    openCity(today.city.id, today.eraId, false);
    setScreen('map');
  };

  const todaySaved = discovered.includes(`${today.city.id}:${today.eraId}`);
  const progressPct = Math.round((discovered.length / TOTAL_COMBINATIONS) * 100);

  return (
    <main className="turan-root relative min-h-screen flex flex-col">
      {/* ============ CINEMATIC HERO — bleeds edge-to-edge ============ */}
      <section
        className="hero-panorama relative w-full"
        role="img"
        aria-label="Samarkand skyline at sunrise with a Silk Road caravan crossing golden dunes"
      >
        <picture>
          <img
            src="/images/cities/hero_panorama.png"
            alt=""
            className="hero-panorama-img"
            loading="eager"
            decoding="async"
            onError={(e) => {
              const img = e.currentTarget;
              if (!img.dataset.fallback) {
                img.dataset.fallback = '1';
                img.src = '/images/cities/menu_caravan.png';
              } else {
                img.style.display = 'none';
              }
            }}
          />
        </picture>
        {/* scrim — lets the ivory wordmark breathe over the skyline */}
        <div className="hero-scrim" aria-hidden="true" />

        {/* overlay: only TURAN and its epithet. nothing else. */}
        <header className="hero-wordmark absolute inset-x-0 bottom-0 text-center select-none px-6 pb-7">
          <h1 className="hero-title t-display">TURAN</h1>
          <p className="hero-epithet t-eyebrow" style={{ color: 'rgba(242,237,225,0.82)' }}>
            {t('app.subtitle')}
          </p>
        </header>
      </section>

      {/* drifting gold dust — sparse, slow */}
      <div className="dust-field pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
        {[
          { left: '14%', size: 2, delay: '0s', dur: '13s', drift: '22px' },
          { left: '34%', size: 3, delay: '-6s', dur: '15s', drift: '-16px' },
          { left: '58%', size: 2, delay: '-3s', dur: '17s', drift: '18px' },
          { left: '78%', size: 2, delay: '-9s', dur: '14s', drift: '-20px' },
          { left: '92%', size: 3, delay: '-5s', dur: '12.5s', drift: '14px' },
        ].map((mote, i) => (
          <span
            key={i}
            className="dust-mote"
            style={{
              left: mote.left,
              width: mote.size,
              height: mote.size,
              animationDelay: mote.delay,
              animationDuration: mote.dur,
              ['--drift' as string]: mote.drift,
            }}
          />
        ))}
      </div>

      {/* ============ BODY ============ */}
      <div className="relative flex-1 w-full max-w-xl mx-auto flex flex-col gap-6 px-5 pt-7 pb-6">
        {/* ---- Today's discovery · a parchment artifact ---- */}
        {today && (
          <section aria-labelledby="today-heading">
            <h2 id="today-heading" className="sr-only">{t('menu.today')}</h2>
            <button className="artifact-panel w-full text-start" onClick={openToday}>
              <span className="artifact-art">
                <CityImage
                  cityId={today.city.id}
                  eraId={today.eraId}
                  cityName={today.city.name}
                  eraLabel={eraLabel(today.eraId)}
                  className="w-full h-full"
                />
                {/* era seal pressed into the artwork corner */}
                <span className="artifact-seal" style={{ '--seal-color': ERA_MAP[today.eraId].color } as React.CSSProperties}>
                  <EraGlyph eraId={today.eraId} size={15} strokeWidth={1.7} />
                </span>
              </span>
              <span className="artifact-body">
                <span className="t-caption" style={{ color: 'rgba(43,33,24,0.62)' }}>
                  {t('menu.today')}
                </span>
                <span className="artifact-name">{cityName(today.city.name, today.city.names)}</span>
                <span className="artifact-era" style={{ color: ERA_MAP[today.eraId].color }}>
                  <EraGlyph eraId={today.eraId} size={11} strokeWidth={1.8} />
                  {eraLabel(today.eraId)}
                </span>
                <span className="artifact-fact">{eraDesc(today.eraId)}</span>
              </span>
              {/* antique brass arrow */}
              <span className="artifact-go" aria-hidden="true">
                <ChevronRight size={16} className="flip-rtl" strokeWidth={2} />
              </span>
            </button>

            {/* quiet progress line under the artifact */}
            <div className="menu-progress" aria-hidden="true">
              <div className="menu-progress-track">
                <div className="menu-progress-fill" style={{ width: `${Math.max(progressPct, 1.5)}%` }} />
              </div>
              <span className="menu-progress-label t-caption">
                {discovered.length} / {TOTAL_COMBINATIONS}
                {todaySaved && (
                  <span className="inline-flex items-center gap-1 ms-2" style={{ color: 'var(--t-accent)' }}>
                    <Star size={9} fill="currentColor" /> {t('menu.todaySaved')}
                  </span>
                )}
              </span>
            </div>
          </section>
        )}

        {/* ---- the three paths ---- */}
        <nav className="flex flex-col gap-2.5" aria-label={t('menu.begin')}>
          <button className="btn-royal-gold w-full" onClick={() => go('map')}>
            <GlyphCompassRose size={20} strokeWidth={1.6} />
            <span className="btn-royal-label">{t('menu.begin')}</span>
          </button>

          <button className="btn-royal-brass w-full" onClick={() => go('random')}>
            <GlyphCamel size={20} strokeWidth={1.6} />
            <span className="btn-royal-label">{t('menu.random')}</span>
          </button>

          <div className="grid grid-cols-2 gap-2.5 mt-0.5">
            <button className="btn-quiet" onClick={() => go('leisure')}>
              <Gamepad2 size={16} aria-hidden="true" />
              <span>{t('menu.leisure')}</span>
            </button>
            <button className="btn-quiet" onClick={() => go('settings')}>
              <Settings2 size={16} aria-hidden="true" />
              <span>{t('menu.settings')}</span>
            </button>
          </div>
        </nav>

        {/* ---- journal, install, colophon ---- */}
        <button
          className="menu-journal-link"
          onClick={() => go('journal')}
        >
          <BookOpen size={14} aria-hidden="true" />
          <span>{t('journal.open')}</span>
          <span className="menu-journal-count tabular-nums">{discovered.length}</span>
        </button>

        {installEvt && !standalone && (
          <button className="install-chip" onClick={installApp} aria-label={t('menu.install')}>
            <MonitorSmartphone size={14} aria-hidden="true" />
            <span className="install-text">{t('menu.install')}</span>
            <span className="install-cta">
              <Download size={12} aria-hidden="true" />
            </span>
          </button>
        )}

        <p className="menu-quote">{t('menu.quote')}</p>
      </div>

      <footer className="relative mt-auto w-full flex justify-between items-center px-5 pt-2 pb-[max(env(safe-area-inset-bottom),0.9rem)] text-[10px] tracking-[0.18em] uppercase text-subtle">
        <span className="flex items-center gap-1.5">
          {t('menu.version')}
          {!online && (
            <span className="offline-chip" role="status">
              <WifiOff size={11} aria-hidden="true" />
              {t('menu.offline')}
            </span>
          )}
        </span>
        <span className="hidden sm:block">{t('menu.footerNote')}</span>
      </footer>
    </main>
  );
}
