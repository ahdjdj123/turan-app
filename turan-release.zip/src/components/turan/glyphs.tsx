'use client';

import type { EraId } from '@/data/eras';

/**
 * TURAN historical iconography.
 * One handcrafted family: 24×24 stroke glyphs inspired by manuscript
 * illumination and Central Asian ornament — no emoji, no generic icons.
 * Stroke = currentColor so glyphs inherit era/accent colors.
 */

interface GlyphProps {
  size?: number;
  className?: string;
  strokeWidth?: number;
}

function Svg({ size = 18, className, strokeWidth = 1.5, children }: GlyphProps & { children: React.ReactNode }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {children}
    </svg>
  );
}

/* ---- the app mark: eight-point Timurid star inside a ring ---- */
export function GlyphCompassRose(p: GlyphProps) {
  return (
    <Svg {...p}>
      <circle cx="12" cy="12" r="10" opacity="0.55" />
      <path d="M12 2.6 L13.8 8.4 L20 7 L16 12 L20 17 L13.8 15.6 L12 21.4 L10.2 15.6 L4 17 L8 12 L4 7 L10.2 8.4 Z" />
      <circle cx="12" cy="12" r="1.1" fill="currentColor" stroke="none" />
    </Svg>
  );
}

/* ---- ancient · Zoroastrian fire altar ---- */
export function GlyphFireAltar(p: GlyphProps) {
  return (
    <Svg {...p}>
      <path d="M12 3.2 C10.6 5 10.4 6.4 12 8 C13.6 6.4 13.4 5 12 3.2 Z" />
      <path d="M9 10.5 C9 8.9 10.3 8.4 12 8.4 C13.7 8.4 15 8.9 15 10.5" />
      <path d="M7.5 13.5 H16.5" />
      <path d="M8.5 13.5 V17 M15.5 13.5 V17" />
      <path d="M6.5 20 H17.5" />
      <path d="M9.5 17 L9 20 M14.5 17 L15 20" opacity="0.7" />
    </Svg>
  );
}

/* ---- hellenistic · crossed swords of the conquerors ---- */
export function GlyphSwords(p: GlyphProps) {
  return (
    <Svg {...p}>
      <path d="M5.5 4.5 L16 15" />
      <path d="M18.5 4.5 L8 15" />
      <path d="M14.6 16.4 L17.5 19.3 M15.6 13.6 L20 18 M17.4 15.4 L20.5 12.3" />
      <path d="M9.4 16.4 L6.5 19.3 M8.4 13.6 L4 18 M6.6 15.4 L3.5 12.3" />
      <circle cx="12" cy="12.4" r="1" fill="currentColor" stroke="none" opacity="0.85" />
    </Svg>
  );
}

/* ---- islamic golden age · dome with crescent ---- */
export function GlyphDomeCrescent(p: GlyphProps) {
  return (
    <Svg {...p}>
      <path d="M5 19 H19" />
      <path d="M6.5 19 V13.2 C6.5 10 9 8 12 8 C15 8 17.5 10 17.5 13.2 V19" />
      <path d="M12 8 V6.2" />
      <path d="M13.9 4.4 A1.9 1.9 0 1 0 13.9 6.4 A1.55 1.55 0 1 1 13.9 4.4 Z" />
      <path d="M8.6 19 V14.5 M15.4 19 V14.5" opacity="0.6" />
    </Svg>
  );
}

/* ---- timurid · the imperial eight-point star ---- */
export function GlyphStar8(p: GlyphProps) {
  return (
    <Svg {...p}>
      <path d="M12 2.8 L14.5 9.5 L21.2 12 L14.5 14.5 L12 21.2 L9.5 14.5 L2.8 12 L9.5 9.5 Z" />
      <path d="M12 6.8 V17.2 M6.8 12 H17.2" opacity="0.55" />
    </Svg>
  );
}

/* ---- khanates · the khagan tamga crown ---- */
export function GlyphTamga(p: GlyphProps) {
  return (
    <Svg {...p}>
      <path d="M4.5 18.5 L4.5 9 L8.6 12.4 L12 5.6 L15.4 12.4 L19.5 9 L19.5 18.5 Z" />
      <path d="M4.5 18.5 H19.5" />
      <circle cx="12" cy="14.6" r="1" fill="currentColor" stroke="none" opacity="0.8" />
    </Svg>
  );
}

/* ---- soviet · star rising over the rails ---- */
export function GlyphSovietStar(p: GlyphProps) {
  return (
    <Svg {...p}>
      <path d="M12 3.6 L13.5 8.2 L18.3 8.2 L14.4 11 L15.9 15.6 L12 12.8 L8.1 15.6 L9.6 11 L5.7 8.2 L10.5 8.2 Z" />
      <path d="M4 19.4 H20" />
      <path d="M4 19.4 L8.6 16.9 M20 19.4 L15.4 16.9" opacity="0.6" />
    </Svg>
  );
}

/* ---- modern · skyline of the republic ---- */
export function GlyphSkyline(p: GlyphProps) {
  return (
    <Svg {...p}>
      <path d="M4 20 H20" />
      <path d="M6.2 20 V12.4 H10 V20" />
      <path d="M10.6 20 V6.8 H14.6 V20" />
      <path d="M16.4 20 V10.2 H19 V20" opacity="0.75" />
      <path d="M12.6 6.8 V4.6" />
    </Svg>
  );
}

/* ---- caravan camel (single-file, manuscript margin style) ---- */
export function GlyphCamel(p: GlyphProps) {
  return (
    <Svg {...p}>
      <path d="M4.2 18.6 L5 12.6 C5.2 10.6 6.6 9.8 8.6 10.1 L13.4 10.4 C14.6 10.5 15.6 9.9 15.9 8.7 L16.3 7.2" />
      <path d="M16.3 7.2 L15.4 5.4 L16.8 5.8 L17.9 5.2" />
      <path d="M17.9 5.2 C18.9 5.6 19.3 6.6 19 7.7 L18.4 9.9 L18.8 18.6" />
      <path d="M7 13.4 L6.8 18.6 M11.5 13.6 L11.5 18.6 M15.4 13 L15.8 18.6" opacity="0.85" />
    </Svg>
  );
}

/* ---- observatory (Ulugh Beg) ---- */
export function GlyphObservatory(p: GlyphProps) {
  return (
    <Svg {...p}>
      <path d="M4.5 19.5 H19.5" />
      <path d="M6.5 19.5 V13 C6.5 9.4 9 7 12 7 C15 7 17.5 9.4 17.5 13 V19.5" />
      <path d="M10.8 7.3 L13.2 19.5" strokeWidth={1.1} opacity="0.7" />
      <path d="M16.8 3.4 L17.4 5 L19 5.6 L17.4 6.2 L16.8 7.8 L16.2 6.2 L14.6 5.6 L16.2 5 Z" />
    </Svg>
  );
}

/* ---- fortress walls ---- */
export function GlyphFortress(p: GlyphProps) {
  return (
    <Svg {...p}>
      <path d="M4.5 19.5 V9 H8 V6.5 H10.4 V9 H13.6 V6.5 H16 V9 H19.5 V19.5" />
      <path d="M4.5 19.5 H19.5" />
      <path d="M10.4 19.5 V15 C10.4 13.7 11.1 13 12 13 C12.9 13 13.6 13.7 13.6 15 V19.5" />
    </Svg>
  );
}

/* ---- coin of the Silk Road (square-holed) ---- */
export function GlyphCoin(p: GlyphProps) {
  return (
    <Svg {...p}>
      <circle cx="12" cy="12" r="8.4" />
      <rect x="9.6" y="9.6" width="4.8" height="4.8" />
      <path d="M12 3.6 V5.6 M12 18.4 V20.4 M3.6 12 H5.6 M18.4 12 H20.4" opacity="0.6" />
    </Svg>
  );
}

/* ---- amphora ---- */
export function GlyphPottery(p: GlyphProps) {
  return (
    <Svg {...p}>
      <path d="M10 4.5 H14" />
      <path d="M10.4 4.5 C10.4 6.4 8.4 7.4 8.4 11 C8.4 14.6 10 16 10 19.5 H14 C14 16 15.6 14.6 15.6 11 C15.6 7.4 13.6 6.4 13.6 4.5" />
      <path d="M9.4 20.5 H14.6" opacity="0.7" />
      <path d="M8.6 11.6 H15.4" opacity="0.5" />
    </Svg>
  );
}

/* ---- scroll ---- */
export function GlyphScroll(p: GlyphProps) {
  return (
    <Svg {...p}>
      <path d="M7.5 5.5 H18.5 V17 A2.5 2.5 0 0 1 16 19.5 H6" />
      <path d="M7.5 5.5 A2 2 0 1 0 7.5 9.5 H10" />
      <path d="M6 19.5 A2 2 0 0 1 6 15.5 H18.5" />
      <path d="M10.5 9 H15.5 M10.5 12 H15.5" opacity="0.6" />
    </Svg>
  );
}

/* ---- era glyph registry — replaces every emoji across the app ---- */
export const ERA_GLYPH: Record<EraId, (p: GlyphProps) => React.ReactElement> = {
  ancient: GlyphFireAltar,
  hellenistic: GlyphSwords,
  islamic: GlyphDomeCrescent,
  timurid: GlyphStar8,
  khanates: GlyphTamga,
  soviet: GlyphSovietStar,
  modern: GlyphSkyline,
};

export function EraGlyph({ eraId, ...rest }: GlyphProps & { eraId: EraId }) {
  const G = ERA_GLYPH[eraId] ?? GlyphStar8;
  return <G {...rest} />;
}
