'use client';

import { useEffect, useRef } from 'react';
import { X, ChevronLeft, ChevronRight, Volume2, Square, Loader2, Landmark as LandmarkIcon } from 'lucide-react';
import { ERA_MAP, type EraId } from '@/data/eras';
import type { City } from '@/data/cities';
import { useTuranLang } from './useTuranLang';
import { CityImage } from './CityImage';
import { EraGlyph } from './glyphs';
import { useNarration } from './useNarration';
import { audio } from '@/lib/audio-engine';

const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];

interface LandmarkPlaqueProps {
  city: City;
  eraId: EraId;
  index: number;
  count: number;
  name: string;
  detail: string;
  onClose: () => void;
  onNavigate: (index: number) => void;
}

/**
 * Full-screen museum plaque for a single landmark: archive-stamped artwork
 * header, serif title, ink-fade description and its own narration channel.
 */
export function LandmarkPlaque({ city, eraId, index, count, name, detail, onClose, onNavigate }: LandmarkPlaqueProps) {
  const { t, eraLabel, cityName } = useTuranLang();
  const era = ERA_MAP[eraId];

  const narration = useNarration(() => `${name}. ${detail}`);

  // touch swipe → prev/next landmark (threshold 56px, horizontal intent)
  const touchStart = useRef<{ x: number; y: number } | null>(null);
  const onTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    touchStart.current = { x: touch.clientX, y: touch.clientY };
  };
  const onTouchEnd = (e: React.TouchEvent) => {
    const start = touchStart.current;
    touchStart.current = null;
    if (!start) return;
    const touch = e.changedTouches[0];
    const dx = touch.clientX - start.x;
    const dy = touch.clientY - start.y;
    if (Math.abs(dx) < 56 || Math.abs(dx) < Math.abs(dy) * 1.4) return;
    const rtl = typeof document !== 'undefined' && document.documentElement.dir === 'rtl';
    // LTR: swipe left → next; RTL: direction flips like the chevrons
    const nextWanted = rtl ? dx > 0 : dx < 0;
    if (nextWanted && index < count - 1) go(index + 1);
    else if (!nextWanted && index > 0) go(index - 1);
  };

  // stop narration when switching plaques or closing
  useEffect(() => {
    narration.stop();
    // narration.stop is a stable useCallback; only the plaque identity matters here
  }, [name, narration.stop]);

  // Escape closes the plaque; arrows move between landmarks
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onClose();
      } else if (e.key === 'ArrowLeft' && index > 0) {
        onNavigate(index - 1);
      } else if (e.key === 'ArrowRight' && index < count - 1) {
        onNavigate(index + 1);
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [index, count, onClose, onNavigate]);

  const go = (next: number) => {
    if (next < 0 || next >= count || next === index) return;
    audio.play('click');
    onNavigate(next);
  };

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center p-3 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-label={`${name} — ${t('landmark.plate')}`}
      data-landmark-plaque="open"
    >
      {/* backdrop */}
      <div
        className="absolute inset-0"
        style={{ background: 'rgba(5, 4, 12, 0.72)', backdropFilter: 'blur(6px)' }}
        onClick={onClose}
        aria-hidden="true"
      />

      <div className="plaque-shell slide-up-panel glass-strong ornate relative w-full max-w-2xl max-h-[100dvh] sm:max-h-[calc(100vh-3rem)] flex flex-col overflow-hidden"
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
      >
        {/* archive-stamped artwork header */}
        <div className="relative h-44 sm:h-56 shrink-0">
          <div className="absolute inset-0 plaque-art">
            <CityImage
              cityId={city.id}
              eraId={eraId}
              cityName={city.name}
              eraLabel={eraLabel(eraId)}
              className="w-full h-full"
            />
          </div>
          <div
            className="absolute inset-0"
            style={{ background: 'linear-gradient(to top, var(--t-panel-solid) 4%, rgba(8,6,18,0.18) 45%, rgba(8,6,18,0.38) 100%)' }}
            aria-hidden="true"
          />

          {/* archive stamp */}
          <div className="absolute top-3 left-4 flex items-center gap-2 plaque-stamp" aria-hidden="true">
            <LandmarkIcon size={13} />
            <span className="text-[9.5px] tracking-[0.3em] uppercase font-bold">{t('landmark.archive')}</span>
          </div>

          {/* roman numeral medallion */}
          <div className="absolute top-3 right-14 plaque-medal" aria-hidden="true">
            {ROMAN[index] ?? index + 1}
          </div>

          <button
            className="absolute top-3 right-3 w-9 h-9 rounded-full glass grid place-items-center hover:scale-105 transition-transform"
            onClick={() => {
              audio.play('click');
              onClose();
            }}
            aria-label={t('popup.close')}
          >
            <X size={18} />
          </button>

          <div className="absolute bottom-3 left-5 right-5">
            <span
              className="inline-block text-[10px] tracking-[0.22em] uppercase px-2.5 py-1 rounded-full mb-2"
              style={{ background: `${era.color}33`, border: `1px solid ${era.color}`, color: 'var(--t-text)' }}
            >
              <EraGlyph eraId={eraId} size={12} strokeWidth={1.9} /> {eraLabel(eraId)} · {cityName(city.name, city.names)}
            </span>
            <h2
              className="text-2xl sm:text-4xl font-bold text-heading tracking-wide plaque-title"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              {name}
            </h2>
          </div>
        </div>

        {/* body */}
        <div className="turan-scroll flex-1 px-5 sm:px-7 py-5">
          <div className="ornament text-[11px] tracking-[0.26em] uppercase mb-3.5" style={{ color: 'var(--t-accent)' }}>
            <LandmarkIcon size={13} aria-hidden="true" />
            {t('landmark.plate')} · {index + 1} {t('quiz.of')} {count}
          </div>
          <p className="leading-relaxed text-[0.95rem] ink-fade whitespace-pre-line">{detail}</p>

          <div className="flex items-center gap-2.5 mt-5">
            <button
              className={`btn-glass justify-center py-2.5 text-sm ${narration.state === 'playing' ? 'narr-active' : ''}`}
              onClick={() => void narration.toggle()}
              aria-label={t('popup.narrate')}
              style={
                narration.state !== 'idle'
                  ? { borderColor: 'var(--t-accent)', boxShadow: '0 0 16px var(--t-accent-glow)' }
                  : undefined
              }
            >
              {narration.state === 'loading' ? (
                <Loader2 size={16} className="animate-spin" aria-hidden="true" />
              ) : narration.state === 'playing' ? (
                <Square size={14} aria-hidden="true" />
              ) : (
                <Volume2 size={16} aria-hidden="true" />
              )}
              {narration.state === 'playing' && (
                <span className="narr-eq" aria-hidden="true">
                  <i /><i /><i />
                </span>
              )}
              <span className="text-xs">
                {narration.state === 'loading'
                  ? t('popup.narrateLoading')
                  : narration.state === 'playing'
                    ? t('popup.narrateStop')
                    : t('popup.narrate')}
              </span>
            </button>
            {narration.error && (
              <span className="text-xs" style={{ color: '#c96a6a' }}>{t('popup.narrateError')}</span>
            )}
          </div>

          {/* touch-device swipe hint (hidden on desktop via CSS) */}
          {count > 1 && (
            <div className="plaque-swipe-hint mt-3 text-[10px] tracking-[0.22em] uppercase text-subtle flex items-center justify-center gap-2" aria-hidden="true">
              <ChevronLeft size={12} className="flip-rtl" />
              {t('landmark.swipeHint')}
              <ChevronRight size={12} className="flip-rtl" />
            </div>
          )}
        </div>

        {/* prev / next footer */}
        <div className="shrink-0 px-5 sm:px-7 py-3.5 flex items-center justify-between gap-3" style={{ borderTop: '1px solid var(--t-glass-border)' }}>
          <button
            className="btn-glass py-2 px-3.5 text-xs"
            onClick={() => go(index - 1)}
            disabled={index === 0}
            aria-label={t('landmark.prev')}
          >
            <ChevronLeft size={15} className="flip-rtl" aria-hidden="true" />
            <span className="hidden sm:inline">{t('landmark.prev')}</span>
          </button>

          <div className="flex items-center gap-1.5" aria-hidden="true">
            {Array.from({ length: count }, (_, i) => (
              <button
                key={i}
                className={`plaque-dot ${i === index ? 'active' : ''}`}
                onClick={() => go(i)}
                tabIndex={-1}
              />
            ))}
          </div>

          <button
            className="btn-glass py-2 px-3.5 text-xs"
            onClick={() => go(index + 1)}
            disabled={index === count - 1}
            aria-label={t('landmark.next')}
          >
            <span className="hidden sm:inline">{t('landmark.next')}</span>
            <ChevronRight size={15} className="flip-rtl" aria-hidden="true" />
          </button>
        </div>
      </div>
    </div>
  );
}
