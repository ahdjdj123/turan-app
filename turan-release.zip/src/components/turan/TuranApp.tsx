'use client';

import { useCallback, useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Toaster } from 'sonner';
import { useTuranStore } from '@/lib/store';
import { useUIStore } from '@/lib/ui-store';
import { ERAS, type EraId } from '@/data/eras';
import { CITY_MAP } from '@/data/cities';
import { audio } from '@/lib/audio-engine';
import { watchOfflineMode } from '@/lib/offline';
import { MainMenu } from './MainMenu';
import { MapView } from './MapView';
import { RandomDiscovery } from './RandomDiscovery';
import { Leisure } from './Leisure';
import { Settings } from './Settings';
import { Journal } from './Journal';
import { ExploreFeed } from './ExploreFeed';
import { BottomNav } from './BottomNav';
import { ShortcutsHelp } from './ShortcutsHelp';
import { OpeningCurtain } from './OpeningCurtain';
import { LANGUAGES } from '@/data/translations';

export function TuranApp() {
  const screen = useTuranStore((s) => s.screen);
  const hydrated = useTuranStore((s) => s.hydrated);
  const settings = useTuranStore((s) => s.settings);

  /* opening ceremony: once per browser session (reload within it is instant) */
  const [ceremonyDone, setCeremonyDone] = useState(true);
  useEffect(() => {
    const id = window.setTimeout(() => {
      try {
        if (!sessionStorage.getItem('turan-opened')) {
          sessionStorage.setItem('turan-opened', '1');
          setCeremonyDone(false);
        }
      } catch {
        setCeremonyDone(false);
      }
    }, 0);
    return () => window.clearTimeout(id);
  }, []);
  const finishCeremony = useCallback(() => setCeremonyDone(true), []);

  /* apply theme / accent / font / animation / glass to <html> */
  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-turan-theme', settings.theme);
    root.setAttribute('data-turan-accent', settings.accent);
    root.setAttribute('data-turan-fs', settings.fontSize);
    root.setAttribute('data-turan-anim', settings.animSpeed);
    root.setAttribute('data-turan-glass', settings.glass ? 'on' : 'off');
  }, [settings.theme, settings.accent, settings.fontSize, settings.animSpeed, settings.glass]);

  /* apply language + direction */
  useEffect(() => {
    const root = document.documentElement;
    const info = LANGUAGES.find((l) => l.id === settings.language);
    root.setAttribute('lang', settings.language);
    root.setAttribute('dir', info?.dir ?? 'ltr');
  }, [settings.language]);

  /* sync audio engine */
  useEffect(() => {
    audio.setVolume(settings.masterVolume);
    audio.setSfx(settings.sfx);
    audio.setMusic(settings.music);
  }, [settings.masterVolume, settings.sfx, settings.music]);

  /* unlock audio on first user gesture */
  useEffect(() => {
    const unlock = () => audio.unlock();
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, []);

  /* offline museum mode: service-worker artwork precache follows the setting */
  useEffect(() => watchOfflineMode(), []);

  /* performance: pause all CSS animations + transitions when the tab is hidden */
  useEffect(() => {
    const onChange = () => {
      document.documentElement.setAttribute('data-turan-hidden', document.hidden ? 'true' : 'false');
    };
    document.addEventListener('visibilitychange', onChange);
    return () => document.removeEventListener('visibilitychange', onChange);
  }, []);

  /* deep link: /?city=samarkand&era=timurid — jump to the map with that popup open */
  useEffect(() => {
    if (!hydrated) return;
    const params = new URLSearchParams(window.location.search);
    const cityId = params.get('city');
    const eraId = params.get('era');
    if (cityId && eraId) {
      const store = useTuranStore.getState();
      if (CITY_MAP[cityId]?.eras[eraId as EraId]) {
        store.openCity(cityId, eraId as EraId, false);
        store.setScreen('map');
      }
      // consume the query so reloads land on the visitor's actual screen
      window.history.replaceState(null, '', window.location.pathname);
    }
  }, [hydrated]);

  /* ---------------- global keyboard shortcuts ---------------- */
  const screenForKeys = useTuranStore((s) => s.screen);
  const setScreenKeys = useTuranStore((s) => s.setScreen);
  const jumpToEraKeys = useTuranStore((s) => s.jumpToEra);

  useEffect(() => {
    const navKeys: Record<string, 'menu' | 'map' | 'explore' | 'random' | 'leisure' | 'journal' | 'settings'> = {
      m: 'menu',
      b: 'map',
      e: 'explore',
      r: 'random',
      l: 'leisure',
      j: 'journal',
      s: 'settings',
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const el = e.target as HTMLElement | null;
      if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable)) return;

      // ? opens/closes the shortcuts plaque
      if (e.key === '?' || (e.shiftKey && e.key === '/')) {
        e.preventDefault();
        audio.play('click');
        useUIStore.getState().toggleHelp();
        return;
      }

      const helpOpen = useUIStore.getState().helpOpen;
      if (helpOpen) {
        // the plaque handles its own Escape; swallow navigation while open
        return;
      }

      if (e.key === 'Escape') {
        if (useUIStore.getState().legendOpen) {
          useUIStore.getState().setLegendOpen(false);
          return;
        }
        // a city popup is open: CityPopup closes itself — do NOT also navigate away
        if (typeof document !== 'undefined' && document.querySelector('[data-city-popup]')) return;
        if (screenForKeys !== 'menu') {
          audio.play('click');
          setScreenKeys('menu');
        }
        return;
      }

      const lower = e.key.toLowerCase();
      if (lower === 'm' || lower === 'b' || lower in navKeys) {
        const target = navKeys[lower];
        if (target && screenForKeys !== target) {
          audio.play('click');
          setScreenKeys(target);
        }
        return;
      }

      // digits 1-7 jump to eras while exploring the map
      if (screenForKeys === 'map') {
        const n = parseInt(e.key, 10);
        if (n >= 1 && n <= ERAS.length) {
          audio.play('click');
          jumpToEraKeys(ERAS[n - 1].id);
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [screenForKeys, setScreenKeys, jumpToEraKeys]);

  /* ---------------- swipe between tabs (thumb navigation) ---------------- */
  const swipeScreenRef = useTuranStore((s) => s.screen);
  const setScreenSwipe = useTuranStore((s) => s.setScreen);

  useEffect(() => {
    if (swipeScreenRef === 'map' || swipeScreenRef === 'menu' || swipeScreenRef === 'random') return;
    let x0 = 0;
    let y0 = 0;
    const onStart = (e: TouchEvent) => {
      x0 = e.touches[0].clientX;
      y0 = e.touches[0].clientY;
    };
    const onEnd = (e: TouchEvent) => {
      const dx = e.changedTouches[0].clientX - x0;
      const dy = e.changedTouches[0].clientY - y0;
      if (Math.abs(dx) < 90 || Math.abs(dx) < 2 * Math.abs(dy)) return;
      const el = e.target as HTMLElement | null;
      if (el && el.closest('.stories-row, .feed-pills, .gallery-strip, .nearby-strip, input, textarea, [data-city-popup]')) return;
      const order = ['explore', 'journal', 'leisure', 'settings'] as const;
      const idx = order.indexOf(swipeScreenRef as typeof order[number]);
      if (idx === -1) return;
      const rtl = document.documentElement.dir === 'rtl';
      const dir = dx < 0 !== rtl ? 1 : -1;
      const next = order[idx + dir];
      if (next) {
        audio.play('click');
        setScreenSwipe(next);
      }
    };
    window.addEventListener('touchstart', onStart, { passive: true });
    window.addEventListener('touchend', onEnd, { passive: true });
    return () => {
      window.removeEventListener('touchstart', onStart);
      window.removeEventListener('touchend', onEnd);
    };
  }, [swipeScreenRef, setScreenSwipe]);

  const screenEl =
    screen === 'menu' ? (
      <MainMenu />
    ) : screen === 'map' ? (
      <MapView />
    ) : screen === 'explore' ? (
      <ExploreFeed />
    ) : screen === 'random' ? (
      <RandomDiscovery />
    ) : screen === 'leisure' ? (
      <Leisure />
    ) : screen === 'journal' ? (
      <Journal />
    ) : (
      <Settings />
    );

  return (
    <div className="turan-root">
      <AnimatePresence mode="wait">
        <motion.div
          key={screen}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.45, ease: 'easeOut' }}
          style={{ minHeight: '100vh' }}
        >
          {screenEl}
        </motion.div>
      </AnimatePresence>

      {/* subtle museum grain */}
      {settings.theme !== 'parchment' && <div className="grain-overlay" aria-hidden="true" />}

      <Toaster
        position="bottom-center"
        offset={screen === 'menu' ? 90 : 96}
        toastOptions={{
          style: {
            background: 'var(--t-panel-solid)',
            border: '1px solid var(--t-glass-border-strong)',
            color: 'var(--t-text)',
            fontFamily: 'inherit',
          },
        }}
      />

      {/* mobile app navigation (hidden on the immersive menu + ≥768px) */}
      {screen !== 'menu' && <BottomNav />}

      {/* brief first-paint guard while localStorage rehydrates */}
      <style>{`html{background:#171321}`}</style>
      <ShortcutsHelp />
      {!ceremonyDone && <OpeningCurtain onDone={finishCeremony} />}
    </div>
  );
}
