'use client';

import { useCallback, useMemo, useState } from 'react';
import { Flame, RotateCcw, Sparkles, Trophy, BookOpenCheck, Globe2, Hourglass, GraduationCap } from 'lucide-react';
import { toast } from 'sonner';
import { CITIES, type City, type CityEraContent } from '@/data/cities';
import { ERAS, ERA_MAP, type EraId } from '@/data/eras';
import { useTuranStore, selectCurrentEra } from '@/lib/store';
import type { QuizDifficulty } from '@/lib/turan-types';
import { useTuranLang } from './useTuranLang';
import { EraGlyph, GlyphCamel, GlyphCoin, GlyphCompassRose, GlyphSwords } from './glyphs';
import { audio } from '@/lib/audio-engine';

const QUESTIONS_PER_ROUND = 8;

/** difficulty tuning: answer choices, base points, streak-bonus cap (score ×mult shown to player) */
const DIFFICULTY: Record<QuizDifficulty, { options: number; base: number; bonusMax: number; mult: number }> = {
  easy: { options: 3, base: 8, bonusMax: 4, mult: 0.8 },
  normal: { options: 4, base: 10, bonusMax: 6, mult: 1 },
  hard: { options: 5, base: 12, bonusMax: 8, mult: 1.2 },
};

type QKind = 'whichCity' | 'whichEra' | 'whichLandmark';

interface QuizQuestion {
  kind: QKind;
  /** the era the source content belongs to (drives per-era mastery) */
  eraId: EraId;
  /** story / fact / landmark name shown as the prompt */
  prompt: string;
  options: string[];
  correct: string;
  /** shown after answering */
  explanation: string;
}

interface Miss {
  label: string;
  /** the full original question so a practice round can re-ask it verbatim */
  question: QuizQuestion;
}

function pick<T>(arr: T[], n: number): T[] {
  const copy = [...arr];
  const out: T[] = [];
  while (out.length < n && copy.length) {
    out.push(copy.splice(Math.floor(Math.random() * copy.length), 1)[0]);
  }
  return out;
}

function buildQuestion(
  allContent: { city: City; eraId: EraId; content: CityEraContent }[],
  optionCount: number,
  eraScoped: boolean
): QuizQuestion {
  // within an era scope, "which era" questions would be trivial — drop them
  const kinds: QKind[] = eraScoped ? ['whichCity', 'whichLandmark'] : ['whichCity', 'whichEra', 'whichLandmark'];
  const kind = kinds[Math.floor(Math.random() * kinds.length)];
  const roll = allContent[Math.floor(Math.random() * allContent.length)];
  const scopeCityIds = new Set(allContent.map((c) => c.city.id));
  const otherCities = CITIES.filter((c) => c.id !== roll.city.id);
  // prefer distractors from the same era scope, fall back to the full atlas
  const pickDistractors = (n: number) => {
    const inScope = otherCities.filter((c) => scopeCityIds.has(c.id)).map((c) => c.name);
    const out = pick(inScope, n);
    if (out.length < n) out.push(...pick(otherCities.filter((c) => !scopeCityIds.has(c.id)).map((c) => c.name), n - out.length));
    return out;
  };

  if (kind === 'whichEra') {
    const correctEra = ERA_MAP[roll.eraId];
    const distractors = pick(
      ERAS.filter((e) => e.id !== roll.eraId),
      optionCount - 1
    );
    const options = pick([...distractors.map((e) => e.id), roll.eraId], optionCount);
    return {
      kind: 'whichEra',
      eraId: roll.eraId,
      prompt: roll.content.fact,
      options: options.map((id) => ERA_MAP[id].label),
      correct: correctEra.label,
      explanation: `${roll.city.name} · ${roll.content.tagline}`,
    };
  }

  if (kind === 'whichLandmark' && roll.content.landmarks.length > 0) {
    const lm = roll.content.landmarks[Math.floor(Math.random() * roll.content.landmarks.length)];
    const options = [
      ...pickDistractors(optionCount - 1),
      roll.city.name,
    ].sort(() => Math.random() - 0.5);
    return {
      kind: 'whichLandmark',
      eraId: roll.eraId,
      prompt: lm.name,
      options,
      correct: roll.city.name,
      explanation: lm.detail,
    };
  }

  // whichCity
  const options = [
    ...pickDistractors(optionCount - 1),
    roll.city.name,
  ].sort(() => Math.random() - 0.5);
  return {
    kind: 'whichCity',
    eraId: roll.eraId,
    prompt:
      roll.content.description.length > 220
        ? `${roll.content.description.slice(0, 217)}…`
        : roll.content.description,
    options,
    correct: roll.city.name,
    explanation: `“${roll.content.tagline}”`,
  };
}

/** per-era correct/asked mastery bars — shown on the intro and the results screen */
function MasteryPanel({
  quizMastery,
  title,
  eraLabel,
  results,
}: {
  quizMastery: Partial<Record<EraId, { asked: number; correct: number }>>;
  title: string;
  eraLabel: (id: EraId) => string;
  results?: boolean;
}) {
  const totalAsked = ERAS.reduce((n, e) => n + (quizMastery[e.id]?.asked ?? 0), 0);
  if (totalAsked === 0) return null;
  return (
    <div
      className={`mastery-panel w-full max-w-sm ${results ? 'mastery-results' : 'mt-1'}`}
      role="group"
      aria-label={title}
    >
      <div className="text-[11px] tracking-[0.2em] uppercase font-semibold text-center mb-2" style={{ color: 'var(--t-accent)' }}>
        {title}
      </div>
      <div className="flex flex-col gap-1.5 turan-scroll max-h-52 pe-1">
        {ERAS.map((era, i) => {
          const m = quizMastery[era.id];
          if (!m || m.asked === 0) return null;
          const pct = Math.round((m.correct / m.asked) * 100);
          return (
            <div
              key={era.id}
              className="mastery-row"
              style={{ '--m-color': era.color, animationDelay: `${i * 50}ms` } as React.CSSProperties}
              title={`${eraLabel(era.id)} — ${m.correct}/${m.asked}`}
            >
              <span className="mastery-icon" aria-hidden="true"><EraGlyph eraId={era.id} size={15} strokeWidth={1.8} /></span>
              <span className="mastery-label">{eraLabel(era.id)}</span>
              <span className="mastery-bar" aria-hidden="true">
                <span className="mastery-fill" style={{ width: `${pct}%` }} />
              </span>
              <span className="mastery-count tabular-nums" style={{ color: m.correct / m.asked >= 0.7 ? era.color : undefined }}>
                {m.correct}/{m.asked}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function EraTrial() {
  const { t, eraLabel } = useTuranLang();
  const recordQuizScore = useTuranStore((s) => s.recordQuizScore);
  const recordQuizAnswer = useTuranStore((s) => s.recordQuizAnswer);
  const quizBest = useTuranStore((s) => s.quizBest);
  const quizMastery = useTuranStore((s) => s.quizMastery);
  const quizDifficulty = useTuranStore((s) => s.quizDifficulty);
  const setQuizDifficulty = useTuranStore((s) => s.setQuizDifficulty);
  const currentEra = useTuranStore(selectCurrentEra);

  const allContent = useMemo(
    () =>
      CITIES.flatMap((city) =>
        (Object.keys(city.eras) as EraId[]).map((eraId) => ({
          city,
          eraId,
          content: city.eras[eraId]!,
        }))
      ),
    []
  );

  const [phase, setPhase] = useState<'intro' | 'playing' | 'done'>('intro');
  const [eraScope, setEraScope] = useState<'all' | 'era'>('all');
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [misses, setMisses] = useState<Miss[]>([]);
  const [practice, setPractice] = useState(false);
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);

  const start = useCallback(() => {
    const cfg = DIFFICULTY[useTuranStore.getState().quizDifficulty];
    const scoped = eraScope === 'era'
      ? allContent.filter((c) => c.eraId === currentEra.id)
      : allContent;
    const pool = scoped.length >= 4 ? scoped : allContent; // tiny eras fall back to the full atlas
    const qs = Array.from({ length: QUESTIONS_PER_ROUND }, () => buildQuestion(pool, cfg.options, eraScope === 'era'));
    setQuestions(qs);
    setMisses([]);
    setPractice(false);
    setIndex(0);
    setPicked(null);
    setScore(0);
    setStreak(0);
    setPhase('playing');
    audio.play('click');
  }, [allContent, currentEra.id, eraScope]);

  /** re-ask only the questions missed in the finished round (best score untouched) */
  const startPractice = useCallback(() => {
    if (misses.length === 0) return;
    setQuestions(pick(
      misses.map((m) => m.question),
      misses.length
    ));
    setMisses([]);
    setPractice(true);
    setIndex(0);
    setPicked(null);
    setScore(0);
    setStreak(0);
    setPhase('playing');
    audio.play('click');
  }, [misses]);

  const question = questions[index];
  const isCorrect = picked !== null && picked === question?.correct;

  const answer = useCallback(
    (option: string) => {
      if (picked !== null) return;
      setPicked(option);
      const cfg = DIFFICULTY[useTuranStore.getState().quizDifficulty];
      if (option === question.correct) {
        const newStreak = streak + 1;
        const gained = cfg.base + Math.min(cfg.bonusMax, (newStreak - 1) * 2);
        setScore((s) => s + gained);
        setStreak(newStreak);
        recordQuizAnswer(question.eraId, true);
        audio.play('discover');
      } else {
        setStreak(0);
        recordQuizAnswer(question.eraId, false);
        setMisses((m) => [
          ...m,
          {
            label:
              question.kind === 'whichEra'
                ? t('quiz.qWhichEra')
                : question.kind === 'whichLandmark'
                  ? t('quiz.qWhichLandmark')
                  : t('quiz.qWhichCity'),
            question,
          },
        ]);
        audio.play('era');
      }
    },
    [picked, question, streak, t, recordQuizAnswer]
  );

  const next = useCallback(() => {
    if (index + 1 >= questions.length) {
      setPhase('done');
      // record the round score directly from state — NOT inside a setState updater.
      // practice rounds re-ask known questions, so they never touch the best score
      if (!practice) recordQuizScore(score);
      audio.play('discover');
      return;
    }
    setIndex((i) => i + 1);
    setPicked(null);
    audio.play('click');
  }, [index, questions.length, recordQuizScore, score, practice]);

  const rank =
    score >= 80 ? t('quiz.rank4') : score >= 60 ? t('quiz.rank3') : score >= 35 ? t('quiz.rank2') : t('quiz.rank1');

  /* ---------------- intro ---------------- */
  if (phase === 'intro') {
    const cfg = DIFFICULTY[quizDifficulty];
    return (
      <div className="flex flex-col items-center gap-4 text-center">
        <div aria-hidden="true" style={{ color: 'var(--t-accent)' }}><GlyphCompassRose size={54} strokeWidth={1.2} /></div>
        <h3 className="text-2xl font-bold gold-glow-text tracking-[0.14em] uppercase" style={{ fontFamily: 'var(--font-display)' }}>
          {t('quiz.title')}
        </h3>
        <p className="text-subtle text-sm max-w-sm">{t('quiz.tagline')}</p>
        {quizBest > 0 && (
          <p className="text-xs text-subtle flex items-center gap-1.5">
            <Trophy size={13} style={{ color: 'var(--t-accent)' }} aria-hidden="true" />
            {t('quiz.best')}: <strong style={{ color: 'var(--t-accent)' }}>{quizBest}</strong>
          </p>
        )}

        {/* difficulty selector */}
        <div className="flex flex-col items-center gap-2 mt-1 w-full max-w-xs">
          <div className="text-[11px] tracking-[0.2em] uppercase font-semibold" style={{ color: 'var(--t-accent)' }}>
            {t('quiz.difficulty')}
          </div>
          <div className="seg-group w-full justify-center">
            {(['easy', 'normal', 'hard'] as QuizDifficulty[]).map((d) => (
              <button
                key={d}
                className={`seg-option ${quizDifficulty === d ? 'active' : ''}`}
                onClick={() => {
                  setQuizDifficulty(d);
                  audio.play('click');
                }}
              >
                {d === 'easy' ? t('quiz.diffEasy') : d === 'normal' ? t('quiz.diffNormal') : t('quiz.diffHard')}
              </button>
            ))}
          </div>
          <p className="text-[11px] text-subtle difficulty-note">
            {cfg.options} × · {t('quiz.mult')} ×{cfg.mult}
          </p>
        </div>

        {/* era scope: all eras or the timeline-selected era */}
        <div className="flex flex-col items-center gap-2 w-full max-w-xs">
          <div className="text-[11px] tracking-[0.2em] uppercase font-semibold" style={{ color: 'var(--t-accent)' }}>
            {t('quiz.eraScope')}
          </div>
          <div className="seg-group w-full justify-center">
            <button
              className={`seg-option ${eraScope === 'all' ? 'active' : ''}`}
              onClick={() => {
                setEraScope('all');
                audio.play('click');
              }}
            >
              <Globe2 size={13} aria-hidden="true" className="inline -mt-0.5 me-1" />
              {t('quiz.eraAll')}
            </button>
            <button
              className={`seg-option ${eraScope === 'era' ? 'active' : ''}`}
              style={
                eraScope === 'era'
                  ? { borderColor: currentEra.color, boxShadow: `0 0 12px ${currentEra.color}55` }
                  : undefined
              }
              onClick={() => {
                setEraScope('era');
                audio.play('click');
              }}
            >
              <Hourglass size={13} aria-hidden="true" className="inline -mt-0.5 me-1" />
              {t('quiz.eraThis')} · {eraLabel(currentEra.id)}
            </button>
          </div>
          {eraScope === 'era' && <p className="text-[11px] text-subtle difficulty-note">{t('quiz.eraHint')}</p>}
        </div>

        {/* era mastery: per-era correct/asked bars (only once there is history) */}
        <MasteryPanel quizMastery={quizMastery} title={t('quiz.mastery')} eraLabel={eraLabel} />

        <button className="btn-glass btn-accent text-base mt-2" onClick={start}>
          <Sparkles size={18} aria-hidden="true" />
          {t('quiz.play')}
        </button>
      </div>
    );
  }

  /* ---------------- results ---------------- */
  if (phase === 'done') {
    return (
      <div className="slide-up-panel flex flex-col items-center gap-4 text-center w-full">
        <div className="text-6xl" aria-hidden="true">{score >= 60 ? <GlyphCoin size={54} strokeWidth={1.2} /> : score >= 35 ? <GlyphSwords size={54} strokeWidth={1.2} /> : <GlyphCamel size={54} strokeWidth={1.2} />}</div>
        <h3 className="text-xl font-bold text-heading tracking-wider uppercase">{t('quiz.result')}</h3>
        <div className="text-5xl font-bold gold-glow-text tabular-nums" style={{ fontFamily: 'var(--font-display)' }}>
          {score}
        </div>
        <p className="text-lg font-semibold" style={{ color: 'var(--t-accent)' }}>{rank}</p>
        {score >= quizBest && score > 0 && (
          <p className="text-xs text-subtle flex items-center gap-1.5">
            <Trophy size={13} style={{ color: 'var(--t-accent)' }} aria-hidden="true" /> {t('quiz.best')}: {quizBest}
          </p>
        )}

        {/* actions: replay · practice mistakes */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 mt-2">
          <button className="btn-glass btn-accent text-sm" onClick={start}>
            <RotateCcw size={16} aria-hidden="true" />
            {t('quiz.again')}
          </button>
          {misses.length > 0 && (
            <button className="btn-glass text-sm practice-btn" onClick={startPractice}>
              <GraduationCap size={16} aria-hidden="true" />
              {t('quiz.practice')}
              <span className="filter-count">{misses.length}</span>
            </button>
          )}
        </div>
        {practice && (
          <p className="practice-note text-[11px] text-subtle flex items-center gap-1.5">
            <GraduationCap size={12} style={{ color: 'var(--t-accent)' }} aria-hidden="true" />
            {t('quiz.practiceNote')}
          </p>
        )}

        {/* updated era mastery after this round */}
        <MasteryPanel quizMastery={quizMastery} title={t('quiz.mastery')} eraLabel={eraLabel} results />

        {/* mistakes review */}
        <div className="quiz-review w-full text-start mt-3">
          <div className="ornament text-[11px] tracking-[0.24em] uppercase mb-3" style={{ color: 'var(--t-accent)' }}>
            <BookOpenCheck size={14} aria-hidden="true" />
            {misses.length === 0 && practice ? t('quiz.reviewPerfect') : t('quiz.review')}
          </div>
          {misses.length === 0 ? (
            <p className="text-sm text-subtle text-center py-2">{t('quiz.reviewPerfect')}</p>
          ) : (
            <ol className="flex flex-col gap-3 max-h-64 turan-scroll pe-1">
              {misses.map((m, i) => (
                <li key={i} className="review-item">
                  <div className="text-[10px] tracking-[0.18em] uppercase mb-1" style={{ color: 'var(--t-accent)' }}>
                    {m.label}
                  </div>
                  <p className="text-sm leading-snug mb-1.5">{m.question.prompt}</p>
                  <p className="text-xs mb-1">
                    <span className="text-subtle">{t('quiz.answer')}: </span>
                    <strong style={{ color: '#2A9D8F' }}>✓ {m.question.correct}</strong>
                  </p>
                  <p className="text-xs text-subtle leading-relaxed">{m.question.explanation}</p>
                </li>
              ))}
            </ol>
          )}
        </div>
      </div>
    );
  }

  /* ---------------- playing ---------------- */
  const questionLabel =
    question.kind === 'whichEra'
      ? t('quiz.qWhichEra')
      : question.kind === 'whichLandmark'
        ? t('quiz.qWhichLandmark')
        : t('quiz.qWhichCity');

  return (
    <div className="w-full flex flex-col gap-4">
      {/* scoreboard */}
      <div className="flex items-center justify-between text-sm">
        <span className="text-subtle flex items-center gap-2">
          {t('quiz.question')} <strong style={{ color: 'var(--t-accent)' }}>{index + 1}</strong> {t('quiz.of')}
          {' '}
          {questions.length}
          {practice && (
            <span className="practice-chip">
              <GraduationCap size={11} aria-hidden="true" />
              {t('quiz.practiceBadge')}
            </span>
          )}
        </span>
        <span className="flex items-center gap-3">
          {streak > 1 && (
            <span
              className={`flex items-center gap-1 text-xs ${streak >= 3 ? 'streak-fire' : ''}`}
              style={{ color: '#e08a3c' }}
              aria-label={String(streak)}
            >
              <Flame size={14} aria-hidden="true" />
              {streak}
            </span>
          )}
          <strong className="tabular-nums gold-glow-text text-lg">{score}</strong>
        </span>
      </div>
      <div className="discovery-track">
        <div className="discovery-fill" style={{ width: `${((index + (picked ? 1 : 0)) / questions.length) * 100}%` }} />
      </div>

      {/* prompt */}
      <div className="landmark-item p-4">
        <p className="text-[11px] tracking-[0.18em] uppercase mb-2" style={{ color: 'var(--t-accent)' }}>
          {questionLabel}
        </p>
        <p className="text-sm leading-relaxed">{question.prompt}</p>
      </div>

      {/* options */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {question.options.map((option) => {
          const revealed = picked !== null;
          const isThisCorrect = option === question.correct;
          const isPicked = option === picked;
          let style: React.CSSProperties = {};
          if (revealed && isThisCorrect) {
            style = { borderColor: '#2A9D8F', boxShadow: '0 0 16px rgba(42,157,143,0.35)' };
          } else if (revealed && isPicked && !isThisCorrect) {
            style = { borderColor: '#9E2A2B', boxShadow: '0 0 16px rgba(158,42,43,0.35)' };
          }
          return (
            <button
              key={option}
              className="btn-glass justify-center py-3 text-sm"
              style={style}
              onClick={() => answer(option)}
              disabled={revealed}
            >
              {revealed && isThisCorrect ? '✓ ' : revealed && isPicked ? '✗ ' : ''}
              {option}
            </button>
          );
        })}
      </div>

      {/* feedback */}
      {picked !== null && (
        <div className="ink-fade flex flex-col gap-2.5">
          <p className="text-sm font-semibold" style={{ color: isCorrect ? '#2A9D8F' : '#c96a6a' }}>
            {isCorrect ? t('quiz.correct') : `${t('quiz.wrong')} ${question.correct}`}
          </p>
          <p className="text-xs text-subtle leading-relaxed">{question.explanation}</p>
          <button className="btn-glass btn-accent justify-center py-2.5 text-sm self-end" onClick={next}>
            {index + 1 >= questions.length ? t('quiz.finish') : t('quiz.next')}
          </button>
        </div>
      )}
    </div>
  );
}
