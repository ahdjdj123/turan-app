'use client';

import { useCallback, useMemo } from 'react';
import { useTuranStore } from '@/lib/store';
import { TRANSLATIONS, type LangId } from '@/data/translations';
import type { EraId } from '@/data/eras';
import { ERA_MAP } from '@/data/eras';

/** Small hook exposing translated UI strings for the current language. */
export function useTuranLang() {
  const lang = useTuranStore((s) => s.settings.language);
  const t = useCallback(
    (key: keyof (typeof TRANSLATIONS)['en']) => TRANSLATIONS[lang][key],
    [lang]
  );
  const eraLabel = useCallback(
    (eraId: EraId) => TRANSLATIONS[lang][`era.${eraId}` as keyof (typeof TRANSLATIONS)['en']],
    [lang]
  );
  const eraDesc = useCallback(
    (eraId: EraId) =>
      TRANSLATIONS[lang][`era.${eraId}.desc` as keyof (typeof TRANSLATIONS)['en']],
    [lang]
  );
  const cityName = useCallback(
    (name: string, names: Record<string, string>) => {
      if (lang === 'en') return name;
      return names[lang as LangId] || name;
    },
    [lang]
  );
  return useMemo(() => ({ lang, t, eraLabel, eraDesc, cityName }), [lang, t, eraLabel, eraDesc, cityName]);
}

export { ERA_MAP };
