'use client';

import { X, Circle, CheckCircle2, Route, Waves } from 'lucide-react';
import { ERAS } from '@/data/eras';
import { useTuranStore } from '@/lib/store';
import { useUIStore } from '@/lib/ui-store';
import { useTuranLang } from './useTuranLang';
import { EraGlyph } from './glyphs';

export function MapLegend() {
  const open = useUIStore((s) => s.legendOpen);
  const setLegendOpen = useUIStore((s) => s.setLegendOpen);
  const jumpToEra = useTuranStore((s) => s.jumpToEra);
  const discovered = useTuranStore((s) => s.discovered);
  const { t, eraLabel } = useTuranLang();

  if (!open) return null;

  return (
    <aside
      className="legend-panel glass-strong ornate fixed z-40 p-4 w-60 max-w-[calc(100vw-1.5rem)] max-h-[calc(100vh-13rem)] overflow-y-auto turan-scroll"
      role="region"
      aria-label={t('legend.title')}
    >
      <header className="flex items-center justify-between mb-2.5">
        <h2 className="text-[11px] tracking-[0.24em] uppercase font-semibold" style={{ color: 'var(--t-accent)' }}>
          {t('legend.title')}
        </h2>
        <button
          className="w-7 h-7 rounded-full glass grid place-items-center"
          onClick={() => setLegendOpen(false)}
          aria-label={t('popup.close')}
        >
          <X size={14} />
        </button>
      </header>

      <h3 className="text-[10px] tracking-[0.2em] uppercase text-subtle mb-1.5">{t('legend.eras')}</h3>
      <ul className="flex flex-col gap-1 mb-3">
        {ERAS.map((e) => (
          <li key={e.id}>
            <button
              className="legend-era-row"
              onClick={() => jumpToEra(e.id)}
              title={eraLabel(e.id)}
            >
              <span className="legend-dot" style={{ background: e.color, boxShadow: `0 0 8px ${e.color}` }} aria-hidden="true" />
              <span className="text-xs inline-flex items-center gap-1.5"><EraGlyph eraId={e.id} size={13} strokeWidth={1.8} /> {eraLabel(e.id)}</span>
            </button>
          </li>
        ))}
      </ul>

      <h3 className="text-[10px] tracking-[0.2em] uppercase text-subtle mb-1.5">{t('legend.markers')}</h3>
      <ul className="flex flex-col gap-1.5 mb-3">
        <li className="flex items-center gap-2">
          <Circle size={13} style={{ color: 'var(--t-accent)', fill: 'var(--t-accent)' }} aria-hidden="true" />
          <span className="text-xs text-subtle">{t('legend.unvisited')}</span>
        </li>
        <li className="flex items-center gap-2">
          <CheckCircle2 size={14} style={{ color: 'var(--t-accent)' }} aria-hidden="true" />
          <span className="text-xs text-subtle">{t('legend.visited')} ({discovered.length})</span>
        </li>
      </ul>

      <h3 className="text-[10px] tracking-[0.2em] uppercase text-subtle mb-1.5">{t('app.subtitle')}</h3>
      <ul className="flex flex-col gap-1.5">
        <li className="flex items-center gap-2">
          <span className="legend-route" aria-hidden="true" />
          <span className="text-xs text-subtle flex items-center gap-1"><Route size={12} aria-hidden="true" />{t('legend.route')}</span>
        </li>
        <li className="flex items-center gap-2">
          <Waves size={14} style={{ color: '#3f7fa6' }} aria-hidden="true" />
          <span className="text-xs text-subtle">{t('legend.water')}</span>
        </li>
        <li className="flex items-center gap-2">
          <span aria-hidden="true" className="text-[13px] leading-none" style={{ color: '#8a7a5a' }}>⛰︎</span>
          <span className="text-xs text-subtle">{t('legend.mountains')}</span>
        </li>
        <li className="flex items-center gap-2">
          <span className="legend-desert" aria-hidden="true" />
          <span className="text-xs text-subtle">{t('legend.desert')}</span>
        </li>
      </ul>
    </aside>
  );
}
