'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  X, Landmark as LandmarkIcon, Lightbulb, Bookmark, BookmarkCheck, Volume2, Square,
  Loader2, ChevronDown, Maximize2, Share2, ChevronLeft, ChevronRight, Users, ScrollText,
  BookOpen, Images, Library, Feather, CalendarClock, MapPin, Expand,
  Clock, Ticket, SunMedium, Hourglass, Wallet, Baby, ThumbsUp, Star,
  Navigation, UtensilsCrossed, Footprints,
} from 'lucide-react';
import { toast } from 'sonner';
import { CITIES, CITY_MAP, getMergedContent, type City, type GalleryItem } from '@/data/cities';
import { ERA_MAP, type EraId } from '@/data/eras';
import {
  TRAVEL, CATEGORY_MAP, SHOWCASE_ERA, HOME_CITY,
  weatherFor, distanceKm, etaCar, etaWalk, formatKm,
} from '@/data/travel';
import { useTuranStore } from '@/lib/store';
import { useTuranLang } from './useTuranLang';
import { LandmarkPlaque } from './LandmarkPlaque';
import { useNarration } from './useNarration';
import { EraGlyph } from './glyphs';
import { formatYear, formatFounded, type FoundedLabels } from '@/lib/turan-utils';
import { audio } from '@/lib/audio-engine';

/* ------------------------------------------------------------------ */
/*  image with graceful parchment fallback                             */
/* ------------------------------------------------------------------ */

export function MuseumImage({
  src, alt, className = '', eager = false,
}: { src: string; alt: string; className?: string; eager?: boolean }) {
  const [failed, setFailed] = useState(false);
  if (failed) {
    return (
      <div className={`placeholder-art flex flex-col items-center justify-center gap-2 w-full h-full ${className}`} aria-label={alt} role="img">
        <svg viewBox="0 0 100 60" className="w-24 h-14 opacity-70" fill="none" stroke="#8b6b2b" strokeWidth="1.2" aria-hidden="true">
          <path d="M8 52 L8 30 L16 30 L16 52" />
          <path d="M24 52 L24 26 Q31 12 38 26 L38 52" />
          <circle cx="31" cy="22" r="2.4" />
          <path d="M46 52 L46 32 L58 32 L58 52" />
          <path d="M54 52 L54 38 L66 38 L66 52" />
          <path d="M74 52 L74 24 L90 24 L90 52 Z" />
        </svg>
        <span className="text-[10px] tracking-[0.3em] uppercase text-subtle">Turan Archive</span>
      </div>
    );
  }
  return (
    <img
      src={src}
      alt={alt}
      className={className}
      loading={eager ? 'eager' : 'lazy'}
      decoding="async"
      onError={() => setFailed(true)}
      draggable={false}
    />
  );
}

/* ------------------------------------------------------------------ */
/*  small travel helpers                                               */
/* ------------------------------------------------------------------ */

function fmtCount(n: number): string {
  return n >= 1000 ? `${(n / 1000).toFixed(1).replace(/\.0$/, '')}k` : `${n}`;
}

function showcaseImage(cityId: string): string {
  const era = SHOWCASE_ERA[cityId] && CITY_MAP[cityId]?.eras[SHOWCASE_ERA[cityId]] ? SHOWCASE_ERA[cityId] : (Object.keys(CITY_MAP[cityId]?.eras ?? {}) as EraId[])[0];
  return `/images/cities/${cityId}_${era}.png`;
}

/* ------------------------------------------------------------------ */
/*  immersive full-screen lightbox (swipe / arrows / captions)         */
/* ------------------------------------------------------------------ */

interface LightboxProps {
  items: { srcResolved: string; title: string; year?: string; caption: string }[];
  index: number;
  cityLabel: string;
  eraLabel: string;
  onClose: () => void;
  onIndex: (i: number) => void;
}

export function Lightbox({ items, index, cityLabel, eraLabel, onClose, onIndex }: LightboxProps) {
  const { t } = useTuranLang();
  const dragRef = useRef<{ x: number; dx: number } | null>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const item = items[index];

  /* the mobile bottom nav lives in a separate fixed root whose stacking
     context paints above this modal — hide it while the lightbox is open */
  useEffect(() => {
    document.body.classList.add('turan-lightbox-open');
    return () => document.body.classList.remove('turan-lightbox-open');
  }, []);

  const step = useCallback(
    (dir: 1 | -1) => {
      onIndex((index + dir + items.length) % items.length);
      audio.play('hover');
    },
    [index, items.length, onIndex]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.stopPropagation(); onClose(); }
      else if (e.key === 'ArrowRight') step(1);
      else if (e.key === 'ArrowLeft') step(-1);
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [onClose, step]);

  if (!item) return null;

  const onTouchStart = (e: React.TouchEvent) => {
    dragRef.current = { x: e.touches[0].clientX, dx: 0 };
  };
  const onTouchMove = (e: React.TouchEvent) => {
    if (!dragRef.current || !stageRef.current) return;
    dragRef.current.dx = e.touches[0].clientX - dragRef.current.x;
    const el = stageRef.current;
    el.style.transition = 'none';
    el.style.transform = `translateX(${dragRef.current.dx}px)`;
  };
  const onTouchEnd = () => {
    const el = stageRef.current;
    const d = dragRef.current;
    dragRef.current = null;
    if (!el || !d) return;
    el.style.transition = 'transform 0.28s ease-out';
    el.style.transform = 'translateX(0)';
    if (Math.abs(d.dx) > 56) step(d.dx < 0 ? 1 : -1);
  };

  return (
    <div className="turan-lightbox" role="dialog" aria-modal="true" aria-label={`${item.title} — ${cityLabel}`}>
      <div className="absolute inset-0" style={{ background: 'rgba(6,5,12,0.92)' }} onClick={onClose} aria-hidden="true" />

      {/* image stage */}
      <div
        className="relative z-10 w-full h-full grid place-items-center p-4 pb-32 pt-14"
        onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      >
        <div
          ref={stageRef}
          className="lightbox-stage relative w-[min(92vw,900px)] h-[calc(100dvh-14rem)]"
          onTouchStart={onTouchStart}
          onTouchMove={onTouchMove}
          onTouchEnd={onTouchEnd}
        >
          <MuseumImage
            key={item.srcResolved}
            eager
            src={item.srcResolved}
            alt={`${item.title} — ${cityLabel}`}
            className="w-full h-full rounded-sm lightbox-img"
          />
        </div>
      </div>

      {/* caption plaque */}
      <div className="lightbox-caption" key={`${item.srcResolved}-cap`}>
        <div className="flex items-baseline gap-3 min-w-0">
          <span className="lightbox-counter tabular-nums">{index + 1}/{items.length}</span>
          <div className="min-w-0">
            <div className="font-bold tracking-wide truncate" style={{ fontFamily: 'var(--font-display)' }}>{item.title}</div>
            <div className="text-[10px] tracking-[0.2em] uppercase text-subtle">
              {cityLabel} · {eraLabel}{item.year ? ` · ${item.year}` : ''}
            </div>
          </div>
        </div>
        <p className="text-sm text-subtle mt-1.5 leading-relaxed line-clamp-2">{item.caption}</p>
      </div>

      {/* controls */}
      <button className="lightbox-nav lightbox-prev flip-rtl" onClick={() => step(-1)} aria-label={t('common.prev')}>
        <ChevronLeft size={26} />
      </button>
      <button className="lightbox-nav lightbox-next flip-rtl" onClick={() => step(1)} aria-label={t('common.next')}>
        <ChevronRight size={26} />
      </button>
      <button className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full grid place-items-center lightbox-close" onClick={onClose} aria-label={t('popup.close')}>
        <X size={20} />
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  hero carousel — swipeable plates over the city hero                */
/* ------------------------------------------------------------------ */

interface HeroCarouselProps {
  slides: { src: string; alt: string; title: string }[];
  eager?: boolean;
}

function HeroCarousel({ slides, eager }: HeroCarouselProps) {
  const [idx, setIdx] = useState(0);
  const drag = useRef<{ x: number; dx: number } | null>(null);
  const stripRef = useRef<HTMLDivElement>(null);

  const step = useCallback(
    (dir: 1 | -1) => {
      setIdx((i) => (i + dir + slides.length) % slides.length);
      audio.play('hover');
    },
    [slides.length]
  );

  const onTouchStart = (e: React.TouchEvent) => {
    drag.current = { x: e.touches[0].clientX, dx: 0 };
  };
  const onTouchMove = (e: React.TouchEvent) => {
    if (!drag.current || !stripRef.current) return;
    drag.current.dx = e.touches[0].clientX - drag.current.x;
    const el = stripRef.current;
    el.style.transition = 'none';
    el.style.transform = `translateX(calc(${-idx * 100}% + ${drag.current.dx}px))`;
  };
  const onTouchEnd = () => {
    const el = stripRef.current;
    const d = drag.current;
    drag.current = null;
    if (!el || !d) return;
    el.style.transition = 'transform 0.26s cubic-bezier(0.22, 1, 0.36, 1)';
    el.style.transform = `translateX(${-idx * 100}%)`;
    if (Math.abs(d.dx) > 48) step(d.dx < 0 ? 1 : -1);
  };

  return (
    <div
      className="hero-carousel"
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      <div ref={stripRef} className="hero-carousel-strip" style={{ transform: `translateX(${-idx * 100}%)` }}>
        {slides.map((s, i) => (
          <div className="hero-slide" key={s.src}>
            <MuseumImage
              eager={eager && i === 0}
              src={s.src}
              alt={s.alt}
              className="w-full h-full city-exp-hero-img"
            />
          </div>
        ))}
      </div>
      {slides.length > 1 && (
        <div className="hero-carousel-dots" role="tablist" aria-hidden="false">
          {slides.map((s, i) => (
            <button
              key={s.src}
              role="tab"
              aria-selected={i === idx}
              aria-label={s.title}
              className={`hero-dot ${i === idx ? 'active' : ''}`}
              onClick={(e) => { e.stopPropagation(); setIdx(i); audio.play('hover'); }}
            />
          ))}
        </div>
      )}
      {slides.length > 1 && (
        <span className="hero-carousel-counter tabular-nums">{idx + 1}/{slides.length}</span>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  CityExperience — travel card → EXPLORE → exhibition tabs           */
/* ------------------------------------------------------------------ */

type TabId = 'story' | 'visit' | 'reviews' | 'nearby' | 'landmarks' | 'people' | 'events' | 'facts' | 'gallery' | 'sources';

interface CityExperienceProps {
  city: City;
  eraId: EraId;
  onClose: () => void;
  onSwitchCity: (cityId: string, eraId: EraId) => void;
}

export function CityExperience({ city, eraId, onClose, onSwitchCity }: CityExperienceProps) {
  const { t, eraLabel, cityName, lang } = useTuranLang();
  const foundedLabels: FoundedLabels = {
    bce: t('common.bce'), ce: t('common.ce'), ancient: t('founding.ancient'),
    centuryBce: t('founding.centuryBce'), centuryCe: t('founding.centuryCe'),
    millenniumBce: t('founding.millenniumBce'), modern: t('founding.modern'), recorded: t('founding.recorded'),
  };
  const discover = useTuranStore((s) => s.discover);
  const discovered = useTuranStore((s) => s.discovered);
  const era = ERA_MAP[eraId];
  const content = useMemo(() => getMergedContent(city, eraId), [city, eraId]);
  const key = `${city.id}:${eraId}`;
  const isSaved = discovered.includes(key);
  const narrationOn = useTuranStore((s) => s.settings.narration);

  const info = TRAVEL[city.id];
  const cat = info ? CATEGORY_MAP[info.category] : null;
  const weather = weatherFor(city.id);
  const kmFromHub = distanceKm(HOME_CITY, city.id);

  const [expanded, setExpanded] = useState(false);
  const [tab, setTab] = useState<TabId>('story');
  const [lmExpanded, setLmExpanded] = useState<number | null>(null);
  const [plaqueIdx, setPlaqueIdx] = useState<number | null>(null);
  const [lightboxIdx, setLightboxIdx] = useState<number | null>(null);
  const [burst, setBurst] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  /* narration (one channel, tagline + description) */
  const [narrTarget, setNarrTarget] = useState<'tour' | 'fact'>('tour');
  const narrTargetRef = useRef<'tour' | 'fact'>('tour');
  const narration = useNarration(() =>
    narrTargetRef.current === 'fact'
      ? (content?.facts[0] ?? '')
      : `${content?.tagline ?? ''}. ${content?.description ?? ''}`
  );
  const narrate = (target: 'tour' | 'fact') => {
    narrTargetRef.current = target;
    setNarrTarget(target);
    void narration.toggle();
  };

  /* reset on city/era change is handled by remounting via `key` in MapView */

  /* mark as discovered on first open */
  useEffect(() => {
    const isNew = discover(city.id, eraId);
    if (isNew) {
      audio.play('discover');
      toast.success(t('toast.journalSaved'), {
        description: `${cityName(city.name, city.names)} · ${eraLabel(eraId)}`,
      });
    }

  }, [city.id, eraId]);

  /* Escape: plaque → lightbox → experience */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      if (lightboxIdx !== null || plaqueIdx !== null) return;
      onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose, lightboxIdx, plaqueIdx]);

  /* warm TTS cache while the visitor reads */
  useEffect(() => {
    if (!narrationOn || !content) return;
    const text = `${content.tagline}. ${content.description}`;
    const id = setTimeout(() => {
      void fetch('/api/narrate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, speed: useTuranStore.getState().settings.narrationSpeed }),
      }).catch(() => {});
    }, 2500);
    return () => clearTimeout(id);
  }, [narrationOn, content]);

  /* era years for the subtitle */
  const yearsLabel = useMemo(
    () => `${formatYear(era.startYear, t('common.bce'), t('common.ce'))} – ${formatYear(era.endYear, t('common.bce'), t('common.ce'))}`,
    [era, t]
  );

  /* sibling cities in the same era (prev / next) */
  const siblings = useMemo(() => CITIES.filter((c) => c.eras[eraId]), [eraId]);
  const sibIdx = siblings.findIndex((c) => c.id === city.id);
  const prevCity = siblings[(sibIdx - 1 + siblings.length) % siblings.length];
  const nextCity = siblings[(sibIdx + 1) % siblings.length];

  const switchTo = useCallback(
    (target: City) => {
      audio.play('click');
      onSwitchCity(target.id, eraId);
    },
    [onSwitchCity, eraId]
  );

  const openExplore = () => {
    audio.play('click');
    setExpanded(true);
    setTab('story');
    requestAnimationFrame(() => scrollRef.current?.scrollTo({ top: 0 }));
  };

  /* save with heart/bookmark burst */
  const saveToJournal = () => {
    const isNew = discover(city.id, eraId);
    if (isNew) {
      audio.play('discover');
      setBurst(true);
      setTimeout(() => setBurst(false), 700);
      toast.success(t('toast.journalSaved'));
    } else {
      toast.info(t('toast.alreadySaved'));
    }
  };

  /* -------- bottom-sheet drag (mobile) -------- */
  const sheetDrag = useRef<{ y0: number; dy: number } | null>(null);
  const onSheetPointerDown = (e: React.PointerEvent) => {
    const el = panelRef.current;
    if (!el) return;
    try {
      el.setPointerCapture(e.pointerId);
    } catch {
      /* synthetic / stale pointers — implicit touch capture still works */
    }
    sheetDrag.current = { y0: e.clientY, dy: 0 };
    el.style.transition = 'none';
  };
  const onSheetPointerMove = (e: React.PointerEvent) => {
    const el = panelRef.current;
    const d = sheetDrag.current;
    if (!el || !d) return;
    d.dy = e.clientY - d.y0;
    if (d.dy > 0) el.style.transform = `translateY(${d.dy}px)`;
  };
  const onSheetPointerUp = () => {
    const el = panelRef.current;
    const d = sheetDrag.current;
    sheetDrag.current = null;
    if (!el || !d) return;
    el.style.transition = '';
    el.style.transform = '';
    if (d.dy > 84) {
      if (expanded) { audio.play('click'); setExpanded(false); }
      else onClose();
    } else if (d.dy < -48 && !expanded) {
      openExplore();
    }
  };

  /* hero carousel slides: hero plate + up to 4 gallery plates (null-safe) */
  const heroSlides = useMemo(
    () => [
      {
        src: `/images/cities/${city.id}_${eraId}.png`,
        alt: `${cityName(city.name, city.names)} — ${eraLabel(eraId)}`,
        title: content?.tagline ?? cityName(city.name, city.names),
      },
      ...(content?.gallery ?? []).slice(0, 4).map((g) => ({
        src: `/images/cities/gallery/${g.src}.png`,
        alt: g.title,
        title: g.title,
      })),
    ],
    [city.id, city.name, city.names, eraId, content, cityName, eraLabel]
  );

  /* nearby destinations — real distances */
  const nearby = useMemo(() => {
    return CITIES.filter((c) => c.id !== city.id && TRAVEL[c.id])
      .map((c) => ({ city: c, km: distanceKm(city.id, c.id) }))
      .sort((a, b) => a.km - b.km)
      .slice(0, 8);
  }, [city.id]);

  if (!content) return null;

  const gallery: (GalleryItem & { __hero?: boolean })[] = [
    {
      src: `__hero__${city.id}_${eraId}`,
      title: `${cityName(city.name, city.names)} — ${eraLabel(eraId)}`,
      caption: content.tagline,
      __hero: true,
    },
    ...content.gallery,
  ];
  const gallerySrc = (g: GalleryItem & { __hero?: boolean }) =>
    g.__hero ? `/images/cities/${city.id}_${eraId}.png` : `/images/cities/gallery/${g.src}.png`;
  const lightboxItems = gallery.map((g) => ({
    srcResolved: gallerySrc(g),
    title: g.title,
    year: g.year,
    caption: g.caption,
  }));

  const tabs: { id: TabId; label: string; icon: React.ReactNode }[] = [
    { id: 'story', label: t('city.tabStory'), icon: <BookOpen size={13} aria-hidden="true" /> },
    { id: 'visit', label: t('visit.tab'), icon: <SunMedium size={13} aria-hidden="true" /> },
    { id: 'reviews', label: t('reviews.tab'), icon: <Star size={13} aria-hidden="true" /> },
    { id: 'nearby', label: t('nearby.tab'), icon: <Navigation size={13} aria-hidden="true" /> },
    { id: 'landmarks', label: t('city.tabLandmarks'), icon: <LandmarkIcon size={13} aria-hidden="true" /> },
    { id: 'people', label: t('city.tabPeople'), icon: <Users size={13} aria-hidden="true" /> },
    { id: 'events', label: t('city.tabEvents'), icon: <CalendarClock size={13} aria-hidden="true" /> },
    { id: 'facts', label: t('city.tabFacts'), icon: <Lightbulb size={13} aria-hidden="true" /> },
    { id: 'gallery', label: t('city.tabGallery'), icon: <Images size={13} aria-hidden="true" /> },
    { id: 'sources', label: t('city.tabSources'), icon: <Library size={13} aria-hidden="true" /> },
  ];

  return (
    <div className="city-experience" role="dialog" aria-modal="true" aria-label={city.name} data-city-popup="open">
      {/* panel */}
      <div className={`city-exp-panel ${expanded ? 'expanded' : ''}`} ref={panelRef}>
        {/* mobile drag handle */}
        <button
          className="sheet-handle md:hidden"
          onPointerDown={onSheetPointerDown}
          onPointerMove={onSheetPointerMove}
          onPointerUp={onSheetPointerUp}
          onPointerCancel={onSheetPointerUp}
          aria-label={expanded ? t('city.collapse') : t('city.explore')}
        >
          <span className="sheet-handle-bar" aria-hidden="true" />
        </button>

        {/* ---------------- hero ---------------- */}
        <div className="city-exp-hero">
          <HeroCarousel slides={heroSlides} eager />
          <div className="city-exp-hero-shade" aria-hidden="true" />
          <div className="era-strip" aria-hidden="true" style={{ background: `linear-gradient(90deg, ${era.color}, transparent 70%)` }} />

          <div className="absolute top-3 left-3 flex gap-2 z-10">
            <button
              className="w-9 h-9 rounded-full grid place-items-center hover:scale-105 transition-transform popup-share"
              onClick={() => {
                audio.play('click');
                const url = `${window.location.origin}/?city=${city.id}&era=${eraId}`;
                void navigator.clipboard
                  ?.writeText(url)
                  .then(() => toast.success(t('toast.linkCopied')))
                  .catch(() => toast.success(url));
              }}
              aria-label={t('popup.share')}
              title={t('popup.share')}
              style={{ background: 'rgba(10,8,20,0.55)', border: '1px solid var(--t-glass-border)' }}
            >
              <Share2 size={15} />
            </button>
          </div>
          <button
            className="absolute top-3 right-3 w-9 h-9 rounded-full grid place-items-center z-10"
            style={{ background: 'rgba(10,8,20,0.55)', border: '1px solid var(--t-glass-border)' }}
            onClick={onClose}
            aria-label={t('popup.close')}
          >
            <X size={18} />
          </button>

          {/* collapsed title block lives over the hero */}
          {!expanded && (
            <div className="city-exp-title">
              <div className="flex items-center gap-1.5 flex-wrap mb-3">
                <span
                  className="inline-flex items-center gap-1.5 text-[10px] tracking-[0.24em] uppercase px-2.5 py-1 rounded-full"
                  style={{ background: `${era.color}2e`, border: `1px solid ${era.color}99`, color: 'var(--t-text)' }}
                >
                  <EraGlyph eraId={eraId} size={12} strokeWidth={1.9} /> {eraLabel(eraId)} · {yearsLabel}
                </span>
                {cat && (
                  <span
                    className="inline-flex items-center gap-1 text-[10px] tracking-[0.16em] uppercase px-2 py-1 rounded-full"
                    style={{ background: `${cat.color}2b`, border: `1px solid ${cat.color}88`, color: 'var(--t-text)' }}
                  >
                    <span aria-hidden="true">{cat.icon}</span> {t(`cat.${cat.id}` as 'cat.unesco')}
                  </span>
                )}
              </div>
              <h2 className="city-exp-name" style={{ fontFamily: 'var(--font-display)' }}>
                {cityName(city.name, city.names)}
              </h2>
              <p className="city-exp-tagline ink-write">“{content.tagline}”</p>
            </div>
          )}

          {/* compact header once expanded */}
          {expanded && (
            <div className="city-exp-minihead">
              <div className="min-w-0">
                <div className="text-xl font-bold tracking-wide truncate" style={{ fontFamily: 'var(--font-display)' }}>
                  {cityName(city.name, city.names)}
                </div>
                <div className="inline-flex items-center gap-1.5 text-[10px] tracking-[0.2em] uppercase text-subtle">
                  <EraGlyph eraId={eraId} size={12} strokeWidth={1.9} /> {eraLabel(eraId)} · {yearsLabel}
                </div>
              </div>
              <button
                className="btn-glass py-1.5 px-3 text-xs shrink-0"
                onClick={() => { audio.play('click'); setExpanded(false); }}
                aria-label={t('city.collapse')}
              >
                <Expand size={13} aria-hidden="true" />
                <span className="hidden sm:inline">{t('city.collapse')}</span>
              </button>
            </div>
          )}
        </div>

        {/* ---------------- scrollable body ---------------- */}
        <div className="turan-scroll city-exp-body" ref={scrollRef}>
          {!expanded ? (
            /* ------- collapsed: travel-grade short & visual ------- */
            <div key="collapsed" className="px-5 pb-5 ink-stagger">
              <p className="city-exp-desc leading-relaxed mt-1">{content.description}</p>

              {/* travel intel chips */}
              {info && (
                <div className="travel-chip-row" role="list" aria-label={t('visit.tab')}>
                  <span className="travel-chip" role="listitem" style={{ borderColor: 'rgba(212,165,60,0.5)' }}>
                    <Star size={12} style={{ color: '#e8b33c' }} aria-hidden="true" />
                    <strong>{info.rating.toFixed(1)}</strong>
                    <span className="text-subtle">({fmtCount(info.reviewsCount)})</span>
                  </span>
                  <span className="travel-chip" role="listitem" title={t(`weather.${weather.condition}` as 'weather.sunny')}>
                    <span aria-hidden="true">{weather.icon}</span> {weather.tempC}°
                  </span>
                  <span className="travel-chip" role="listitem">
                    <Clock size={12} aria-hidden="true" />
                    {info.hours.split('·')[0]}
                  </span>
                  {kmFromHub > 0 && (
                    <span className="travel-chip" role="listitem" title={`${t('visit.distance')} ${t('visit.fromHub')}`}>
                      <Navigation size={12} aria-hidden="true" />
                      {formatKm(kmFromHub)} · {etaCar(kmFromHub)}
                    </span>
                  )}
                </div>
              )}

              {/* museum label row */}
              <div className="city-exp-stats">
                <div>
                  <div className="stat-k"><MapPin size={11} aria-hidden="true" /> {t('map.founded')}</div>
                  <div className="stat-v">{formatFounded(city.founded, lang, foundedLabels)}</div>
                </div>
                <div>
                  <div className="stat-k"><ScrollText size={11} aria-hidden="true" /> {t('city.region')}</div>
                  <div className="stat-v">{content.region}</div>
                </div>
                <div>
                  <div className="stat-k"><Feather size={11} aria-hidden="true" /> {t('city.knownFor')}</div>
                  <div className="stat-v">{content.highlights[0] ?? eraLabel(eraId)}</div>
                </div>
              </div>

              {/* at a glance */}
              {content.highlights.length > 0 && (
                <div className="mt-4">
                  <div className="ornament text-[11px] tracking-[0.24em] uppercase mb-2">{t('city.glance')}</div>
                  <div className="flex flex-wrap gap-1.5">
                    {content.highlights.map((h) => (
                      <span key={h} className="glance-chip">{h}</span>
                    ))}
                  </div>
                </div>
              )}

              {/* actions */}
              <div className="flex gap-2.5 mt-5">
                <button className="btn-accent-explore flex-1 justify-center" onClick={openExplore}>
                  {t('city.explore')}
                  <ChevronDown size={16} className="flip-rtl-none" aria-hidden="true" />
                </button>
                <button
                  className="w-11 h-11 rounded-xl grid place-items-center shrink-0 hover:scale-105 transition-transform"
                  style={{
                    background: 'var(--t-panel)',
                    border: '1px solid var(--t-glass-border)',
                    ...(narration.state !== 'idle' && narrTarget === 'tour'
                      ? { borderColor: 'var(--t-accent)', boxShadow: '0 0 14px var(--t-accent-glow)' }
                      : {}),
                  }}
                  onClick={() => narrate('tour')}
                  aria-label={t('popup.narrate')}
                  title={t('popup.narrate')}
                >
                  {narration.state === 'loading' && narrTarget === 'tour' ? (
                    <Loader2 size={16} className="animate-spin" aria-hidden="true" />
                  ) : narration.state === 'playing' && narrTarget === 'tour' ? (
                    <Square size={14} aria-hidden="true" />
                  ) : (
                    <Volume2 size={16} aria-hidden="true" />
                  )}
                </button>
                <button
                  className={`w-11 h-11 rounded-xl grid place-items-center shrink-0 hover:scale-105 transition-transform save-btn ${burst ? 'save-burst' : ''}`}
                  style={{ background: 'var(--t-panel)', border: '1px solid var(--t-glass-border)' }}
                  onClick={saveToJournal}
                  aria-label={t('popup.journal')}
                  title={t('popup.journal')}
                >
                  {isSaved ? <BookmarkCheck size={16} aria-hidden="true" /> : <Bookmark size={16} aria-hidden="true" />}
                </button>
              </div>
            </div>
          ) : (
            /* ------- expanded: the exhibition ------- */
            <div key="expanded" className="ink-fade">
              {/* tabs */}
              <div className="city-exp-tabs" role="tablist" aria-label={t('city.explore')}>
                {tabs.map((tb) => (
                  <button
                    key={tb.id}
                    role="tab"
                    aria-selected={tab === tb.id}
                    className={`exp-tab ${tab === tb.id ? 'active' : ''}`}
                    style={tab === tb.id ? ({ '--tab-era': era.color } as React.CSSProperties) : undefined}
                    onClick={() => {
                      audio.play('hover');
                      setTab(tb.id);
                      scrollRef.current?.scrollTo({ top: 0 });
                    }}
                  >
                    {tb.label}
                  </button>
                ))}
              </div>

              <div className="px-5 pb-6">
                {/* THE STORY */}
                {tab === 'story' && (
                  <div key="story" className="ink-fade">
                    {content.story.map((p, i) => (
                      <p key={i} className="leading-[1.75] text-[0.95rem] mb-3.5 first-letter:exp-drop">{p}</p>
                    ))}
                  </div>
                )}

                {/* VISIT — travel intelligence */}
                {tab === 'visit' && info && (
                  <div key="visit" className="ink-fade">
                    {/* now widget */}
                    <div className="visit-weather">
                      <span className="visit-weather-icon" aria-hidden="true">{weather.icon}</span>
                      <div className="min-w-0">
                        <div className="text-2xl font-bold tabular-nums leading-none" style={{ fontFamily: 'var(--font-display)' }}>
                          {weather.tempC}°C
                        </div>
                        <div className="text-[11px] tracking-[0.18em] uppercase text-subtle mt-1">
                          {t('visit.weather')} · {t(`weather.${weather.condition}` as 'weather.sunny')} · {cityName(city.name, city.names)}
                        </div>
                      </div>
                    </div>

                    {/* info widget grid */}
                    <div className="visit-grid">
                      <div className="visit-widget">
                        <div className="visit-widget-k"><Clock size={12} aria-hidden="true" /> {t('visit.hours')}</div>
                        <div className="visit-widget-v">{info.hours}</div>
                      </div>
                      <div className="visit-widget">
                        <div className="visit-widget-k"><Ticket size={12} aria-hidden="true" /> {t('visit.ticket')}</div>
                        <div className="visit-widget-v">{info.ticket}</div>
                      </div>
                      <div className="visit-widget">
                        <div className="visit-widget-k"><SunMedium size={12} aria-hidden="true" /> {t('visit.bestTime')}</div>
                        <div className="visit-widget-v">{info.bestTime}</div>
                      </div>
                      <div className="visit-widget">
                        <div className="visit-widget-k"><Hourglass size={12} aria-hidden="true" /> {t('visit.duration')}</div>
                        <div className="visit-widget-v">{info.duration}</div>
                      </div>
                      <div className="visit-widget">
                        <div className="visit-widget-k"><Wallet size={12} aria-hidden="true" /> {t('visit.budget')}</div>
                        <div className="visit-widget-v">{info.budget}</div>
                      </div>
                      <div className="visit-widget">
                        <div className="visit-widget-k"><Baby size={12} aria-hidden="true" /> {t('visit.family')}</div>
                        <div className="visit-widget-v">{info.family ? '✓' : '—'}</div>
                      </div>
                      <div className="visit-widget">
                        <div className="visit-widget-k"><Navigation size={12} aria-hidden="true" /> {t('visit.eta')}</div>
                        <div className="visit-widget-v">{formatKm(kmFromHub)} · {etaCar(kmFromHub)} {t('visit.byCar')}</div>
                      </div>
                      <div className="visit-widget">
                        <div className="visit-widget-k"><Footprints size={12} aria-hidden="true" /> {t('visit.onFoot')}</div>
                        <div className="visit-widget-v">{etaWalk(kmFromHub) ?? '—'}</div>
                      </div>
                    </div>

                    {/* local food */}
                    <div className="ornament text-[11px] tracking-[0.24em] uppercase mb-2 mt-5">
                      <UtensilsCrossed size={12} className="inline -mt-0.5 me-1" aria-hidden="true" />
                      {t('visit.food')}
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {info.food.map((f) => (
                        <span key={f} className="food-chip">{f}</span>
                      ))}
                    </div>

                    {/* travel tips */}
                    <div className="ornament text-[11px] tracking-[0.24em] uppercase mb-2 mt-5">{t('visit.tips')}</div>
                    <ul className="tip-list">
                      {info.tips.map((tip) => (
                        <li key={tip} className="tip-row">{tip}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* REVIEWS */}
                {tab === 'reviews' && info && (
                  <div key="reviews" className="ink-fade">
                    <div className="reviews-summary">
                      <div className="reviews-score tabular-nums" style={{ fontFamily: 'var(--font-display)' }}>
                        {info.rating.toFixed(1)}
                      </div>
                      <div>
                        <div className="reviews-stars" aria-label={`${info.rating} / 5`}>
                          {[1, 2, 3, 4, 5].map((n) => (
                            <Star
                              key={n}
                              size={15}
                              aria-hidden="true"
                              style={{
                                color: n <= Math.round(info.rating) ? '#e8b33c' : 'rgba(180,170,150,0.35)',
                              }}
                              fill={n <= Math.round(info.rating) ? '#e8b33c' : 'none'}
                            />
                          ))}
                        </div>
                        <div className="text-xs text-subtle mt-0.5">
                          {fmtCount(info.reviewsCount)} {t('reviews.count')}
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col gap-3 mt-4">
                      {info.reviews.map((r) => (
                        <article key={r.name} className="review-card">
                          <div className="flex items-center gap-2.5">
                            <span className="review-avatar" aria-hidden="true">{r.name.slice(0, 1)}</span>
                            <div className="min-w-0 flex-1">
                              <div className="text-sm font-semibold truncate">{r.name}</div>
                              <div className="text-[10px] tracking-[0.14em] uppercase text-subtle truncate">{r.from} · {r.when}</div>
                            </div>
                            <span className="review-stars shrink-0" aria-label={`${r.rating}/5`}>
                              {[1, 2, 3, 4, 5].map((n) => (
                                <Star
                                  key={n}
                                  size={10}
                                  aria-hidden="true"
                                  style={{ color: n <= r.rating ? '#e8b33c' : 'rgba(180,170,150,0.3)' }}
                                  fill={n <= r.rating ? '#e8b33c' : 'none'}
                                />
                              ))}
                            </span>
                          </div>
                          <p className="text-sm leading-relaxed mt-2">{r.text}</p>
                          <div className="flex items-center gap-1 mt-2 text-subtle">
                            <ThumbsUp size={11} aria-hidden="true" />
                            <span className="text-[11px] tabular-nums">{r.helpful}</span>
                            <span className="text-[11px] ms-1">{t('reviews.helpful')}</span>
                          </div>
                        </article>
                      ))}
                    </div>
                  </div>
                )}

                {/* NEARBY */}
                {tab === 'nearby' && (
                  <div key="nearby" className="ink-fade -mx-5">
                    <div className="nearby-strip turan-scroll">
                      {nearby.map(({ city: n, km }) => (
                        <button
                          key={n.id}
                          className="nearby-card"
                          onClick={() => {
                            const eraId2 = CITY_MAP[n.id].eras[eraId] ? eraId : ((Object.keys(CITY_MAP[n.id].eras) as EraId[])[0]);
                            audio.play('click');
                            onSwitchCity(n.id, eraId2);
                          }}
                          aria-label={`${cityName(n.name, n.names)} — ${formatKm(km)}`}
                        >
                          <span className="nearby-img-wrap">
                            <MuseumImage src={showcaseImage(n.id)} alt={cityName(n.name, n.names)} className="w-full h-full" />
                            <span className="nearby-km tabular-nums">{km} {t('visit.kmAway')}</span>
                          </span>
                          <span className="nearby-name">{cityName(n.name, n.names)}</span>
                          <span className="nearby-eta text-subtle">{etaCar(km)} {t('visit.byCar')}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* LANDMARKS */}
                {tab === 'landmarks' && (
                  <div key="landmarks" className="ink-fade flex flex-col gap-2">
                    {content.landmarks.map((lm, i) => (
                      <div key={lm.name} className="landmark-item">
                        <div className="flex items-stretch">
                          <button
                            className="flex-1 min-w-0 text-start ps-3 pe-2 py-2.5 flex items-center gap-2.5 font-semibold text-sm"
                            onClick={() => setLmExpanded(lmExpanded === i ? null : i)}
                            aria-expanded={lmExpanded === i}
                          >
                            <span className="lm-medal" aria-hidden="true">{['I', 'II', 'III', 'IV', 'V'][i] ?? i + 1}</span>
                            <span className="flex-1 min-w-0">{lm.name}</span>
                            <ChevronDown
                              size={16}
                              className="transition-transform shrink-0"
                              style={{ transform: lmExpanded === i ? 'rotate(180deg)' : 'none', color: 'var(--t-accent)' }}
                              aria-hidden="true"
                            />
                          </button>
                          <button
                            className="lm-dive"
                            onClick={() => { audio.play('click'); setPlaqueIdx(i); }}
                            aria-label={`${t('landmark.deepDive')}: ${lm.name}`}
                            title={t('landmark.deepDive')}
                          >
                            <Maximize2 size={14} aria-hidden="true" />
                          </button>
                        </div>
                        {lmExpanded === i && (
                          <div className="px-3.5 pb-3 ink-fade">
                            <p className="text-sm text-subtle leading-relaxed">{lm.detail}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* PEOPLE */}
                {tab === 'people' && (
                  <div key="people" className="ink-fade">
                    {content.figures?.length ? (
                      <div className="flex flex-col gap-3">
                        {content.figures.map((f) => (
                          <div key={f.name} className="figure-card">
                            <div className="flex items-baseline justify-between gap-2 flex-wrap">
                              <span className="font-bold" style={{ fontFamily: 'var(--font-display)' }}>{f.name}</span>
                              {f.years && <span className="text-[10px] tracking-[0.16em] text-subtle tabular-nums">{f.years}</span>}
                            </div>
                            <div className="text-[10px] tracking-[0.2em] uppercase mt-0.5" style={{ color: 'var(--t-accent)' }}>{f.role}</div>
                            <p className="text-sm text-subtle leading-relaxed mt-1.5">{f.bio}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="archive-empty">{t('city.emptyFigures')}</p>
                    )}
                  </div>
                )}

                {/* KEY EVENTS */}
                {tab === 'events' && (
                  <div key="events" className="ink-fade">
                    {content.events?.length ? (
                      <div className="event-rail" style={{ '--rail-era': era.color } as React.CSSProperties}>
                        {content.events.map((ev) => (
                          <div key={`${ev.year}-${ev.text.slice(0, 12)}`} className="event-row">
                            <div className="event-year tabular-nums" style={{ fontFamily: 'var(--font-display)' }}>{ev.year}</div>
                            <p className="text-sm leading-relaxed text-subtle">{ev.text}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="archive-empty">{t('city.emptyEvents')}</p>
                    )}
                  </div>
                )}

                {/* DID YOU KNOW */}
                {tab === 'facts' && (
                  <div key="facts" className="ink-fade flex flex-col gap-3">
                    {content.facts.map((f, i) => (
                      <div key={i} className="glass p-3.5 flex gap-3 items-start" style={{ borderRadius: 12 }}>
                        <Lightbulb size={18} style={{ color: 'var(--t-accent)', flexShrink: 0, marginTop: 2 }} aria-hidden="true" />
                        <p className="text-sm leading-relaxed">{f}</p>
                      </div>
                    ))}
                    <button
                      className="self-start btn-glass py-2 px-3.5 text-xs"
                      style={narration.state !== 'idle' && narrTarget === 'fact' ? { borderColor: 'var(--t-accent)' } : undefined}
                      onClick={() => narrate('fact')}
                    >
                      <Volume2 size={14} aria-hidden="true" />
                      {narration.state === 'playing' && narrTarget === 'fact' ? t('popup.narrateStop') : t('popup.narrateFact')}
                    </button>
                  </div>
                )}

                {/* GALLERY */}
                {tab === 'gallery' && (
                  <div key="gallery" className="ink-fade -mx-5">
                    <MuseumImage
                      eager
                      key={`feat-${gallery[0]?.src}`}
                      src={gallerySrc(gallery[0])}
                      alt={gallery[0]?.title ?? ''}
                      className="w-full h-56 sm:h-64 city-exp-hero-img"
                    />
                    <div className="flex items-center justify-between px-5 mt-2">
                      <div className="min-w-0">
                        <div className="font-bold text-sm truncate">{gallery[0]?.title}</div>
                        <div className="text-xs text-subtle line-clamp-1">{gallery[0]?.caption}</div>
                      </div>
                      <button
                        className="btn-glass py-1.5 px-3 text-xs shrink-0"
                        onClick={() => { audio.play('click'); setLightboxIdx(0); }}
                      >
                        <Expand size={13} aria-hidden="true" />
                        {t('city.viewAll')}
                      </button>
                    </div>

                    {/* horizontal strip */}
                    <div className="gallery-strip turan-scroll" role="listbox" aria-label={t('city.tabGallery')}>
                      {gallery.map((g, i) => (
                        <button
                          key={g.src}
                          role="option"
                          aria-selected={i === 0}
                          className="gallery-thumb"
                          onClick={() => { audio.play('hover'); setLightboxIdx(i); }}
                          aria-label={g.title}
                        >
                          <MuseumImage
                            src={gallerySrc(g)}
                            alt={g.title}
                            className="w-full h-full"
                          />
                          <span className="gallery-thumb-title">{g.title}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* SOURCES */}
                {tab === 'sources' && (
                  <div key="sources" className="ink-fade">
                    <div className="source-plaque">
                      <ScrollText size={16} style={{ color: 'var(--t-accent)' }} aria-hidden="true" />
                      <div className="text-[11px] tracking-[0.22em] uppercase" style={{ color: 'var(--t-accent)' }}>
                        {t('city.tabSources')}
                      </div>
                    </div>
                    {(content.sources?.length ? (
                      <ul className="flex flex-col gap-2 mt-3">
                        {content.sources.map((s) => (
                          <li key={s} className="source-row">{s}</li>
                        ))}
                      </ul>
                    ) : (
                      <p className="archive-empty mt-3">{t('city.emptySources')}</p>
                    ))}
                    <p className="text-[11px] text-subtle mt-4 leading-relaxed">{t('city.museumNote')}</p>
                  </div>
                )}
              </div>

              {/* prev / next city */}
              <div className="city-exp-footnav">
                <button className="footnav-btn" onClick={() => switchTo(prevCity)}>
                  <ChevronLeft size={15} className="flip-rtl" aria-hidden="true" />
                  <span className="min-w-0 text-start">
                    <span className="block text-[9px] tracking-[0.18em] uppercase text-subtle">{t('city.prevCity')}</span>
                    <span className="block text-sm font-semibold truncate">{cityName(prevCity.name, prevCity.names)}</span>
                  </span>
                </button>
                <button className="footnav-btn footnav-next" onClick={() => switchTo(nextCity)}>
                  <span className="min-w-0 text-end">
                    <span className="block text-[9px] tracking-[0.18em] uppercase text-subtle">{t('city.nextCity')}</span>
                    <span className="block text-sm font-semibold truncate">{cityName(nextCity.name, nextCity.names)}</span>
                  </span>
                  <ChevronRight size={15} className="flip-rtl" aria-hidden="true" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* landmark deep-dive plaque */}
      {plaqueIdx !== null && content.landmarks[plaqueIdx] && (
        <LandmarkPlaque
          city={city}
          eraId={eraId}
          index={plaqueIdx}
          count={content.landmarks.length}
          name={content.landmarks[plaqueIdx].name}
          detail={content.landmarks[plaqueIdx].detail}
          onClose={() => setPlaqueIdx(null)}
          onNavigate={(i) => setPlaqueIdx(i)}
        />
      )}

      {/* immersive lightbox */}
      {lightboxIdx !== null && (
        <Lightbox
          items={lightboxItems}
          index={Math.min(lightboxIdx, lightboxItems.length - 1)}
          cityLabel={cityName(city.name, city.names)}
          eraLabel={eraLabel(eraId)}
          onClose={() => setLightboxIdx(null)}
          onIndex={(i) => setLightboxIdx(i)}
        />
      )}
    </div>
  );
}
