'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  BookOpen,
  MapPin,
  Download,
  FileJson,
  Search,
  SearchX,
  Hourglass,
  X,
  Lightbulb,
  Landmark as LandmarkIcon,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { toast } from 'sonner';
import { CITIES, CITY_MAP, TOTAL_COMBINATIONS, type City } from '@/data/cities';
import { ERAS, ERA_MAP, type EraId } from '@/data/eras';
import { useTuranStore } from '@/lib/store';
import { useTuranLang } from './useTuranLang';
import { CityImage } from './CityImage';
import { EraGlyph, GlyphScroll, GlyphCompassRose } from './glyphs';
import { formatFounded, type FoundedLabels } from '@/lib/turan-utils';
import { audio } from '@/lib/audio-engine';

/** case-insensitive match against localized + English city name and the era label */
function matchQuery(
  city: (typeof CITIES)[number],
  eraId: EraId,
  q: string,
  cityNameFn: (name: string, names: Record<string, string>) => string,
  eraLabelFn: (id: EraId) => string
): boolean {
  const needle = q.trim().toLowerCase();
  if (!needle) return true;
  const hay = `${city.name} ${Object.values(city.names).join(' ')} ${cityNameFn(city.name, city.names)} ${eraLabelFn(eraId)} ${city.founded}`.toLowerCase();
  return hay.includes(needle);
}

/**
 * Parse the human "founded" string into a sortable year number so journal
 * cards can be ordered chronologically instead of by atlas order.
 * Handles: '742 BCE' · '4th century BCE' · '1st millennium BCE' · '1732 CE'
 *          '9th century CE (recorded)' · 'Ancient'
 */
export function foundedSortKey(founded: string): number {
  const f = founded.toLowerCase();
  if (f.includes('ancient')) return -100000;
  const numMatch = f.match(/(\d+)/);
  let n = numMatch ? parseInt(numMatch[1], 10) : 0;
  if (f.includes('millennium')) n *= 1000;
  else if (f.includes('century')) n = n; // century number already the coarse order
  const isBce = f.includes('bce') || f.includes('bc)');
  return isBce ? -n : n;
}

interface JournalEntry {
  city: City;
  eraId: EraId;
}

const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII'];

export function Journal() {
  const setScreen = useTuranStore((s) => s.setScreen);
  const discovered = useTuranStore((s) => s.discovered);
  const openCity = useTuranStore((s) => s.openCity);
  const { t, eraLabel, cityName, lang } = useTuranLang();
  const foundedLabels: FoundedLabels = {
    bce: t('common.bce'), ce: t('common.ce'), ancient: t('founding.ancient'),
    centuryBce: t('founding.centuryBce'), centuryCe: t('founding.centuryCe'),
    millenniumBce: t('founding.millenniumBce'), modern: t('founding.modern'), recorded: t('founding.recorded'),
  };
  const foundedText = (founded: string) => formatFounded(founded, lang, foundedLabels);
  const [eraFilter, setEraFilter] = useState<EraId | 'all'>('all');
  const [query, setQuery] = useState('');
  const [groupBy, setGroupBy] = useState<'city' | 'era'>('city');

  /** index into flatEntries for the open entry drawer (null = closed) */
  const [detailIdx, setDetailIdx] = useState<number | null>(null);
  const drawerScrollRef = useRef<HTMLDivElement>(null);

  const progress = Math.round((discovered.length / TOTAL_COMBINATIONS) * 100);

  /** group discovered keys by city, keeping city order */
  const allGroups = useMemo(() => {
    const byCity = new Map<string, EraId[]>();
    discovered.forEach((key) => {
      const [cityId, eraId] = key.split(':') as [string, EraId];
      if (!CITY_MAP[cityId]?.eras[eraId]) return;
      const list = byCity.get(cityId) ?? [];
      list.push(eraId);
      byCity.set(cityId, list);
    });
    return CITIES.filter((c) => byCity.has(c.id)).map((c) => ({
      city: c,
      eras: byCity.get(c.id)!,
    }));
  }, [discovered]);

  /** how many entries exist per era (for filter chip badges) */
  const eraCounts = useMemo(() => {
    const counts = new Map<EraId, number>();
    discovered.forEach((key) => {
      const eraId = key.split(':')[1] as EraId;
      counts.set(eraId, (counts.get(eraId) ?? 0) + 1);
    });
    return counts;
  }, [discovered]);

  const groups = useMemo(
    () =>
      allGroups
        .map(({ city, eras }) => ({
          city,
          eras: eras.filter(
            (e) =>
              (eraFilter === 'all' || e === eraFilter) && matchQuery(city, e, query, cityName, eraLabel)
          ),
        }))
        .filter((g) => g.eras.length > 0),
    [allGroups, eraFilter, query, cityName, eraLabel]
  );

  /** flat ordered entry list behind the drawer's prev/next navigation */
  const flatEntries = useMemo<JournalEntry[]>(
    () => groups.flatMap(({ city, eras }) => eras.map((eraId) => ({ city, eraId }))),
    [groups]
  );

  const filteredEntryCount = flatEntries.length;
  const searched = query.trim().length > 0;
  const shownEntries = filteredEntryCount;

  /** era-grouped view: each era lists the cities discovered in it, oldest founding first */
  const eraGroups = useMemo(
    () =>
      ERAS.map((era) => {
        const entries = allGroups
          .filter((g) => g.eras.includes(era.id))
          .filter((g) => (eraFilter === 'all' || era.id === eraFilter) && matchQuery(g.city, era.id, query, cityName, eraLabel))
          .map((g) => ({ city: g.city, eraId: era.id as EraId }))
          .sort((a, b) => foundedSortKey(a.city.founded) - foundedSortKey(b.city.founded));
        return { era, entries };
      }).filter((eg) => eg.entries.length > 0),
    [allGroups, eraFilter, query, cityName, eraLabel]
  );

  /* ---------------- entry drawer logic ---------------- */
  const closeDetail = useCallback(() => setDetailIdx(null), []);

  const stepDetail = useCallback(
    (dir: 1 | -1) => {
      setDetailIdx((i) => {
        if (i === null) return i;
        const next = i + dir;
        if (next < 0 || next >= flatEntries.length) return i;
        return next;
      });
    },
    [flatEntries.length]
  );

  const exploreEntry = useCallback(
    (entry: JournalEntry) => {
      audio.play('click');
      openCity(entry.city.id, entry.eraId, false);
      setDetailIdx(null);
      setScreen('map');
    },
    [openCity, setScreen]
  );

  // keyboard: Escape closes, arrows move between entries
  useEffect(() => {
    if (detailIdx === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        closeDetail();
      } else if (e.key === 'ArrowLeft') {
        e.stopPropagation();
        stepDetail(-1);
      } else if (e.key === 'ArrowRight') {
        e.stopPropagation();
        stepDetail(1);
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [detailIdx, closeDetail, stepDetail]);

  // scroll the drawer body back to top on entry change
  useEffect(() => {
    if (drawerScrollRef.current) drawerScrollRef.current.scrollTop = 0;
  }, [detailIdx]);

  /** open the drawer for an entry (find its flat index) */
  const openDetail = useCallback(
    (entry: JournalEntry) => {
      audio.play('click');
      const idx = flatEntries.findIndex(
        (e) => e.city.id === entry.city.id && e.eraId === entry.eraId
      );
      setDetailIdx(idx >= 0 ? idx : null);
    },
    [flatEntries]
  );

  const detail = detailIdx !== null ? flatEntries[detailIdx] : null;

  const exportJournal = () => {
    const entries = groups;
    const total = filteredEntryCount;
    const lines: string[] = [
      '═══════════════════════════════════════',
      '  TURAN — The Heart of the Silk Road',
      '  Travel Journal',
      `  Exported: ${new Date().toLocaleString()}`,
      `  Entries: ${total}${eraFilter !== 'all' ? ` (${eraLabel(eraFilter as EraId)})` : ''}${searched ? ` · “${query.trim()}”` : ''}`,
      '═══════════════════════════════════════',
      '',
    ];
    entries.forEach(({ city, eras }) => {
      eras.forEach((eraId) => {
        const content = city.eras[eraId];
        if (!content) return;
        lines.push(`◆ ${city.name} — ${eraLabel(eraId)}`);
        lines.push(`  ${content.tagline}`);
        lines.push(`  ${content.description}`);
        lines.push(`  ${t('popup.didYouKnow')} ${content.fact}`);
        if (content.landmarks.length) {
          lines.push(`  ${t('popup.landmarks')}:`);
          content.landmarks.forEach((lm) => {
            lines.push(`    • ${lm.name} — ${lm.detail}`);
          });
        }
        lines.push('');
      });
    });
    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `turan-journal-${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(t('toast.exported'));
  };

  const exportJournalJson = () => {
    const entries = groups;
    const payload = {
      app: 'turan-journal',
      exportedAt: new Date().toISOString(),
      filter: eraFilter,
      search: searched ? query.trim() : undefined,
      count: filteredEntryCount,
      totalCombinations: TOTAL_COMBINATIONS,
      entries: entries.flatMap(({ city, eras }) =>
        eras.map((eraId) => {
          const content = city.eras[eraId];
          return {
            city: { id: city.id, name: city.name, founded: city.founded },
            era: eraId,
            tagline: content?.tagline,
            description: content?.description,
            fact: content?.fact,
            landmarks: content?.landmarks.map((lm) => ({ name: lm.name, detail: lm.detail })),
          };
        })
      ),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `turan-journal-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success(t('toast.exported'));
  };

  return (
    <main className="turan-root min-h-screen flex flex-col px-3 sm:px-6 py-5">
      <header className="w-full max-w-3xl mx-auto flex items-center justify-between mb-5">
        <button
          className="btn-glass py-2 px-3.5 text-sm"
          onClick={() => {
            audio.play('click');
            setScreen('menu');
          }}
        >
          <ArrowLeft size={16} className="flip-rtl" aria-hidden="true" />
          <span className="hidden sm:inline">{t('common.backToMenu')}</span>
        </button>
        <h1 className="text-lg sm:text-2xl font-bold tracking-[0.18em] uppercase text-heading" style={{ fontFamily: 'var(--font-display)' }}>
          <GlyphScroll size={15} strokeWidth={1.7} /> {t('journal.open')}
        </h1>
        <div className="flex items-center gap-2 export-split">
          <button
            className="btn-glass py-2 px-3.5 text-sm"
            onClick={exportJournal}
            disabled={discovered.length === 0}
            aria-label={`${t('prog.export')} (TXT)`}
            title={`${t('prog.export')} (TXT)`}
          >
            <Download size={16} aria-hidden="true" />
            <span className="hidden sm:inline text-xs">TXT</span>
          </button>
          <button
            className="btn-glass py-2 px-3.5 text-sm"
            onClick={exportJournalJson}
            disabled={discovered.length === 0}
            aria-label={t('journal.exportJsonDesc')}
            title={t('journal.exportJsonDesc')}
          >
            <FileJson size={16} aria-hidden="true" />
            <span className="hidden sm:inline text-xs">{t('journal.exportJson')}</span>
          </button>
        </div>
      </header>

      <section className="w-full max-w-3xl mx-auto glass-strong ornate p-5 sm:p-6">
        {/* progress header */}
        <div className="flex items-center justify-between gap-4 mb-1">
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold gold-glow-text tabular-nums" style={{ fontFamily: 'var(--font-display)' }}>
              {shownEntries}
            </span>
            <span className="text-subtle text-sm">/ {TOTAL_COMBINATIONS} {t('journal.entries')}</span>
          </div>
          <span className="text-lg font-bold" style={{ color: 'var(--t-accent)' }}>{progress}%</span>
        </div>
        <div className="discovery-track mb-5" role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}>
          <div className="discovery-fill" style={{ width: `${progress}%` }} />
        </div>

        {/* grouping toggle + era filter chips */}
        {discovered.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div className="seg-group journal-group-seg" role="group" aria-label={t('journal.groupBy')}>
              <button
                className={`seg-option ${groupBy === 'city' ? 'active' : ''}`}
                onClick={() => {
                  audio.play('click');
                  setGroupBy('city');
                }}
              >
                <MapPin size={13} aria-hidden="true" className="inline -mt-0.5 me-1" />
                {t('journal.groupCity')}
              </button>
              <button
                className={`seg-option ${groupBy === 'era' ? 'active' : ''}`}
                onClick={() => {
                  audio.play('click');
                  setGroupBy('era');
                }}
              >
                <Hourglass size={13} aria-hidden="true" className="inline -mt-0.5 me-1" />
                {t('journal.groupEra')}
              </button>
            </div>
            <span className="text-[11px] text-subtle tracking-wide uppercase">{t('journal.groupBy')}</span>
          </div>
        )}

        {/* era filter chips */}
        {discovered.length > 0 && (
          <div className="journal-filter mb-5" role="group" aria-label={t('map.era')}>
            <button
              className={`filter-chip ${eraFilter === 'all' ? 'active' : ''}`}
              onClick={() => {
                audio.play('click');
                setEraFilter('all');
              }}
            >
              ✦ {t('journal.filterAll')}
              <span className="filter-count">{discovered.length}</span>
            </button>
            {ERAS.map((era) => {
              const count = eraCounts.get(era.id) ?? 0;
              const active = eraFilter === era.id;
              return (
                <button
                  key={era.id}
                  className={`filter-chip ${active ? 'active' : ''}`}
                  style={active ? { borderColor: era.color, boxShadow: `0 0 12px ${era.color}55`, color: era.color } : undefined}
                  disabled={count === 0}
                  onClick={() => {
                    audio.play('click');
                    setEraFilter(era.id);
                  }}
                >
                  <span aria-hidden="true"><EraGlyph eraId={era.id} size={12} strokeWidth={1.9} /></span> {eraLabel(era.id)}
                  <span className="filter-count">{count}</span>
                </button>
              );
            })}
          </div>
        )}

        {/* city-name search */}
        {discovered.length > 0 && (
          <div className="journal-search mb-5">
            <Search size={15} className="journal-search-icon" aria-hidden="true" />
            <input
              type="text"
              className="journal-search-input"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t('journal.search')}
              aria-label={t('journal.search')}
            />
            {searched && (
              <button
                className="journal-search-clear"
                onClick={() => {
                  audio.play('click');
                  setQuery('');
                }}
                aria-label={t('journal.searchClear')}
                title={t('journal.searchClear')}
              >
                ✕
              </button>
            )}
          </div>
        )}

        {groups.length === 0 ? (
          searched ? (
            <div className="text-center py-10 flex flex-col items-center gap-3">
              <SearchX size={40} style={{ color: 'var(--t-accent)', opacity: 0.6 }} aria-hidden="true" />
              <p className="text-sm text-subtle">{t('journal.noMatch')}</p>
              <button
                className="btn-glass text-sm mt-1"
                onClick={() => {
                  audio.play('click');
                  setQuery('');
                  setEraFilter('all');
                }}
              >
                {t('journal.searchClear')}
              </button>
            </div>
          ) : (
          <div className="text-center py-12 flex flex-col items-center gap-3">
            <BookOpen size={44} style={{ color: 'var(--t-accent)', opacity: 0.6 }} aria-hidden="true" />
            <h2 className="text-xl font-bold text-heading">{t('journal.empty')}</h2>
            <p className="text-sm text-subtle max-w-sm leading-relaxed">{t('journal.emptyHint')}</p>
            <div className="flex gap-2.5 mt-2 flex-wrap justify-center">
              <button
                className="btn-glass btn-accent text-sm"
                onClick={() => {
                  audio.play('click');
                  setScreen('map');
                }}
              >
                <MapPin size={16} aria-hidden="true" />
                {t('menu.begin')}
              </button>
              <button
                className="btn-glass text-sm"
                onClick={() => {
                  audio.play('click');
                  setScreen('random');
                }}
              >
                <GlyphCompassRose size={15} strokeWidth={1.7} /> {t('menu.random')}
              </button>
            </div>
          </div>
          )
        ) : groupBy === 'era' ? (
          /* ---------- era-grouped view (cards sorted by founding date) ---------- */
          <div className="journal-stagger flex flex-col gap-6 turan-scroll max-h-[62vh] pe-1">
            {eraGroups.map(({ era, entries }) => (
              <section key={era.id} className="era-group" style={{ '--eg-color': era.color } as React.CSSProperties}>
                <header className="era-group-head">
                  <span className="era-group-icon" aria-hidden="true"><EraGlyph eraId={era.id} size={14} strokeWidth={1.8} /></span>
                  <h3 className="era-group-title" style={{ fontFamily: 'var(--font-display)' }}>{eraLabel(era.id)}</h3>
                  <span className="era-group-count filter-count">{entries.length}</span>
                  <span className="era-group-line" aria-hidden="true" />
                </header>
                <div className="era-group-grid">
                  {entries.map(({ city, eraId }) => {
                    const content = city.eras[eraId];
                    return (
                      <button
                        key={`${city.id}:${eraId}`}
                        className="era-group-card"
                        onClick={() => openDetail({ city, eraId })}
                        aria-label={`${cityName(city.name, city.names)} — ${eraLabel(eraId)}`}
                        title={content?.tagline}
                      >
                        <span className="era-group-thumb">
                          <img
                            src={`/images/cities/${city.id}_${eraId}.png`}
                            alt=""
                            className="w-full h-full object-cover"
                            onError={(e) => (e.currentTarget.style.display = 'none')}
                          />
                          <span className="placeholder-art absolute inset-0" />
                        </span>
                        <span className="era-group-name">{cityName(city.name, city.names)}</span>
                        <span className="era-group-meta">{foundedText(city.founded)}</span>
                      </button>
                    );
                  })}
                </div>
              </section>
            ))}
          </div>
        ) : (
          <div className="journal-stagger flex flex-col gap-5 turan-scroll max-h-[62vh] pe-1">
            {groups.map(({ city, eras }) => (
              <article key={city.id} className="landmark-item overflow-hidden">
                <div className="flex items-center gap-4 p-3.5">
                  {/* thumbnail */}
                  <button
                    className="relative w-20 h-14 rounded-lg overflow-hidden shrink-0 border"
                    style={{ borderColor: 'var(--t-glass-border)' }}
                    onClick={() => openDetail({ city, eraId: eras[0] })}
                    aria-label={`${t('journal.entryDetail')}: ${city.name}`}
                  >
                    <img
                      src={`/images/cities/${city.id}_${eras[0]}.png`}
                      alt=""
                      className="w-full h-full object-cover"
                      onError={(e) => (e.currentTarget.style.display = 'none')}
                    />
                    <div className="placeholder-art absolute inset-0 -z-10" />
                  </button>
                  <div className="min-w-0 flex-1">
                    <h3 className="font-bold text-lg leading-tight" style={{ fontFamily: 'var(--font-display)' }}>
                      {cityName(city.name, city.names)}
                    </h3>
                    <p className="text-[11px] text-subtle tracking-wide uppercase">
                      {t('map.founded')}: {foundedText(city.founded)}
                    </p>
                  </div>
                </div>
                {/* era chips */}
                <div className="flex flex-wrap gap-1.5 px-3.5 pb-3.5">
                  {eras.map((eraId) => {
                    const era = ERA_MAP[eraId];
                    const content = city.eras[eraId];
                    return (
                      <button
                        key={eraId}
                        className="text-start rounded-lg px-2.5 py-1.5 text-xs transition-transform hover:scale-[1.03] border"
                        style={{
                          background: `${era.color}1f`,
                          borderColor: `${era.color}66`,
                        }}
                        onClick={() => openDetail({ city, eraId })}
                        title={content?.tagline}
                      >
                        <span aria-hidden="true"><EraGlyph eraId={era.id} size={11} strokeWidth={1.9} /></span>{' '}
                        <span className="font-semibold">{eraLabel(eraId)}</span>
                        {content && <span className="text-subtle"> — {content.tagline}</span>}
                      </button>
                    );
                  })}
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {/* ---------- entry detail drawer ---------- */}
      {detail && (() => {
        const era = ERA_MAP[detail.eraId];
        const content = detail.city.eras[detail.eraId];
        if (!content) return null;
        return (
          <div
            className="fixed inset-0 z-[60] flex items-center justify-center p-3 sm:p-6"
            role="dialog"
            aria-modal="true"
            aria-label={`${cityName(detail.city.name, detail.city.names)} — ${eraLabel(detail.eraId)}`}
            data-journal-drawer="open"
          >
            <div
              className="absolute inset-0 journal-drawer-backdrop"
              onClick={closeDetail}
              aria-hidden="true"
            />
            <div className="journal-drawer glass-strong ornate relative w-full max-w-xl max-h-[100dvh] sm:max-h-[calc(100vh-3rem)] flex flex-col overflow-hidden">
              {/* era gradient strip */}
              <div className="era-strip" aria-hidden="true" style={{ background: `linear-gradient(90deg, ${era.color}, transparent 70%)` }} />

              {/* artwork header */}
              <div className="relative h-40 sm:h-48 shrink-0">
                <div className="absolute inset-0 plaque-art">
                  <CityImage
                    cityId={detail.city.id}
                    eraId={detail.eraId}
                    cityName={detail.city.name}
                    eraLabel={eraLabel(detail.eraId)}
                    className="w-full h-full"
                  />
                </div>
                <div
                  className="absolute inset-0"
                  style={{ background: 'linear-gradient(to top, var(--t-panel-solid) 4%, rgba(8,6,18,0.16) 50%, rgba(8,6,18,0.34) 100%)' }}
                  aria-hidden="true"
                />
                <button
                  className="absolute top-3 right-3 w-9 h-9 rounded-full glass grid place-items-center hover:scale-105 transition-transform"
                  onClick={() => {
                    audio.play('click');
                    closeDetail();
                  }}
                  aria-label={t('popup.close')}
                >
                  <X size={18} />
                </button>
                <div className="absolute bottom-2.5 left-4 right-4">
                  <span
                    className="inline-block text-[10px] tracking-[0.22em] uppercase px-2.5 py-1 rounded-full"
                    style={{ background: `${era.color}33`, border: `1px solid ${era.color}`, color: 'var(--t-text)' }}
                  >
                    <EraGlyph eraId={detail.eraId} size={12} strokeWidth={1.9} /> {eraLabel(detail.eraId)}
                  </span>
                </div>
              </div>

              {/* body */}
              <div ref={drawerScrollRef} className="turan-scroll flex-1 px-5 sm:px-6 py-4 overflow-y-auto">
                <div className="ornament text-[10.5px] tracking-[0.24em] uppercase mb-1" style={{ color: 'var(--t-accent)' }}>
                  <BookOpen size={12} aria-hidden="true" />
                  {t('journal.entryDetail')}
                </div>
                <h2 className="text-2xl sm:text-3xl font-bold text-heading tracking-wide" style={{ fontFamily: 'var(--font-display)' }}>
                  {cityName(detail.city.name, detail.city.names)}
                </h2>
                <p className="text-[11px] text-subtle tracking-[0.18em] uppercase mt-1">
                  {t('map.founded')}: {foundedText(detail.city.founded)}
                </p>
                <p className="italic mt-2" style={{ color: 'var(--t-accent)' }}>
                  “{content.tagline}”
                </p>
                <p className="mt-3 leading-relaxed text-[0.92rem] ink-fade">{content.description}</p>

                {/* did you know */}
                <div className="glass mt-4 p-3.5 flex gap-3 items-start" style={{ borderRadius: 12 }}>
                  <Lightbulb size={19} style={{ color: 'var(--t-accent)', flexShrink: 0, marginTop: 2 }} aria-hidden="true" />
                  <div className="min-w-0 flex-1">
                    <div className="text-[11px] tracking-[0.2em] uppercase font-semibold" style={{ color: 'var(--t-accent)' }}>
                      {t('popup.didYouKnow')}
                    </div>
                    <p className="text-sm mt-1 leading-relaxed">{content.fact}</p>
                  </div>
                </div>

                {/* landmarks */}
                {content.landmarks.length > 0 && (
                  <div className="mt-4">
                    <div className="ornament text-[10.5px] tracking-[0.24em] uppercase mb-2.5">
                      <LandmarkIcon size={13} aria-hidden="true" />
                      {t('popup.landmarks')}
                    </div>
                    <ul className="flex flex-col gap-1.5">
                      {content.landmarks.map((lm, i) => (
                        <li key={lm.name} className="drawer-landmark">
                          <span className="lm-medal" aria-hidden="true">{ROMAN[i] ?? i + 1}</span>
                          <span className="min-w-0 flex-1">
                            <span className="block text-sm font-semibold leading-snug">{lm.name}</span>
                            <span className="block text-xs text-subtle leading-relaxed mt-0.5">{lm.detail}</span>
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* footer: prev/next + explore CTA */}
              <div className="shrink-0 px-4 sm:px-5 py-3 flex flex-col gap-2.5" style={{ borderTop: '1px solid var(--t-glass-border)' }}>
                <div className="flex items-center justify-between gap-2">
                  <button
                    className="btn-glass py-2 px-3 text-xs"
                    onClick={() => stepDetail(-1)}
                    disabled={detailIdx === 0}
                    aria-label={t('journal.prev')}
                  >
                    <ChevronLeft size={15} className="flip-rtl" aria-hidden="true" />
                    <span className="hidden sm:inline">{t('journal.prev')}</span>
                  </button>
                  <div className="flex items-center gap-1.5 flex-wrap justify-center" aria-hidden="true">
                    {flatEntries.map((e, i) => (
                      <button
                        key={`${e.city.id}:${e.eraId}`}
                        className={`plaque-dot ${i === detailIdx ? 'active' : ''}`}
                        onClick={() => setDetailIdx(i)}
                        tabIndex={-1}
                      />
                    ))}
                  </div>
                  <button
                    className="btn-glass py-2 px-3 text-xs"
                    onClick={() => stepDetail(1)}
                    disabled={detailIdx === flatEntries.length - 1}
                    aria-label={t('journal.next')}
                  >
                    <span className="hidden sm:inline">{t('journal.next')}</span>
                    <ChevronRight size={15} className="flip-rtl" aria-hidden="true" />
                  </button>
                </div>
                <button
                  className="btn-glass btn-accent justify-center py-2.5 text-sm w-full"
                  onClick={() => exploreEntry(detail)}
                >
                  <MapPin size={16} aria-hidden="true" />
                  {t('journal.exploreMap')}
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </main>
  );
}
