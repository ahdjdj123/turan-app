'use client';

import { useMemo, useState } from 'react';
import { Bookmark, BookmarkCheck, Map as MapIcon, ArrowLeft, Globe2, Hourglass, Star } from 'lucide-react';
import { toast } from 'sonner';
import { CITIES, type City } from '@/data/cities';
import { ERA_MAP, type EraId } from '@/data/eras';
import { useTuranStore, selectCurrentEra } from '@/lib/store';
import { useTuranLang } from './useTuranLang';
import { CityImage } from './CityImage';
import { EraGlyph, GlyphCamel, GlyphCoin, GlyphCompassRose } from './glyphs';
import { audio } from '@/lib/audio-engine';

interface Roll {
  city: City;
  eraId: EraId;
}

function pickRandom(eraFilter?: EraId): Roll {
  // build weighted pool so major cities appear a bit more often
  const pool: Roll[] = [];
  CITIES.forEach((c) => {
    (Object.keys(c.eras) as EraId[]).forEach((eraId) => {
      if (eraFilter && eraId !== eraFilter) return;
      const weight = c.major ? 2 : 1;
      for (let i = 0; i < weight; i++) pool.push({ city: c, eraId });
    });
  });
  return pool[Math.floor(Math.random() * pool.length)];
}

export function RandomDiscovery() {
  const setScreen = useTuranStore((s) => s.setScreen);
  const discover = useTuranStore((s) => s.discover);
  const openCity = useTuranStore((s) => s.openCity);
  const discovered = useTuranStore((s) => s.discovered);
  const spinCount = useTuranStore((s) => s.spinCount);
  const spinNew = useTuranStore((s) => s.spinNew);
  const recordSpin = useTuranStore((s) => s.recordSpin);
  const currentEra = useTuranStore(selectCurrentEra);
  const { t, eraLabel, eraDesc, cityName } = useTuranLang();

  const [roll, setRoll] = useState<Roll | null>(null);
  const [spinning, setSpinning] = useState(false);
  const [wheelDeg, setWheelDeg] = useState(0);
  const [scope, setScope] = useState<'all' | 'era'>('all');

  const era = roll ? ERA_MAP[roll.eraId] : null;
  const content = roll ? roll.city.eras[roll.eraId] : null;
  const rollKey = roll ? `${roll.city.id}:${roll.eraId}` : '';
  const isSaved = roll ? discovered.includes(rollKey) : false;

  const spokes = useMemo(() => Array.from({ length: 12 }, (_, i) => i * 30), []);

  const spin = () => {
    if (spinning) return;
    setSpinning(true);
    setRoll(null);
    audio.play('spin');
    const next = pickRandom(scope === 'era' ? currentEra.id : undefined);
    const turns = 3 + Math.floor(Math.random() * 3);
    setWheelDeg((d) => d + turns * 360 + Math.floor(Math.random() * 360));
    setTimeout(() => {
      setRoll(next);
      setSpinning(false);
      audio.play('discover');
      const isNew = !discovered.includes(`${next.city.id}:${next.eraId}`);
      recordSpin(isNew);
    }, 1700);
  };

  return (
    <main className="turan-root min-h-screen flex flex-col items-center px-4 py-6 pb-16">
      <header className="w-full max-w-2xl flex items-center justify-between mb-5">
        <button
          className="btn-glass py-2 px-3.5 text-sm"
          onClick={() => {
            audio.play('click');
            setScreen('menu');
          }}
        >
          <ArrowLeft size={16} className="flip-rtl" aria-hidden="true" />
          <span className="hidden sm:inline">{t('common.backToMenu')}</span>
        </button>
        <h1 className="text-xl sm:text-2xl font-bold tracking-[0.18em] uppercase text-heading inline-flex items-center gap-2.5" style={{ fontFamily: 'var(--font-display)' }}>
          <GlyphCompassRose size={20} strokeWidth={1.6} />
          {t('random.title')}
        </h1>
        <div className="w-[104px] hidden sm:block" />
      </header>

      <p className="text-subtle text-sm text-center max-w-md mb-3">{t('random.subtitle')}</p>

      {/* visitor spin stats */}
      {spinCount > 0 && (
        <div className="flex items-center justify-center gap-2 mb-4 spin-stats">
          <span className="stat-chip">
            <GlyphCompassRose size={12} strokeWidth={1.8} />
            {t('random.spins')}: <b className="tabular-nums">{spinCount}</b>
          </span>
          <span className="stat-chip" style={{ borderColor: 'var(--t-accent)' }}>
            <Star size={12} aria-hidden="true" />
            {t('random.newFinds')}: <b className="tabular-nums">{spinNew}</b>
          </span>
        </div>
      )}

      {/* spin scope segmented control */}
      {!roll && (
        <div className="flex flex-col items-center gap-2 mb-2" role="group" aria-label={t('random.scope')}>
          <span className="text-[10px] tracking-[0.24em] uppercase text-subtle font-semibold">{t('random.scope')}</span>
          <div className="spin-scope" role="radiogroup" aria-label={t('random.scope')}>
            <button
              role="radio"
              aria-checked={scope === 'all'}
              className={scope === 'all' ? 'active' : ''}
              onClick={() => {
                audio.play('click');
                setScope('all');
              }}
            >
              <Globe2 size={14} aria-hidden="true" />
              {t('random.scopeAll')}
            </button>
            <button
              role="radio"
              aria-checked={scope === 'era'}
              className={scope === 'era' ? 'active' : ''}
              style={
                scope === 'era'
                  ? { borderColor: currentEra.color, boxShadow: `0 0 14px ${currentEra.color}55`, color: currentEra.color }
                  : undefined
              }
              onClick={() => {
                audio.play('click');
                setScope('era');
              }}
            >
              <Hourglass size={14} aria-hidden="true" />
              <span aria-hidden="true"><EraGlyph eraId={currentEra.id} size={12} strokeWidth={1.9} /></span> {t('random.scopeEra')}
              <span className="scope-era-name">· {eraLabel(currentEra.id)}</span>
            </button>
          </div>
        </div>
      )}

      {/* spinning compass */}
      {!roll && (
        <div className="flex flex-col items-center gap-6 mt-8">
          <div className="spin-wheel spin-wheel-idle rounded-full" style={{ transform: `rotate(${wheelDeg}deg)`, transitionDuration: '1.7s' }}>
            <svg width="170" height="170" viewBox="0 0 170 170" aria-hidden="true">
              <circle cx="85" cy="85" r="80" fill="none" stroke="var(--t-accent)" strokeWidth="3" />
              <circle cx="85" cy="85" r="70" fill="none" stroke="var(--t-accent)" strokeWidth="1" opacity="0.5" />
              {spokes.map((a) => (
                <line key={a} x1="85" y1="85" x2="85" y2="12" stroke="var(--t-accent)" strokeWidth="1.4" opacity="0.55" transform={`rotate(${a} 85 85)`} />
              ))}
              <polygon points="85,20 92,45 78,45" fill="var(--t-accent)" />
              <polygon points="85,150 92,125 78,125" fill="#7d6a3f" />
              <circle cx="85" cy="85" r="9" fill="var(--t-accent)" opacity="0.9" />
              <circle cx="85" cy="85" r="4" fill="#fff2cf" />
            </svg>
          </div>
          <button className="btn-glass btn-accent text-base" onClick={spin} disabled={spinning}>
            <GlyphCamel size={20} strokeWidth={1.7} />
            {spinning ? '…' : t('random.spin')}
          </button>
          <p className="text-subtle text-xs italic">
            {scope === 'all' ? t('random.hint') : t('random.hintEra')}
          </p>
        </div>
      )}

      {/* reveal card — unrolls like a historical scroll */}
      {roll && era && content && (
        <div className="scroll-reveal ornate w-full max-w-2xl glass-strong overflow-hidden">
          <div className="relative h-56 sm:h-72">
            <CityImage
              cityId={roll.city.id}
              eraId={roll.eraId}
              cityName={roll.city.name}
              eraLabel={eraLabel(roll.eraId)}
              className="w-full h-full"
            />
            <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, var(--t-panel-solid) 3%, transparent 60%)' }} aria-hidden="true" />
            <div className="absolute bottom-3 left-5 right-5">
              <span
                className="inline-flex items-center gap-1.5 text-[10px] tracking-[0.22em] uppercase px-2.5 py-1 rounded-full mb-2"
                style={{ background: `${era.color}33`, border: `1px solid ${era.color}` }}
              >
                <EraGlyph eraId={roll.eraId} size={11} strokeWidth={2} />
                {eraLabel(roll.eraId)}
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold text-heading tracking-wide" style={{ fontFamily: 'var(--font-display)' }}>
                {cityName(roll.city.name, roll.city.names)}
              </h2>
              <p className="italic text-sm mt-1" style={{ color: 'var(--t-accent)' }}>
                “{content.tagline}”
              </p>
            </div>
          </div>

          <div className="p-5 sm:p-6">
            <p className="text-sm leading-relaxed">{content.description}</p>

            <div className="glass mt-4 p-3.5 flex gap-3 items-start" style={{ borderRadius: 12 }}>
              <span className="mt-0.5 shrink-0" style={{ color: 'var(--t-accent)' }} aria-hidden="true">
                <GlyphCoin size={17} strokeWidth={1.6} />
              </span>
              <div>
                <div className="text-[11px] tracking-[0.2em] uppercase font-semibold" style={{ color: 'var(--t-accent)' }}>
                  {t('popup.didYouKnow')}
                </div>
                <p className="text-sm mt-1 leading-relaxed">{content.fact}</p>
              </div>
            </div>

            <p className="text-[11px] text-subtle mt-3 tracking-wide uppercase">{eraDesc(roll.eraId)}</p>

            <div className="flex flex-wrap gap-2.5 mt-5">
              <button className="btn-glass flex-1 justify-center text-sm" onClick={spin}>
                <GlyphCompassRose size={17} strokeWidth={1.7} />
                {t('random.again')}
              </button>
              <button
                className="btn-glass flex-1 justify-center text-sm"
                disabled={isSaved}
                onClick={() => {
                  const isNew = discover(roll.city.id, roll.eraId);
                  if (isNew) {
                    audio.play('discover');
                    toast.success(t('toast.journalSaved'), {
                      description: `${cityName(roll.city.name, roll.city.names)} · ${eraLabel(roll.eraId)}`,
                    });
                  } else {
                    toast.info(t('toast.alreadySaved'));
                  }
                }}
              >
                {isSaved ? <BookmarkCheck size={17} aria-hidden="true" /> : <Bookmark size={17} aria-hidden="true" />}
                {isSaved ? t('random.saved') : t('random.save')}
              </button>
              <button
                className="btn-glass btn-accent flex-1 justify-center text-sm"
                onClick={() => {
                  audio.play('click');
                  openCity(roll.city.id, roll.eraId, true);
                  setScreen('map');
                }}
              >
                <MapIcon size={17} aria-hidden="true" />
                {t('random.explore')}
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
