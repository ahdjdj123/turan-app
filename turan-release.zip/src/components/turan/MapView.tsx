'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowLeft, Plus, Minus, LocateFixed, BookOpen, ScrollText, Search, Landmark as LandmarkIcon, Sparkles } from 'lucide-react';
import { CITIES, CITY_MAP, type City } from '@/data/cities';
import { ERA_MAP, ERAS as ERAS_LIST, type EraId } from '@/data/eras';
import { useTuranStore } from '@/lib/store';
import { useUIStore } from '@/lib/ui-store';
import { useTuranLang } from './useTuranLang';
import { MapCanvas } from './MapCanvas';
import { CityExperience } from './CityExperience';
import { Compass } from './Compass';
import { TimelineBar } from './TimelineBar';
import { MapLegend } from './MapLegend';
import { EraGlyph } from './glyphs';
import { formatFounded, type FoundedLabels } from '@/lib/turan-utils';
import { MAP_W as PLATE_W, MAP_H as PLATE_H, ATLAS_OX as OX, ATLAS_OY as OY } from '@/data/geo';
import { audio } from '@/lib/audio-engine';

/* world canvas keeps the exact projection ratio (×2.5), surrounded by an atlas margin */
const VB_W = PLATE_W + OX * 2; /* 1480 viewBox units across */
const VB_H = PLATE_H + OY * 2; /* 1020 viewBox units tall */
const WORLD_W = 2500;
const WORLD_H = Math.round((WORLD_W * VB_H) / VB_W);
/** the country plate's width measured in world-canvas px */
const PLATE_W_PX = WORLD_W * (PLATE_W / VB_W);

/** plate % (0–100 of the country plate) → world-canvas px */
function plateToWorld(pctX: number, pctY: number) {
  const k = WORLD_W / VB_W;
  return { wx: ((pctX / 100) * PLATE_W + OX) * k, wy: ((pctY / 100) * PLATE_H + OY) * k };
}

interface View {
  x: number;
  y: number;
  scale: number;
}

function clampScale(scale: number, vw: number, vh: number): number {
  // contain: the whole country always visible, like a plate on a table
  const min = Math.min(vw / WORLD_W, vh / WORLD_H) * 0.98;
  return Math.min(4.5, Math.max(min, scale));
}

function clampView(v: View, vw: number, vh: number): View {
  const minX = vw - WORLD_W * v.scale;
  const minY = vh - WORLD_H * v.scale;
  const x = minX > 0 ? minX / 2 : Math.max(minX, Math.min(0, v.x));
  const y = minY > 0 ? minY / 2 : Math.max(minY, Math.min(0, v.y));
  return { scale: v.scale, x, y };
}

export function MapView() {
  const year = useTuranStore((s) => s.year);
  const setYear = useTuranStore((s) => s.setYear);
  const setScreen = useTuranStore((s) => s.setScreen);
  const discover = useTuranStore((s) => s.discover);
  const discovered = useTuranStore((s) => s.discovered);
  const pendingFocus = useTuranStore((s) => s.pendingFocus);
  const consumeFocus = useTuranStore((s) => s.consumeFocus);
  const showCompass = useTuranStore((s) => s.settings.showCompass);
  const showProgress = useTuranStore((s) => s.settings.showProgress);
  const discoveredCount = useTuranStore((s) => s.discovered.length);
  const legendOpen = useUIStore((s) => s.legendOpen);
  const toggleLegend = useUIStore((s) => s.toggleLegend);
  const { t, eraLabel, cityName, lang } = useTuranLang();
  const foundedLabels: FoundedLabels = {
    bce: t('common.bce'), ce: t('common.ce'), ancient: t('founding.ancient'),
    centuryBce: t('founding.centuryBce'), centuryCe: t('founding.centuryCe'),
    millenniumBce: t('founding.millenniumBce'), modern: t('founding.modern'), recorded: t('founding.recorded'),
  };

  const viewportRef = useRef<HTMLDivElement>(null);
  const worldRef = useRef<HTMLDivElement>(null);
  const tweenTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [view, setView] = useState<View>({ x: 0, y: 0, scale: 1 });
  const [dragging, setDragging] = useState(false);
  const [compassRot, setCompassRot] = useState(0);
  const [hovered, setHovered] = useState<City | null>(null);
  const [openCity, setOpenCity] = useState<{ cityId: string; eraId: EraId } | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [activeIdx, setActiveIdx] = useState(0);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const era = useMemo(() => ERAS_LIST.find((e) => year <= e.endYear) ?? ERAS_LIST[ERAS_LIST.length - 1], [year]);

  /* initial fit — portrait phones: the plate fills the width like Apple Maps */
  useEffect(() => {
    const el = viewportRef.current;
    if (!el) return;
    const fit = () => {
      const vw = el.clientWidth;
      const vh = el.clientHeight;
      const portrait = vh > vw * 1.05;
      const scale = clampScale(
        portrait ? (vw / PLATE_W_PX) * 1.16 : Math.min(vw / WORLD_W, vh / WORLD_H) * 0.99,
        vw,
        vh
      );
      setView(clampView({ x: (vw - WORLD_W * scale) / 2, y: (vh - WORLD_H * scale) / 2, scale }, vw, vh));
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);

  /* era whoosh (audio only — visuals change through overlay opacity) */
  const prevEraRef = useRef(era.id);
  useEffect(() => {
    if (prevEraRef.current !== era.id) {
      prevEraRef.current = era.id;
      audio.play('era');
    }
  }, [era.id]);

  /* camera: animated fly-to (transform transition, GPU-friendly) */
  const flyTo = useCallback((target: View) => {
    const el = viewportRef.current;
    const world = worldRef.current;
    if (!el) return;
    const v = clampView(target, el.clientWidth, el.clientHeight);
    if (world) {
      world.classList.add('tween');
      if (tweenTimer.current) clearTimeout(tweenTimer.current);
      tweenTimer.current = setTimeout(() => world.classList.remove('tween'), 700);
    }
    setView(v);
  }, []);

  /* external focus requests (deep links, random discovery, journal CTA) */
  useEffect(() => {
    if (pendingFocus) {
      const f = consumeFocus();
      if (f && CITY_MAP[f.cityId]?.eras[f.eraId]) {
        const target = ERA_MAP[f.eraId];
        setYear(Math.round((target.startYear + target.endYear) / 2));
        setOpenCity({ cityId: f.cityId, eraId: f.eraId });
        flyToView(f.cityId, true);
      }
    }
     
  }, [pendingFocus, consumeFocus, setYear]);

  /* keep the URL shareable while the experience is open */
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (openCity && CITY_MAP[openCity.cityId]?.eras[openCity.eraId]) {
      window.history.replaceState(null, '', `/?city=${openCity.cityId}&era=${openCity.eraId}`);
    } else {
      window.history.replaceState(null, '', window.location.pathname);
    }
  }, [openCity]);

  const eraCities = useMemo(() => CITIES.filter((c) => c.eras[era.id]), [era.id]);

  /* ---- marker clustering: nearby cities collapse into a badge when the
         camera is far out so labels never collide on a phone ---- */
  const markerGroups = useMemo(() => {
    const inv = 1 / view.scale;
    const effInv = Math.min(Math.max(inv, 0.55), 1.15);
    const pts = eraCities.map((city) => {
      const { wx, wy } = plateToWorld(city.x, city.y);
      return { city, wx, wy, sx: wx * view.scale + view.x, sy: wy * view.scale + view.y };
    });
    if (view.scale >= 1.05) {
      return pts.map((p) => ({ kind: 'city' as const, city: p.city, effInv }));
    }
    const TH = 26; /* screen px between marker centers */
    const groups: (
      | { kind: 'city'; city: City; effInv: number }
      | { kind: 'cluster'; members: City[]; xPct: number; yPct: number; label: string; effInv: number }
    )[] = [];
    const used = new Set<number>();
    for (let i = 0; i < pts.length; i++) {
      if (used.has(i)) continue;
      /* major cities always keep their own marker — they are the hooks */
      if (pts[i].city.major) {
        used.add(i);
        groups.push({ kind: 'city', city: pts[i].city, effInv });
        continue;
      }
      const members = [pts[i]];
      used.add(i);
      for (let j = i + 1; j < pts.length; j++) {
        if (used.has(j) || pts[j].city.major) continue;
        if (Math.hypot(pts[j].sx - pts[i].sx, pts[j].sy - pts[i].sy) < TH) {
          members.push(pts[j]);
          used.add(j);
        }
      }
      if (members.length === 1) {
        groups.push({ kind: 'city', city: pts[i].city, effInv });
      } else {
        const cx = members.reduce((a, m) => a + m.wx, 0) / members.length;
        const cy = members.reduce((a, m) => a + m.wy, 0) / members.length;
        groups.push({
          kind: 'cluster',
          members: members.map((m) => m.city),
          xPct: (cx / WORLD_W) * 100,
          yPct: (cy / WORLD_H) * 100,
          label: members[0].city.name,
          effInv,
        });
      }
    }
    return groups;
  }, [view.x, view.y, view.scale, eraCities]);

  const flyToView = useCallback(
    (cityId: string, panelSide = false) => {
      const city = CITY_MAP[cityId];
      const el = viewportRef.current;
      if (!city || !el) return;
      const vw = el.clientWidth;
      const vh = el.clientHeight;
      const { wx, wy } = plateToWorld(city.x, city.y);
      const scale = clampScale(Math.max(vw, vh) / 760, vw, vh);
      const desktop = vw >= 1024 && panelSide;
      const fx = desktop ? vw * 0.68 : vw / 2;
      const fy = vh * 0.46;
      flyTo({ x: fx - wx * scale, y: fy - wy * scale, scale });
    },
    [flyTo]
  );

  /* ------------------------- archive search ------------------------- */
  const searchIndex = useMemo(
    () =>
      CITIES.flatMap((city) =>
        (Object.keys(city.eras) as EraId[]).map((eraId) => ({
          city,
          eraId,
          hay: `${city.name} ${Object.values(city.names).join(' ')} ${eraId}`.toLowerCase(),
        }))
      ),
    []
  );

  const searchResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) {
      const majors = searchIndex.filter((e) => e.city.major);
      const seen = new Set<string>();
      const out: typeof searchIndex = [];
      for (const entry of majors) {
        if (seen.has(entry.city.id)) continue;
        seen.add(entry.city.id);
        out.push(entry);
        if (out.length >= 8) break;
      }
      return out;
    }
    return searchIndex.filter((e) => e.hay.includes(q)).slice(0, 12);
  }, [query, searchIndex]);

  useEffect(() => setActiveIdx(0), [query]);
  useEffect(() => {
    if (searchOpen) searchInputRef.current?.focus();
  }, [searchOpen]);

  const pickSearchResult = useCallback(
    (i: number) => {
      const r = searchResults[i];
      if (!r) return;
      audio.play('click');
      setSearchOpen(false);
      setQuery('');
      const target = ERA_MAP[r.eraId];
      setYear(Math.round((target.startYear + target.endYear) / 2));
      setOpenCity({ cityId: r.city.id, eraId: r.eraId });
      flyToView(r.city.id, true);
    },
    [searchResults, flyToView, setYear]
  );

  /* ------------------------- interactions ------------------------- */
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const pinchStart = useRef<{ dist: number; scale: number; cx: number; cy: number; vx: number; vy: number } | null>(null);
  const dragStart = useRef<{ px: number; py: number; vx: number; vy: number } | null>(null);
  const movedRef = useRef(false);
  const lastTap = useRef<{ t: number; x: number; y: number } | null>(null);

  const handleTapEnd = (clientX: number, clientY: number) => {
    const now = Date.now();
    const lt = lastTap.current;
    if (lt && now - lt.t < 320 && Math.hypot(clientX - lt.x, clientY - lt.y) < 36) {
      lastTap.current = null;
      zoomAt(clientX, clientY, 1.8);
      audio.play('click');
    } else {
      lastTap.current = { t: now, x: clientX, y: clientY };
    }
  };

  const onDoubleClick = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('.city-marker, .map-search, [data-city-popup], .timeline-bar')) return;
    e.preventDefault();
    zoomAt(e.clientX, e.clientY, 1.8);
    audio.play('click');
  };

  const onPointerDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest('.city-marker')) return;
    const el = viewportRef.current;
    if (!el) return;
    worldRef.current?.classList.remove('tween');
    el.setPointerCapture(e.pointerId);
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    movedRef.current = false;

    if (pointers.current.size === 1) {
      setDragging(true);
      dragStart.current = { px: e.clientX, py: e.clientY, vx: view.x, vy: view.y };
    } else if (pointers.current.size === 2) {
      const pts = [...pointers.current.values()];
      const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      pinchStart.current = { dist, scale: view.scale, cx: (pts[0].x + pts[1].x) / 2, cy: (pts[0].y + pts[1].y) / 2, vx: view.x, vy: view.y };
      dragStart.current = null;
    }
  };

  const onPointerMove = (e: React.PointerEvent) => {
    const el = viewportRef.current;
    if (!el || !pointers.current.has(e.pointerId)) return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const vw = el.clientWidth;
    const vh = el.clientHeight;

    if (pointers.current.size === 2 && pinchStart.current) {
      const pts = [...pointers.current.values()];
      const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      const p = pinchStart.current;
      const scale = clampScale(p.scale * (dist / Math.max(1, p.dist)), vw, vh);
      const ratio = scale / p.scale;
      const nx = p.cx - (p.cx - p.vx) * ratio;
      const ny = p.cy - (p.cy - p.vy) * ratio;
      setView(clampView({ x: nx, y: ny, scale }, vw, vh));
      movedRef.current = true;
      return;
    }

    if (pointers.current.size === 1 && dragStart.current) {
      const dx = e.clientX - dragStart.current.px;
      const dy = e.clientY - dragStart.current.py;
      if (Math.abs(dx) + Math.abs(dy) > 4) movedRef.current = true;
      setView(clampView({ x: dragStart.current.vx + dx, y: dragStart.current.vy + dy, scale: view.scale }, vw, vh));
      if (dx !== 0 || dy !== 0) {
        const target = (Math.atan2(dy, dx) * 180) / Math.PI + 90;
        setCompassRot((r) => r + (target - r) * 0.35);
      }
    }
  };

  const endPointer = (e: React.PointerEvent) => {
    pointers.current.delete(e.pointerId);
    if (pointers.current.size < 2) pinchStart.current = null;
    if (pointers.current.size === 0) {
      setDragging(false);
      dragStart.current = null;
      if (e.pointerType === 'touch' && !movedRef.current) handleTapEnd(e.clientX, e.clientY);
    }
  };

  const zoomAt = useCallback(
    (clientX: number, clientY: number, factor: number) => {
      const el = viewportRef.current;
      if (!el) return;
      const vw = el.clientWidth;
      const vh = el.clientHeight;
      const rect = el.getBoundingClientRect();
      const cx = clientX - rect.left;
      const cy = clientY - rect.top;
      setView((v) => {
        const scale = clampScale(v.scale * factor, vw, vh);
        const ratio = scale / v.scale;
        return clampView({ x: cx - (cx - v.x) * ratio, y: cy - (cy - v.y) * ratio, scale }, vw, vh);
      });
    },
    []
  );

  useEffect(() => {
    const el = viewportRef.current;
    if (!el) return;
    const handler = (e: WheelEvent) => {
      e.preventDefault();
      zoomAt(e.clientX, e.clientY, Math.exp(-e.deltaY * 0.0016));
    };
    el.addEventListener('wheel', handler, { passive: false });
    return () => el.removeEventListener('wheel', handler);
  }, [zoomAt]);

  const resetView = useCallback(() => {
    const el = viewportRef.current;
    if (!el) return;
    const vw = el.clientWidth;
    const vh = el.clientHeight;
    const portrait = vh > vw * 1.05;
    const scale = clampScale(
      portrait ? (vw / PLATE_W_PX) * 1.16 : Math.min(vw / WORLD_W, vh / WORLD_H) * 0.99,
      vw,
      vh
    );
    flyTo({ x: (vw - WORLD_W * scale) / 2, y: (vh - WORLD_H * scale) / 2, scale });
    audio.play('click');
  }, [flyTo]);

  const openMarker = (city: City) => {
    if (movedRef.current) return;
    audio.play('click');
    discover(city.id, era.id);
    setOpenCity({ cityId: city.id, eraId: era.id });
    setHovered(null);
    flyToView(city.id, true);
  };

  const switchCity = useCallback(
    (cityId: string, eraId: EraId) => {
      setOpenCity({ cityId, eraId });
      flyToView(cityId, true);
    },
    [flyToView]
  );

  const onKeyDown = (e: React.KeyboardEvent) => {
    const el = viewportRef.current;
    if (!el) return;
    const step = 80;
    setView((v) => {
      let { x, y } = v;
      if (e.key === 'ArrowLeft') x += step;
      if (e.key === 'ArrowRight') x -= step;
      if (e.key === 'ArrowUp') y += step;
      if (e.key === 'ArrowDown') y -= step;
      if (e.key === '+' || e.key === '=') return clampView({ ...v, scale: clampScale(v.scale * 1.2, el.clientWidth, el.clientHeight) }, el.clientWidth, el.clientHeight);
      if (e.key === '-') return clampView({ ...v, scale: clampScale(v.scale / 1.2, el.clientWidth, el.clientHeight) }, el.clientWidth, el.clientHeight);
      return clampView({ ...v, x, y }, el.clientWidth, el.clientHeight);
    });
  };

  const experienceCity = openCity ? CITY_MAP[openCity.cityId] : null;

  return (
    <div className="turan-root fixed inset-0">
      {/* map viewport */}
      <div
        ref={viewportRef}
        className={`map-viewport ${dragging ? 'dragging' : ''}`}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endPointer}
        onPointerCancel={endPointer}
        onDoubleClick={onDoubleClick}
        onKeyDown={onKeyDown}
        tabIndex={0}
        role="application"
        aria-label={t('map.hint')}
      >
        <div className={`map-depth ${openCity ? 'map-depth-open' : ''}`} aria-hidden="false">
          <div
            ref={worldRef}
            className="map-world"
            style={{
              width: WORLD_W,
              height: WORLD_H,
              transform: `translate3d(${view.x}px, ${view.y}px, 0) scale(${view.scale})`,
            }}
          >
          <MapCanvas
            eraId={era.id}
            labels={{
              aral: t('geo.aral'),
              amuDarya: t('geo.amuDarya'),
              syrDarya: t('geo.syrDarya'),
              zarafshan: t('geo.zarafshan'),
            }}
            focus={openCity ? { x: CITY_MAP[openCity.cityId].x, y: CITY_MAP[openCity.cityId].y } : null}
          />

          {/* city markers — pins, glowing when selected, clustered far out */}
          <div key={era.id}>
            {markerGroups.map((g, i) => {
              if (g.kind === 'cluster') {
                const eff = g.effInv;
                const size = Math.max(34, 42 * eff);
                return (
                  <button
                    key={`cl-${era.id}-${g.label}`}
                    className="marker-cluster"
                    style={{
                      left: `${g.xPct}%`,
                      top: `${g.yPct}%`,
                      width: size,
                      height: size,
                      ['--marker-color' as string]: era.color,
                      ['--i' as string]: i,
                    }}
                    onClick={() => {
                      audio.play('click');
                      flyToView(g.members[0].id, false);
                    }}
                    aria-label={`${g.label} +${g.members.length - 1}`}
                  >
                    <span className="cluster-count tabular-nums">{g.members.length}</span>
                    <span className="marker-label" style={{ fontSize: 10.5 * eff, top: size / 2 + 5 * eff }}>
                      {g.label} +{g.members.length - 1}
                    </span>
                  </button>
                );
              }
              const city = g.city;
              const effInv = g.effInv;
              const hit = (city.major ? 40 : 30) * effInv;
              const isHovered = hovered?.id === city.id;
              const isSelected = openCity?.cityId === city.id;
              const pos = plateToWorld(city.x, city.y);
              return (
                <button
                  key={`${era.id}-${city.id}`}
                  className={`city-marker ${city.major ? 'major' : ''} ${discovered.includes(`${city.id}:${era.id}`) ? 'visited' : ''} ${isSelected ? 'selected' : ''}`}
                  style={{
                    left: `${(pos.wx / WORLD_W) * 100}%`,
                    top: `${(pos.wy / WORLD_H) * 100}%`,
                    width: hit,
                    height: hit,
                    ['--marker-color' as string]: era.color,
                    ['--i' as string]: i,
                  }}
                  onClick={() => openMarker(city)}
                  onMouseEnter={() => {
                    setHovered(city);
                    audio.play('hover');
                  }}
                  onMouseLeave={() => setHovered((h) => (h === city ? null : h))}
                  onFocus={() => setHovered(city)}
                  onBlur={() => setHovered((h) => (h === city ? null : h))}
                  aria-label={`${cityName(city.name, city.names)} — ${eraLabel(era.id)}`}
                >
                  <span
                    className="marker-pin"
                    style={{ ['--pin-size' as string]: (city.major ? 22 : 17) * effInv }}
                    aria-hidden="true"
                  >
                    <span className="marker-pin-icon" style={{ fontSize: (city.major ? 12 : 9) * effInv }}>
                      <EraGlyph eraId={era.id} size={(city.major ? 11 : 8.5) * effInv} strokeWidth={2.4} />
                    </span>
                  </span>
                  <span
                    className="marker-label"
                    style={{
                      fontSize: (city.major ? 13 : 10.5) * effInv,
                      top: hit / 2 + 6 * effInv,
                    }}
                  >
                    {cityName(city.name, city.names)}
                  </span>
                  {isHovered && (
                    <span
                      className="marker-sublabel"
                      style={{ fontSize: 9.5 * effInv, top: hit / 2 + 6 * effInv + (city.major ? 19 : 15) * effInv }}
                    >
                      {eraLabel(era.id)} · {t('map.founded')} {formatFounded(city.founded, lang, foundedLabels)}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
          </div>
        </div>
      </div>

      {/* paper grain + drifting dust — the plate rests on aged paper (viewport-fixed) */}
      <div className="map-atmosphere" aria-hidden="true" />

      {/* floating search pill (mobile, thumb-reachable) */}
      <button
        className="floating-search md:hidden"
        onClick={() => { audio.play('click'); setSearchOpen(true); }}
        aria-label={t('map.searchTitle')}
      >
        <Search size={14} aria-hidden="true" />
        <span className="truncate">{t('map.search')}</span>
      </button>

      {/* top bar: minimal — back, wordmark, tools */}
      <div className="fixed top-0 inset-x-0 z-40 flex items-center justify-between gap-3 p-3 pointer-events-none">
        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            className="btn-glass py-2 px-3.5 text-sm"
            onClick={() => {
              audio.play('click');
              setScreen('menu');
            }}
          >
            <ArrowLeft size={16} className="flip-rtl" aria-hidden="true" />
            <span className="hidden sm:inline">{t('common.backToMenu')}</span>
          </button>
        </div>
        <div className="hidden md:flex items-center gap-2 pointer-events-auto">
          <button
            className="btn-glass py-2 px-3 text-sm relative"
            onClick={() => {
              audio.play('click');
              setScreen('random');
            }}
            aria-label={t('menu.random')}
            title={t('menu.random')}
          >
            <Sparkles size={16} aria-hidden="true" />
          </button>
          <button
            className="btn-glass py-2 px-3 text-sm relative"
            onClick={() => {
              audio.play('click');
              setScreen('journal');
            }}
            aria-label={t('journal.open')}
            title={t('journal.open')}
          >
            <BookOpen size={16} aria-hidden="true" />
            <span
              className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 rounded-full text-[10px] font-bold grid place-items-center"
              style={{ background: 'var(--t-accent)', color: '#14102a' }}
            >
              {discoveredCount}
            </span>
          </button>
          <button
            className={`btn-glass py-2 px-3 text-sm ${searchOpen ? 'btn-accent' : ''}`}
            onClick={() => {
              audio.play('click');
              setSearchOpen((o) => !o);
              if (searchOpen) setQuery('');
            }}
            aria-label={t('map.searchTitle')}
            title={t('map.searchTitle')}
            aria-pressed={searchOpen}
            aria-expanded={searchOpen}
          >
            <Search size={16} aria-hidden="true" />
          </button>
          <button
            className={`btn-glass py-2 px-3 text-sm ${legendOpen ? 'btn-accent' : ''}`}
            onClick={() => {
              audio.play('click');
              toggleLegend();
            }}
            aria-label={t('legend.title')}
            title={t('legend.title')}
            aria-pressed={legendOpen}
          >
            <ScrollText size={16} aria-hidden="true" />
          </button>
          <div className="glass px-3 py-2 text-xs flex items-center gap-1.5" style={{ color: era.color }}>
            <EraGlyph eraId={era.id} size={13} strokeWidth={1.8} />
            <span className="tracking-[0.14em] uppercase">{eraLabel(era.id)}</span>
          </div>
        </div>
      </div>

      {/* mobile compact toolbar */}
      <div className="map-mobile-tools md:hidden">
        <button
          className="btn-glass py-2 px-3 text-sm relative"
          onClick={() => { audio.play('click'); setScreen('random'); }}
          aria-label={t('menu.random')}
        >
          <Sparkles size={16} aria-hidden="true" />
        </button>
        <button
          className="btn-glass py-2 px-3 text-sm relative"
          onClick={() => { audio.play('click'); setScreen('journal'); }}
          aria-label={t('journal.open')}
        >
          <BookOpen size={16} aria-hidden="true" />
          <span
            className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 rounded-full text-[10px] font-bold grid place-items-center"
            style={{ background: 'var(--t-accent)', color: '#14102a' }}
          >
            {discoveredCount}
          </span>
        </button>
        <button
          className={`btn-glass py-2 px-3 text-sm ${legendOpen ? 'btn-accent' : ''}`}
          onClick={() => { audio.play('click'); toggleLegend(); }}
          aria-label={t('legend.title')}
        >
          <ScrollText size={16} aria-hidden="true" />
        </button>
      </div>

      {/* archive search panel */}
      {searchOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setSearchOpen(false)} aria-hidden="true" />
          <div className="map-search glass-strong ornate" role="dialog" aria-label={t('map.searchTitle')} data-map-search="open">
            <div className="flex items-center gap-2 px-3.5 py-3 shrink-0" style={{ borderBottom: '1px solid var(--t-glass-border)' }}>
              <Search size={15} style={{ color: 'var(--t-accent)', flexShrink: 0 }} aria-hidden="true" />
              <input
                ref={searchInputRef}
                className="flex-1 min-w-0 bg-transparent outline-none text-sm placeholder:text-subtle"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  e.stopPropagation();
                  if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    setActiveIdx((i) => Math.min(i + 1, searchResults.length - 1));
                  } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    setActiveIdx((i) => Math.max(i - 1, 0));
                  } else if (e.key === 'Enter') {
                    e.preventDefault();
                    pickSearchResult(activeIdx);
                  } else if (e.key === 'Escape') {
                    e.preventDefault();
                    setSearchOpen(false);
                    setQuery('');
                  }
                }}
                placeholder={t('map.search')}
                aria-label={t('map.searchTitle')}
                role="combobox"
                aria-expanded="true"
                aria-controls="turan-search-list"
                aria-activedescendant={searchResults[activeIdx] ? `turan-search-opt-${activeIdx}` : undefined}
                autoComplete="off"
                spellCheck={false}
              />
            </div>
            <div id="turan-search-list" className="turan-scroll overflow-y-auto max-h-96 p-1.5" role="listbox">
              {searchResults.map((r, i) => {
                const e2 = ERA_MAP[r.eraId];
                const visited = discovered.includes(`${r.city.id}:${r.eraId}`);
                return (
                  <button
                    key={`${r.city.id}:${r.eraId}`}
                    id={`turan-search-opt-${i}`}
                    role="option"
                    aria-selected={i === activeIdx}
                    className={`search-row ${i === activeIdx ? 'active' : ''}`}
                    style={{ ['--row-era' as string]: e2.color }}
                    onMouseEnter={() => setActiveIdx(i)}
                    onClick={() => pickSearchResult(i)}
                  >
                    <LandmarkIcon size={14} className="shrink-0" style={{ color: e2.color }} aria-hidden="true" />
                    <span className="flex-1 min-w-0 text-start">
                      <span className="block text-sm font-semibold truncate">{cityName(r.city.name, r.city.names)}</span>
                      <span className="block text-[10px] tracking-[0.14em] uppercase text-subtle">
                        <EraGlyph eraId={r.eraId} size={11} strokeWidth={2} /> {eraLabel(r.eraId)} · {t('map.founded')} {formatFounded(r.city.founded, lang, foundedLabels)}
                      </span>
                    </span>
                    {visited && (
                      <span className="shrink-0 text-[10px] font-bold" style={{ color: 'var(--t-accent)' }} aria-label="✓">
                        ✓
                      </span>
                    )}
                  </button>
                );
              })}
              {searchResults.length === 0 && (
                <div className="px-4 py-7 text-center text-sm text-subtle">{t('map.searchEmpty')}</div>
              )}
            </div>
          </div>
        </>
      )}

      {/* map legend */}
      {legendOpen && <MapLegend />}

      {/* zoom controls */}
      <div className="fixed left-3 bottom-32 md:bottom-40 z-30 flex flex-col gap-2">
        <button className="btn-glass zoom-btn" onClick={() => zoomAtInner(1.3)} aria-label={t('map.zoomIn')}>
          <Plus size={17} />
        </button>
        <button className="btn-glass zoom-btn" onClick={() => zoomAtInner(1 / 1.3)} aria-label={t('map.zoomOut')}>
          <Minus size={17} />
        </button>
        <button className="btn-glass zoom-btn" onClick={resetView} aria-label={t('map.reset')}>
          <LocateFixed size={17} />
        </button>
      </div>

      {/* compass */}
      {showCompass && <Compass rotation={compassRot} eraId={era.id} onReset={resetView} />}

      {/* timeline */}
      {showProgress && <TimelineBar />}

      {/* city exhibition */}
      {experienceCity && openCity && (
        <CityExperience
          key={`${openCity.cityId}:${openCity.eraId}`}
          city={experienceCity}
          eraId={openCity.eraId}
          onClose={() => setOpenCity(null)}
          onSwitchCity={switchCity}
        />
      )}
    </div>
  );

  function zoomAtInner(factor: number) {
    const el = viewportRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    zoomAt(rect.left + rect.width / 2, rect.top + rect.height / 2, factor);
    audio.play('click');
  }
}
