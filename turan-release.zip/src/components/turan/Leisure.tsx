'use client';

import { useState } from 'react';
import { ArrowLeft, Bell, Hourglass } from 'lucide-react';
import { toast } from 'sonner';
import { useTuranStore } from '@/lib/store';
import { useTuranLang } from './useTuranLang';
import { EraTrial } from './Quiz';
import { CaravanMemory } from './CaravanMemory';
import { audio } from '@/lib/audio-engine';

export function Leisure() {
  const setScreen = useTuranStore((s) => s.setScreen);
  const { t } = useTuranLang();
  const [email, setEmail] = useState('');
  const [notified, setNotified] = useState(false);

  return (
    <main className="turan-root min-h-screen flex flex-col items-center px-4 py-6 pb-14">
      <header className="w-full max-w-2xl flex items-center justify-between mb-6">
        <button
          className="btn-glass py-2 px-3.5 text-sm"
          onClick={() => {
            audio.play('click');
            setScreen('menu');
          }}
        >
          <ArrowLeft size={16} className="flip-rtl" aria-hidden="true" />
          <span className="hidden sm:inline">{t('common.backToMenu')}</span>
        </button>
        <h1 className="text-xl sm:text-2xl font-bold tracking-[0.18em] uppercase text-heading" style={{ fontFamily: 'var(--font-display)' }}>
          🎮 {t('leisure.title')}
        </h1>
        <div className="w-[104px] hidden sm:block" />
      </header>

      {/* playable games */}
      <section className="w-full max-w-5xl grid lg:grid-cols-2 gap-5 items-start">
        <div className="slide-up-panel ornate w-full glass-strong p-6 sm:p-8">
          <EraTrial />
        </div>
        <div className="slide-up-panel ornate w-full glass-strong p-6 sm:p-8" style={{ animationDelay: '0.12s' }}>
          <CaravanMemory />
        </div>
      </section>

      {/* what's next */}
      <section className="w-full max-w-5xl glass p-5 mt-5 flex flex-col sm:flex-row items-center gap-4">
        <div className="sandglass text-4xl shrink-0" aria-hidden="true">
          <Hourglass size={36} style={{ color: 'var(--t-accent)' }} />
        </div>
        <div className="flex-1 text-center sm:text-start">
          <p className="text-sm font-semibold text-heading">{t('leisure.moreSoon')}</p>
          <p className="text-xs text-subtle mt-0.5 leading-relaxed">{t('leisure.desc')}</p>
        </div>
        {!notified ? (
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (!email.trim()) return;
              setNotified(true);
              audio.play('discover');
              toast.success(t('leisure.notified'));
            }}
          >
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={t('leisure.emailPh')}
              className="w-40 sm:w-44 px-3 py-2 rounded-xl text-xs outline-none"
              style={{
                background: 'var(--t-panel)',
                border: '1px solid var(--t-glass-border)',
                color: 'var(--t-text)',
              }}
              aria-label={t('leisure.emailPh')}
              required
            />
            <button type="submit" className="btn-glass px-3 py-2 text-xs">
              <Bell size={14} aria-hidden="true" />
            </button>
          </form>
        ) : (
          <p className="text-xs" style={{ color: 'var(--t-accent)' }}>
            ✦ {t('leisure.notified')}
          </p>
        )}
      </section>
    </main>
  );
}
