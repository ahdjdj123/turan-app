'use client';

import { useMemo } from 'react';
import {
  BORDER_GEO,
  RIVERS_GEO,
  ROUTES_GEO,
  MOUNTAIN_ZONES,
  DESERT_ZONES,
  LAKE_GEO,
  REGION_LABEL_GEO,
  NEIGHBOUR_LABEL_GEO,
  project,
  MAP_W,
  MAP_H,
  ATLAS_OX,
  ATLAS_OY,
} from '@/data/geo';
import type { EraId } from '@/data/eras';

/**
 * TURAN V3 geographic atlas — Uzbekistan as a hand-lit museum plate:
 * terrain relief with mountain shadows, river gradients, desert dune
 * texture, oases, faint constellations, atmospheric light and vignette.
 * The only living things on the plate: one caravan walking the Silk
 * Road and a soft shimmer on the Amu Darya. Everything else is static.
 */

export interface MapLabels {
  aral: string;
  amuDarya: string;
  syrDarya: string;
  zarafshan: string;
}

function toPath(pts: [number, number][], closed: boolean): string {
  const P = pts.map(([lon, lat]) => {
    const p = project(lon, lat);
    return [p.x, p.y] as [number, number];
  });
  let d = `M ${P[0][0].toFixed(1)} ${P[0][1].toFixed(1)}`;
  const n = P.length;
  const last = closed ? n : n - 1;
  for (let i = 0; i < last; i++) {
    const cur = P[i];
    const next = P[(i + 1) % n];
    const mx = ((cur[0] + next[0]) / 2).toFixed(1);
    const my = ((cur[1] + next[1]) / 2).toFixed(1);
    d += ` Q ${cur[0].toFixed(1)} ${cur[1].toFixed(1)} ${mx} ${my}`;
  }
  if (closed) d += ' Z';
  return d;
}

/* deterministic pseudo random (stable between renders) */
function mulberry(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** era tints — the historical atmosphere of the whole plate */
const ERA_TINT: Record<EraId, { color: string; opacity: number }> = {
  ancient: { color: '#C66B4D', opacity: 0.07 },
  hellenistic: { color: '#B8952E', opacity: 0.07 },
  islamic: { color: '#2A9D8F', opacity: 0.08 },
  timurid: { color: '#D4A53C', opacity: 0.09 },
  khanates: { color: '#9E2A2B', opacity: 0.08 },
  soviet: { color: '#8A97A5', opacity: 0.09 },
  modern: { color: '#D4A53C', opacity: 0.05 },
};

/* Khanate realms (1500–1876) — approximate polygons */
const KHIVA_REALM: [number, number][] = [
  [57.0, 41.4], [58.6, 40.4], [59.8, 39.9], [61.4, 39.6], [62.5, 40.0],
  [62.7, 41.4], [61.6, 43.4], [59.3, 44.7], [57.4, 43.6],
];
const BUKHARA_REALM: [number, number][] = [
  [62.7, 41.4], [62.5, 40.0], [63.4, 38.4], [64.7, 37.4], [66.4, 37.6],
  [67.6, 38.2], [68.4, 38.7], [68.6, 40.0], [69.2, 41.2], [68.0, 42.1],
  [66.0, 42.6], [63.8, 42.7],
];
const KOKAND_REALM: [number, number][] = [
  [68.6, 40.0], [69.2, 41.2], [70.6, 41.5], [71.4, 41.0], [72.9, 40.2],
  [71.6, 40.0], [70.0, 39.9],
];

/* Russian railway (Soviet era) */
const RAILWAYS: [number, number][][] = [
  [[58.8, 41.5], [60.6, 41.6], [62.0, 41.3], [63.6, 40.9], [65.4, 40.7], [67.0, 40.6], [68.7, 40.75], [69.5, 41.05]], // Orenburg–Tashkent
  [[69.3, 41.3], [67.9, 40.6], [66.9, 40.0], [66.0, 39.9], [64.9, 39.95], [64.1, 40.1]], // Tashkent–Bukhara
  [[69.3, 41.3], [70.6, 40.8], [71.9, 40.6], [72.3, 40.5]], // Tashkent–Andijan
];

/* desert oases — teal-green jewel clusters at the foot of the dunes */
const OASES: [number, number][] = [
  [60.4, 43.0], [61.0, 42.4],           // Khorezm delta
  [64.4, 40.2], [65.0, 39.8],           // Zarafshan mouth
  [65.6, 39.1],                          // Karshi steppe
  [66.9, 37.4],                          // Termez
  [58.3, 43.6],                          // lower Amu
];

interface MapCanvasProps {
  quality?: '720' | '1080' | '1440';
  eraId?: EraId;
  labels?: MapLabels;
  /** selected city → the route near it glows gold */
  focus?: { x: number; y: number } | null;
}

export function MapCanvas({ eraId = 'timurid', labels, focus }: MapCanvasProps) {
  const L = labels ?? { aral: 'Aral Sea', amuDarya: 'Amu Darya', syrDarya: 'Syr Darya', zarafshan: 'Zarafshan' };

  const borderPath = useMemo(() => toPath(BORDER_GEO, true), []);
  const riverPaths = useMemo(() => RIVERS_GEO.map((r) => toPath(r.pts, false)), []);
  const routePaths = useMemo(() => ROUTES_GEO.map((r) => toPath(r.pts, false)), []);
  const railPaths = useMemo(() => RAILWAYS.map((r) => toPath(r, false)), []);
  const khivaPath = useMemo(() => toPath(KHIVA_REALM, true), []);
  const bukharaPath = useMemo(() => toPath(BUKHARA_REALM, true), []);
  const kokandPath = useMemo(() => toPath(KOKAND_REALM, true), []);

  /* desert stipple + dune strokes — static, generated once */
  const desertDots = useMemo(() => {
    const rnd = mulberry(42);
    const dots: [number, number, number][] = [];
    for (const zone of DESERT_ZONES) {
      const c = project(zone.cx, zone.cy);
      const rx = (zone.rx / 18) * MAP_W;
      const ry = (zone.ry / 8.8) * MAP_H;
      for (let i = 0; i < 54; i++) {
        const a = rnd() * Math.PI * 2;
        const r = Math.sqrt(rnd());
        dots.push([c.x + Math.cos(a) * r * rx, c.y + Math.sin(a) * r * ry, 0.9 + rnd() * 1.8]);
      }
    }
    return dots;
  }, []);

  /* dune ridge lines inside the desert zones */
  const duneLines = useMemo(() => {
    const rnd = mulberry(7);
    const lines: string[] = [];
    for (const zone of DESERT_ZONES) {
      const c = project(zone.cx, zone.cy);
      const rx = (zone.rx / 18) * MAP_W;
      const ry = (zone.ry / 8.8) * MAP_H;
      for (let i = 0; i < 5; i++) {
        const y = c.y + (rnd() - 0.5) * ry * 1.5;
        const x0 = c.x - rx * (0.5 + rnd() * 0.4);
        const x1 = c.x + rx * (0.5 + rnd() * 0.4);
        const lift = 5 + rnd() * 9;
        lines.push(`M ${x0.toFixed(1)} ${y.toFixed(1)} Q ${((x0 + x1) / 2).toFixed(1)} ${(y - lift).toFixed(1)} ${x1.toFixed(1)} ${y.toFixed(1)}`);
      }
    }
    return lines;
  }, []);

  /* constellation — faint manuscript stars across the whole sheet */
  const stars = useMemo(() => {
    const rnd = mulberry(1224);
    const out: [number, number, number][] = [];
    const W = MAP_W + ATLAS_OX * 2;
    const H = MAP_H + ATLAS_OY * 2;
    for (let i = 0; i < 230; i++) {
      out.push([-ATLAS_OX + rnd() * W, -ATLAS_OY + rnd() * H, 0.35 + rnd() * 0.75]);
    }
    return out;
  }, []);

  const oasisPts = useMemo(() => OASES.map(([lon, lat]) => project(lon, lat)), []);

  /* trunk silk road (first route) carries the walking caravan */
  const trunkPath = routePaths[0];
  const trunkGeo = ROUTES_GEO[0];
  const caravanStart = useMemo(() => {
    if (!trunkGeo) return { x: 0, y: 0 };
    return project(trunkGeo.pts[0][0], trunkGeo.pts[0][1]);
  }, [trunkGeo]);

  const aral = project(LAKE_GEO.aral.lon, LAKE_GEO.aral.lat);
  const aralRx = (LAKE_GEO.aral.rx / 18) * MAP_W;
  const aralRy = (LAKE_GEO.aral.ry / 8.8) * MAP_H;
  const aydarkul = project(LAKE_GEO.aydarkul.lon, LAKE_GEO.aydarkul.lat);
  const sarykamysh = project(LAKE_GEO.sarykamysh.lon, LAKE_GEO.sarykamysh.lat);

  const tint = ERA_TINT[eraId] ?? ERA_TINT.timurid;
  const focusPt = focus ? { x: (focus.x / 100) * MAP_W, y: (focus.y / 100) * MAP_H } : null;
  const focusAtlas = focusPt ? { x: focusPt.x, y: focusPt.y } : null;

  return (
    <svg
      viewBox={`${-ATLAS_OX} ${-ATLAS_OY} ${MAP_W + ATLAS_OX * 2} ${MAP_H + ATLAS_OY * 2}`}
      className="turan-map-svg"
      style={{ background: 'var(--t-map-deep)' }}
      aria-hidden="true"
      preserveAspectRatio="xMidYMid slice"
    >
      <defs>
        <radialGradient id="turanPlate" cx="46%" cy="36%" r="88%">
          <stop offset="0%" stopColor="#1b1730" />
          <stop offset="58%" stopColor="#131020" />
          <stop offset="100%" stopColor="#0a0814" />
        </radialGradient>
        <linearGradient id="turanLand" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#251e40" />
          <stop offset="100%" stopColor="#1a1531" />
        </linearGradient>
        <linearGradient id="turanGold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#d4a53c" />
          <stop offset="55%" stopColor="#b8952e" />
          <stop offset="100%" stopColor="#8a6d24" />
        </linearGradient>
        <linearGradient id="turanRiver" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#6fb5c4" />
          <stop offset="100%" stopColor="#2f6f81" />
        </linearGradient>
        {/* atmospheric vignette — light in the heart of the plate */}
        <radialGradient id="turanVignette" cx="50%" cy="42%" r="74%">
          <stop offset="0%" stopColor="#000000" stopOpacity="0" />
          <stop offset="72%" stopColor="#000000" stopOpacity="0" />
          <stop offset="100%" stopColor="#05030c" stopOpacity="0.52" />
        </radialGradient>
        <radialGradient id="turanSun" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#e8c46a" stopOpacity="0.2" />
          <stop offset="45%" stopColor="#e8c46a" stopOpacity="0.07" />
          <stop offset="100%" stopColor="#e8c46a" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* plate background — the whole atlas sheet */}
      <rect x={-ATLAS_OX} y={-ATLAS_OY} width={MAP_W + ATLAS_OX * 2} height={MAP_H + ATLAS_OY * 2} fill="url(#turanPlate)" />

      {/* ---- night sky: faint manuscript stars (static) ---- */}
      <g>
        {stars.map(([x, y, r], i) => (
          <circle key={`st-${i}`} cx={x} cy={y} r={r} fill="#cfc4e6" opacity={i % 7 === 0 ? 0.5 : 0.24} />
        ))}
        {/* one constellation: the She-Camel above Khorezm */}
        <g stroke="#9d92c4" strokeWidth={0.8} opacity={0.3}>
          <path d="M 108 96 L 146 88 L 178 102 L 214 96" fill="none" />
          <path d="M 146 88 L 152 66" fill="none" />
        </g>
        {[[108, 96], [146, 88], [178, 102], [214, 96], [152, 66]].map(([x, y], i) => (
          <circle key={`cn-${i}`} cx={x} cy={y} r={1.7} fill="#d8cff0" opacity={0.55} />
        ))}
      </g>

      {/* ---- territory: land with hand-inked coast ---- */}
      {/* soft outer shadow of the land itself */}
      <path d={borderPath} fill="#0d0a1c" opacity={0.7} transform="translate(7 9)" />
      <path d={borderPath} fill="url(#turanLand)" stroke="url(#turanGold)" strokeWidth={2.6} strokeLinejoin="round" />
      {/* the ink under-drawing: a fine dashed line inside the gold coast */}
      <path d={borderPath} fill="none" stroke="#0e0b1a" strokeWidth={5.4} opacity={0.35} transform="translate(-1.5 -1.5)" />
      <path d={borderPath} fill="none" stroke="#d4a53c" strokeWidth={0.7} opacity={0.55} />
      <path d={borderPath} fill="none" stroke="#e7cf96" strokeWidth={0.45} strokeDasharray="7 5" opacity={0.4} />

      {/* ---- desert: stipple + dune ridges ---- */}
      <g opacity={0.55}>
        {desertDots.map(([x, y, r], i) => (
          <circle key={`d-${i}`} cx={x} cy={y} r={r} fill="#8a734f" opacity={0.35} />
        ))}
      </g>
      <g opacity={0.3}>
        {duneLines.map((d, i) => (
          <path key={`dl-${i}`} d={d} fill="none" stroke="#a58a5e" strokeWidth={0.8} />
        ))}
      </g>

      {/* ---- oases: living green at the desert's edge ---- */}
      <g>
        {oasisPts.map((p, i) => (
          <g key={`o-${i}`} transform={`translate(${p.x} ${p.y})`}>
            <circle r={7.5} fill="#2f7d6d" opacity={0.2} />
            <circle r={3.6} fill="#3f9c82" opacity={0.4} />
            <circle r={1.1} cy={-0.6} fill="#7fc9a4" opacity={0.75} />
          </g>
        ))}
      </g>

      {/* ---- mountains: relief with shadows on the south-east flank ---- */}
      <g>
        {MOUNTAIN_ZONES.map((zone, zi) => {
          const d = toPath(zone.pts, true);
          const peaks = zone.peaks.map((pk) => project(pk[0], pk[1]));
          return (
            <g key={zi}>
              {/* cast shadow SE */}
              <path d={d} fill="#0e0b1e" opacity={0.55} transform="translate(6 6)" />
              {/* body */}
              <path d={d} fill="#2b2444" opacity={0.62} />
              {/* moonlit north-west rim */}
              <path d={d} fill="none" stroke="#584a7e" strokeWidth={1.1} opacity={0.6} transform="translate(-1.5 -1.5)" />
              {/* ridge hatching + peak marks */}
              {peaks.map((p, i) => (
                <g key={i}>
                  <path
                    d={`M ${p.x - 9} ${p.y + 5} L ${p.x} ${p.y - 7} L ${p.x + 9} ${p.y + 5}`}
                    fill="none"
                    stroke="#8d7fb0"
                    strokeWidth={1.3}
                    opacity={0.62}
                  />
                  {i % 2 === 0 && <circle cx={p.x} cy={p.y - 8.2} r={1} fill="#e9e2f7" opacity={0.7} />}
                </g>
              ))}
            </g>
          );
        })}
      </g>

      {/* ---- lakes ---- */}
      <g>
        <ellipse cx={aral.x + 3} cy={aral.y + 4} rx={aralRx} ry={aralRy} fill="#101527" opacity={0.5} transform={`rotate(-16 ${aral.x + 3} ${aral.y + 4})`} />
        <ellipse cx={aral.x} cy={aral.y} rx={aralRx} ry={aralRy} fill="url(#turanRiver)" opacity={0.75} transform={`rotate(-16 ${aral.x} ${aral.y})`} />
        <ellipse cx={aral.x - aralRx * 0.25} cy={aral.y + aralRy * 0.15} rx={aralRx * 0.55} ry={aralRy * 0.5} fill="#5c98a5" opacity={0.55} transform={`rotate(-16 ${aral.x} ${aral.y})`} />
        <ellipse cx={aydarkul.x + 2} cy={aydarkul.y + 2} rx={(0.55 / 18) * MAP_W} ry={(0.13 / 8.8) * MAP_H} fill="#101527" opacity={0.45} transform={`rotate(-8 ${aydarkul.x + 2} ${aydarkul.y + 2})`} />
        <ellipse cx={aydarkul.x} cy={aydarkul.y} rx={(0.55 / 18) * MAP_W} ry={(0.13 / 8.8) * MAP_H} fill="#3e6a72" opacity={0.7} transform={`rotate(-8 ${aydarkul.x} ${aydarkul.y})`} />
        <ellipse cx={sarykamysh.x} cy={sarykamysh.y} rx={(0.4 / 18) * MAP_W} ry={(0.28 / 8.8) * MAP_H} fill="#3e6a72" opacity={0.65} />
        <text x={aral.x} y={aral.y - aralRy - 8} textAnchor="middle" fontSize={12} fill="#6f9aa1" fontStyle="italic" opacity={0.85} fontFamily="var(--font-display)">
          {L.aral}
        </text>
      </g>

      {/* ---- rivers: gradient body + bright core + bank shadow ---- */}
      {riverPaths.map((d, i) => (
        <g key={i}>
          <path d={d} fill="none" stroke="#0d1120" strokeWidth={6} opacity={0.35} strokeLinecap="round" transform="translate(2 3)" />
          <path d={d} fill="none" stroke="url(#turanRiver)" strokeWidth={4.4} opacity={0.4} strokeLinecap="round" />
          <path d={d} fill="none" stroke="#7fbccb" strokeWidth={1.6} opacity={0.85} strokeLinecap="round" />
        </g>
      ))}
      {/* shimmer on the great river only — three slow breaths of light */}
      {riverPaths[0] && (
        <g>
          <circle cx={project(61.6, 41.9).x} cy={project(61.6, 41.9).y} r={9} fill="#bfe3ec" opacity={0.12} className="river-shimmer" style={{ animationDelay: '0s' }} />
          <circle cx={project(63.2, 40.6).x} cy={project(63.2, 40.6).y} r={7} fill="#bfe3ec" opacity={0.12} className="river-shimmer" style={{ animationDelay: '2.8s' }} />
          <circle cx={project(66.5, 38.1).x} cy={project(66.5, 38.1).y} r={8} fill="#bfe3ec" opacity={0.12} className="river-shimmer" style={{ animationDelay: '5.4s' }} />
        </g>
      )}

      {/* ---- silk road: dotted gold with a walking caravan ---- */}
      {routePaths.map((d, i) => (
        <g key={i}>
          <path d={d} fill="none" stroke="#d4a53c" strokeWidth={5} opacity={0.1} strokeLinecap="round" />
          <path d={d} fill="none" stroke="#d4a53c" strokeWidth={1.6} strokeDasharray="1.5 7" strokeLinecap="round" opacity={0.75} />
        </g>
      ))}
      {trunkPath && (
        <g>
          {/* the caravan — the only traveler that never stops */}
          <g className="map-caravan">
            <g transform="scale(1.05)">
              <path d="M0 0 q1.6-4.2 4.6-5.6 q1-3.4 4.2-4 q3.4-0.6 5.2 2.2 q1.8-1.6 4.6-1 l-0.6 1.8 q-2.2 0-3.4 1.6 l-1 5 h-1.8 l0.6-4 q-3.4 1.2-6.8 0.6 l-1 3.4 h-1.8 z" fill="#1a1026" opacity={0.95} />
              <circle cx="7.4" cy="-9.4" r="1.5" fill="#1a1026" opacity={0.95} />
            </g>
            <animateMotion dur="52s" repeatCount="indefinite" rotate="auto" path={trunkPath} />
          </g>
          {/* faint footprints trail behind it */}
        </g>
      )}

      {/* ---- selected destination: the road lights up gold ---- */}
      {focusPt && (
        <g pointerEvents="none">
          <circle cx={focusPt.x} cy={focusPt.y} r={30} fill="none" stroke="#e8c46a" strokeWidth={1.2} opacity={0.35} />
          <circle cx={focusPt.x} cy={focusPt.y} r={46} fill="none" stroke="#e8c46a" strokeWidth={0.7} opacity={0.2} strokeDasharray="2 5" />
          <circle cx={focusPt.x} cy={focusPt.y} r={16} fill="#e8c46a" opacity={0.1} />
        </g>
      )}

      {/* ---- era overlays (opacity-only transitions) ---- */}
      {eraId === 'khanates' && (
        <g aria-hidden="true">
        <path d={khivaPath} fill="#2A9D8F" fillOpacity={0.14} stroke="#2A9D8F" strokeOpacity={0.5} strokeWidth={1.2} strokeDasharray="5 4" />
        <path d={bukharaPath} fill="#D4A53C" fillOpacity={0.13} stroke="#D4A53C" strokeOpacity={0.5} strokeWidth={1.2} strokeDasharray="5 4" />
        <path d={kokandPath} fill="#9E2A2B" fillOpacity={0.16} stroke="#9E2A2B" strokeOpacity={0.55} strokeWidth={1.2} strokeDasharray="5 4" />
        <text x={project(59.8, 42.6).x} y={project(59.8, 42.6).y} textAnchor="middle" fontSize={13} fill="#8fd0c6" letterSpacing="2.5" opacity={0.9} fontFamily="var(--font-display)">KHIVA</text>
        <text x={project(65.6, 41.4).x} y={project(65.6, 41.4).y} textAnchor="middle" fontSize={13} fill="#e4c06a" letterSpacing="2.5" opacity={0.9} fontFamily="var(--font-display)">BUKHARA</text>
        <text x={project(70.8, 40.9).x} y={project(70.8, 40.9).y} textAnchor="middle" fontSize={11} fill="#d98d8e" letterSpacing="2.5" opacity={0.9} fontFamily="var(--font-display)">KOKAND</text>
        </g>
      )}

      {/* Timurid: imperial label + capital star */}
      {eraId === 'timurid' && (
        <g aria-hidden="true">
        <text
          x={project(64.2, 43.2).x}
          y={project(64.2, 43.2).y}
          textAnchor="middle"
          fontSize={15}
          fill="#d4a53c"
          opacity={0.42}
          letterSpacing="7"
          fontFamily="var(--font-display)"
        >
          T I M U R I D   R E A L M
        </text>
        <g transform={`translate(${project(66.96, 39.65).x} ${project(66.96, 39.65).y - 26})`} opacity={0.9}>
          <path d="M 0 -9 L 2.6 -2.8 L 9 -2.8 L 3.9 1.4 L 5.8 8 L 0 4 L -5.8 8 L -3.9 1.4 L -9 -2.8 L -2.6 -2.8 Z" fill="#d4a53c" opacity={0.95} />
        </g>
        </g>
      )}

      {/* Soviet: railways */}
      {eraId === 'soviet' && (
        <g aria-hidden="true">
        {railPaths.map((d, i) => (
          <g key={i}>
            <path d={d} fill="none" stroke="#9aa7b5" strokeWidth={2.4} opacity={0.55} />
            <path d={d} fill="none" stroke="#12101f" strokeWidth={1} strokeDasharray="6 6" opacity={0.8} />
          </g>
        ))}
        </g>
      )}

      {/* Islamic: Samanid orbit label */}
      {eraId === 'islamic' && (
        <g aria-hidden="true">
        <text
          x={project(64.6, 43.4).x}
          y={project(64.6, 43.4).y}
          textAnchor="middle"
          fontSize={14}
          fill="#7cc8bd"
          opacity={0.45}
          letterSpacing="6"
          fontFamily="var(--font-display)"
        >
          M A W A R A N N A H R
        </text>
        </g>
      )}

      {/* ---- era tint wash (topmost over land) ---- */}
      <rect x={-ATLAS_OX} y={-ATLAS_OY} width={MAP_W + ATLAS_OX * 2} height={MAP_H + ATLAS_OY * 2} fill={tint.color} opacity={tint.opacity} className="era-tint" data-era={eraId} pointerEvents="none" />

      {/* ---- historical region labels ---- */}
      {REGION_LABEL_GEO.map((l) => {
        const p = project(l.lon, l.lat);
        return (
          <text
            key={l.text}
            x={p.x}
            y={p.y}
            textAnchor="middle"
            fontSize={l.size ?? 12}
            fill="#9a8563"
            opacity={0.5}
            fontFamily="var(--font-display)"
            letterSpacing="4"
          >
            {l.text}
          </text>
        );
      })}

      {/* ---- river labels (translated) ---- */}
      <text x={project(62.9, 39.7).x} y={project(62.9, 39.7).y} fontSize={11.5} fill="#5fa3b5" fontStyle="italic" opacity={0.8} fontFamily="var(--font-display)" transform={`rotate(38 ${project(62.9, 39.7).x} ${project(62.9, 39.7).y})`}>
        {L.amuDarya}
      </text>
      <text x={project(68.4, 41.15).x} y={project(68.4, 41.15).y - 6} fontSize={11.5} fill="#5fa3b5" fontStyle="italic" opacity={0.8} fontFamily="var(--font-display)">
        {L.syrDarya}
      </text>
      <text x={project(66.4, 40.15).x} y={project(66.4, 40.15).y + 14} fontSize={10.5} fill="#5fa3b5" fontStyle="italic" opacity={0.75} fontFamily="var(--font-display)">
        {L.zarafshan}
      </text>

      {/* ---- faint TURAN watermark ---- */}
      <text
        x={MAP_W / 2}
        y={MAP_H / 2}
        textAnchor="middle"
        fontSize={110}
        fill="#d4a53c"
        opacity={0.04}
        fontFamily="var(--font-display)"
        letterSpacing="44"
      >
        TURAN
      </text>

      {/* ---- neighbours ---- */}
      {NEIGHBOUR_LABEL_GEO.map((n) => {
        const p = project(n.lon, n.lat);
        return (
          <text
            key={n.text}
            x={p.x}
            y={p.y}
            textAnchor="middle"
            fontSize={9.5}
            fill="#5e5478"
            opacity={0.75}
            letterSpacing="3"
            fontFamily="var(--font-display)"
          >
            {n.text}
          </text>
        );
      })}

      {/* ---- atmosphere: low sun, vignette ---- */}
      <circle cx={MAP_W * 0.86} cy={-ATLAS_OY + 60} r={MAP_W * 0.42} fill="url(#turanSun)" pointerEvents="none" />
      <rect x={-ATLAS_OX} y={-ATLAS_OY} width={MAP_W + ATLAS_OX * 2} height={MAP_H + ATLAS_OY * 2} fill="url(#turanVignette)" pointerEvents="none" />

      {/* the country plate frame — double-ruled engraving around the border only */}
      <rect x={-5} y={-5} width={MAP_W + 10} height={MAP_H + 10} fill="none" stroke="#d4a53c" strokeWidth={0.8} opacity={0.3} />
      <rect x={-10} y={-10} width={MAP_W + 20} height={MAP_H + 20} fill="none" stroke="#d4a53c" strokeWidth={0.4} opacity={0.15} />
    </svg>
  );
}
