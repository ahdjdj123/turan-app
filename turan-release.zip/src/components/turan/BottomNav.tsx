'use client';

import { Map as MapIcon, Compass, Bookmark, UserRound } from 'lucide-react';
import { useTuranStore } from '@/lib/store';
import { audio } from '@/lib/audio-engine';
import { useTuranLang } from './useTuranLang';
import type { Screen } from '@/lib/turan-types';

/**
 * Instagram-style bottom navigation — mobile only (hidden ≥768px).
 * Thumb-reachable 56px targets, spring press feedback, safe-area aware.
 */
export function BottomNav() {
  const screen = useTuranStore((s) => s.screen);
  const setScreen = useTuranStore((s) => s.setScreen);
  const discoveredCount = useTuranStore((s) => s.discovered.length);
  const { t } = useTuranLang();

  const items: {
    id: Screen;
    icon: React.ComponentType<{ size?: number; strokeWidth?: number }>;
    label: string;
    badge?: number;
    activeFor: Screen[];
  }[] = [
    { id: 'map', icon: MapIcon, label: t('nav.map'), activeFor: ['map', 'random'] },
    { id: 'explore', icon: Compass, label: t('nav.explore'), activeFor: ['explore'] },
    { id: 'journal', icon: Bookmark, label: t('nav.saved'), badge: discoveredCount, activeFor: ['journal', 'leisure'] },
    { id: 'settings', icon: UserRound, label: t('nav.profile'), activeFor: ['settings'] },
  ];

  return (
    <nav className="bottom-nav md:hidden" aria-label={t('explore.title')}>
      {items.map((it) => {
        const active = it.activeFor.includes(screen);
        const Icon = it.icon;
        return (
          <button
            key={it.id}
            className={`bottom-nav-item ${active ? 'active' : ''}`}
            onClick={() => {
              if (screen === it.id) return;
              audio.play('click');
              setScreen(it.id);
            }}
            aria-label={it.label}
            aria-current={active ? 'page' : undefined}
          >
            <span className="bottom-nav-icon">
              <Icon size={22} strokeWidth={active ? 2.4 : 1.9} />
              {typeof it.badge === 'number' && it.badge > 0 && (
                <span className="bottom-nav-badge tabular-nums">{it.badge > 99 ? '99+' : it.badge}</span>
              )}
            </span>
            <span className="bottom-nav-label">{it.label}</span>
            <span className="bottom-nav-dot" aria-hidden="true" />
          </button>
        );
      })}
    </nav>
  );
}
