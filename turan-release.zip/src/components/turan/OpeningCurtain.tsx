'use client';

import { useEffect, useState } from 'react';
import { GlyphCompassRose } from './glyphs';

/**
 * V3 opening ceremony — replaces the spinner forever.
 * Parchment unfolds → the compass turns → the Silk Road draws itself
 * → TURAN appears → the curtain lifts onto the map.
 * One-shot, transform/opacity only. Plays once per browser session;
 * the parent keeps it mounted for the whole ceremony via onDone.
 */
export function OpeningCurtain({ onDone }: { onDone?: () => void }) {
  const [phase, setPhase] = useState<'play' | 'lift'>('play');

  useEffect(() => {
    const t1 = window.setTimeout(() => setPhase('lift'), 2250);
    const t2 = window.setTimeout(() => onDone?.(), 2900);
    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    };
  }, [onDone]);

  return (
    <div
      className={`curtain ${phase === 'lift' ? 'curtain-lift' : ''}`}
      role="status"
      aria-label="TURAN is opening"
    >
      {/* the unfolding parchment sheet */}
      <div className="curtain-sheet" aria-hidden="true">
        <div className="curtain-compass">
          <GlyphCompassRose size={64} strokeWidth={1.1} />
        </div>

        {/* the road draws itself west → east */}
        <svg className="curtain-road" viewBox="0 0 240 64" fill="none" aria-hidden="true">
          <path
            d="M6 52 C 44 46 60 30 96 32 C 132 34 142 18 178 16 C 202 14.6 220 12 234 9"
            stroke="#b8892c"
            strokeWidth="1.6"
            strokeLinecap="round"
            strokeDasharray="3.5 6"
            className="curtain-road-path"
          />
          <circle className="curtain-road-dot" r="2.4" fill="#d4a53c" cx="6" cy="52" />
        </svg>

        {/* the name */}
        <div className="curtain-title">TURAN</div>
        <div className="curtain-caption">THE HEART OF THE SILK ROAD</div>
      </div>
    </div>
  );
}
