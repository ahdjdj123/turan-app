# TURAN — The Heart of the Silk Road

An immersive interactive museum of Uzbekistan's history. Explore 16 cities
across 7 eras — from ancient Sogdiana and the Hellenistic frontier, through the
Islamic Golden Age and the Timurid renaissance, to the Khanates, the Soviet
period and modern independence — on a hand-drawn atlas of the Silk Road.

## Features

- **Animated historical atlas** — terrain, rivers, caravan routes, era overlays
  and era-colored city markers across 3,000 px of hand-drawn map
- **7-era timeline** — scrub 8,000 years; every city re-renders per era
- **16 cities × 7 eras** — stories, landmarks, people, key events, facts,
  landmark plaques and curated image galleries with a cinematic lightbox
- **Discovery systems** — daily discovery, random-discovery compass,
  discovery journal with progress (76 combinations)
- **Leisure games** — Era Trial quiz with difficulty levels, Caravan Memory
  card game
- **Travel intelligence** — ratings, hours, tickets, weather model, local
  food, tips, reviews and nearby destinations with real distances
- **5 languages** — English, Русский, Oʻzbekcha, العربية (RTL), Türkçe
- **3 themes** — Classic dark, Parchment light, High Contrast + 4 accents
- **Synthesized ambient audio** — WebAudio drone + sound design, optional
  AI narration
- **Keyboard shortcuts** — press `?` in the app
- **PWA** — offline-capable service worker, installable

## Tech stack

Next.js 16 (App Router) · React 19 · TypeScript · Tailwind CSS 4 ·
Framer Motion · Zustand (persisted to localStorage) · WebAudio · Canvas/SVG

## Getting started

```bash
bun install        # or: npm install
bun run dev        # development on http://localhost:3000
bun run build      # production build
bun run start      # serve production build
```

All progress (journal, settings) is stored locally in the browser — no
database is required.

## Project structure

```
src/
  app/            # root route, layout, API routes (narration, health)
  components/
    turan/        # TURAN app: map, timeline, city experience, games, settings
    ui/           # shadcn/ui primitives
  data/           # cities, eras, translations (5 languages), travel data, geo
  lib/            # store, utils, audio engine, types
public/
  images/         # generated city artwork, gallery plates, icons
scripts/          # asset generation scripts used to produce the artwork
```

## Asset generation (optional)

The images in `public/images` are pre-generated and committed. The scripts
that produced them live in `scripts/` and require a `z-ai-web-dev-sdk`
credential — you only need them if you want to regenerate artwork.

---

Compiled by the TURAN curators from UNESCO dossiers, academic literature and
museum archives.
